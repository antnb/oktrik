---
layout: post
title: Cara membatasi pengguna wifi indihome (Blokir Via MAC blacklist,Whitelist dan
 Max user)
date: '2022-12-12T18:41:00.005+07:00'
author: rosari J
tags:
- indihome
- internet
modification_time: '2022-12-13T16:51:32.826+07:00'
blogger_id: tag:blogger.com,1999:blog-7329298365997944344.post-4710370358746085909
blogger_orig_url: https://www.oktrik.com/2022/12/cara-membatasi-pengguna-wifi-indihome.html
---

Indihome merupakan layanan Internet berkecepatan tinggi yang ditawarkan oleh Telkom Indonesia. Indihome menawarkan layanan Wifi yang handal dan cepat untuk menghubungkan berbagai perangkat komputer, laptop, smartphone, dan tablet ke internet. Ini memungkinkan Anda untuk mengakses internet dari mana saja di rumah Anda dan menikmati konten dan layanan yang terhubung. Layanan ini dilengkapi dengan berbagai fitur keamanan untuk melindungi Anda dan jaringan Anda dari serangan berbahaya. Dengan Indihome, Anda dapat menikmati akses internet yang cepat, aman, dan andal.


Koneksi WiFi Indihome lambat disebabkan oleh jumlah pengguna yang terlalu banyak. Hal ini menyebabkan banyak orang yang merasa kecepatan internet lambat. Koneksi Wi-Fi IndiHome yang lambat biasanya terjadi karena terlalu banyak pengguna wifi yang terhubung dalam satu access point (SSID). Hal ini dapat menyebabkan jumlah lalu lintas data meningkat, menyebabkan kecepatan koneksi menurun. Beberapa solusi untuk masalah ini adalah memperbaiki jaringan, menggunakan perangkat Wi-Fi yang lebih kuat, dan memastikan hanya orang yang berhak yang dapat menggunakan koneksi Wi-Fi.


Membatasi pengguna wifi Indihome adalah cara yang efektif untuk mengontrol akses internet di sebuah rumah dan cara yang ampuh untuk meningkatkan keamanan dan meningkatkan kecepatan internet. Hal ini dapat dilakukan dengan memblokir alamat MAC atau mengubah password WiFi. Ini akan membantu untuk mengurangi jumlah orang yang dapat mengakses jaringan internet Anda, meminimalkan risiko serangan malware dan meningkatkan kecepatan koneksi. Dengan membatasi Pengguna WiFi Indihome, Anda dapat meningkatkan keamanan dan kinerja jaringan Anda.


[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhoMJyTrW_z0yC45EUM2-nEFCRwoELld3m9Op2nQPObE45PyP-6kwpBJ5F0lRexoaG7RD1Pl_lg4I4-_d_StrcszbkEqBdbt07_6POXkqJEIx2zhzk-TqFAVZB2OxGW-BvHL8KHIKQ4jxJ2Qv2VTd54jkmJnSG6Heo62QA5gcQ-etMDRT2mCv7JyNCAQg/s600/mac.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhoMJyTrW_z0yC45EUM2-nEFCRwoELld3m9Op2nQPObE45PyP-6kwpBJ5F0lRexoaG7RD1Pl_lg4I4-_d_StrcszbkEqBdbt07_6POXkqJEIx2zhzk-TqFAVZB2OxGW-BvHL8KHIKQ4jxJ2Qv2VTd54jkmJnSG6Heo62QA5gcQ-etMDRT2mCv7JyNCAQg/s1511/mac.jpg)
Tujuan Pembatasan Wifi Indihome
-------------------------------


Penggunaan wifi Indihome saat ini sudah menjadi hal yang sangat lazim dan banyak digunakan oleh masyarakat di seluruh Indonesia. Dengan adanya wifi Indihome ini, masyarakat dapat dengan mudah mengakses internet dan menikmati berbagai macam layanan yang ditawarkan. Namun, ada beberapa alasan mengapa penggunaan wifi Indihome harus dibatasi.


Pertama, ada kekhawatiran bahwa penggunaan wifi Indihome dapat meningkatkan risiko keamanan. Jika penggunaan wifi Indihome tidak dibatasi, maka pengguna yang tidak berwenang dapat dengan mudah mengakses jaringan dan mengakses informasi yang tidak ia miliki. Hal ini dapat menyebabkan masalah keamanan seperti pencurian data pribadi atau penyalahgunaan lainnya.


Kedua, penggunaan wifi Indihome dapat menyebabkan penurunan kualitas layanan. Jika banyak orang yang mengakses jaringan Indihome secara bersamaan, maka kualitas layanan yang diberikan akan menurun. Jaringan yang terlalu penuh akan menyebabkan penurunan kinerja dan lambatnya aliran data.


Ketiga, penggunaan wifi Indihome dapat menyebabkan penyalahgunaan lainnya. Jika penggunaan wifi Indihome tidak dibatasi, maka pengguna yang tidak berwenang dapat dengan mudah mengakses jaringan dan menyalahgunakan layanan yang diberikan. Hal ini dapat menyebabkan masalah seperti pencemaran lingkungan, penyalahgunaan sumber daya alam, dan lainnya.


Oleh karena itu, penting untuk membatasi penggunaan wifi Indihome. Hal ini dapat dilakukan dengan menggunakan sistem keamanan yang tepat, mengatur jumlah pengguna yang diizinkan untuk mengakses jaringan, dan menerapkan aturan dasar yang dapat membantu mencegah penyalahgunaan. Dengan cara ini, masyarakat dapat menikmati layanan wifi Indihome dengan nyaman dan aman.


Pembatasan User Wifi yang tidak praktis dan tidak dianjurkan
------------------------------------------------------------


Banyak artikel dan tulisan di internet yang mengklaim bahwa Pengguna Indihome dapat membatasi penggunaan WiFi dengan menggunakan aplikasi P2Pover, NetLimiter, NetCut dan sebagainya. Aplikasi P2Pover memungkinkan pengguna untuk membatasi bandwith aplikasi P2P tertentu. NetLimiter memungkinkan pengguna untuk membatasi koneksi internet secara keseluruhan atau mengatur bandwith untuk aplikasi tertentu. Sedangkan NetCut memungkinkan pengguna untuk melihat semua perangkat yang terhubung dengan jaringan dan memblokir alamat IP tertentu. Dengan menggunakan ketiga aplikasi ini, pengguna Indihome dapat membatasi penggunaan WiFi sesuai kebutuhan mereka. Itulah kesimpulan dari artikel yang banyak beredar di internet.


Namun semua aplikasi tersebut sangatlah tidak praktis dan tidak semuanya bisa berhasil, Alasan utama nya ialah Modem atau router yang disediakan secara gratis oleh pihak indihome semuanya dalam kondisi LOCKED secara pabrikan. Anda tidak akan bisa menginstall software apa pun pada modem yang telah disediakan oleh pihak indihome, Ketiga aplikasi diatas tadi hanya dapat terinstal di komputer windows atau smartphone anda.


Hal ini tentunya hanya akan membuat sesuatu yang sangat simple menjadi lebih rumit karena otomatis access point atau SSID wifi harus dibagikan via komputer atau smartphone anda, sedangkan idealnya pembatasan user wifi indihome harus di set up langsung dari sumbernya atau langsung dari router.


Cara Membatasi Wifi Indihome
----------------------------


Caranya untuk membatasi penggunaan wifi Indihome adalah dengan mengakses router. Langkah yang pertama adalah membuka browser web favorit Anda dan mengetik alamat IP modem Indihome yaitu 192.168.100.1. Setelah melakukan itu, Anda akan diminta untuk memasukkan username dan password.


Setelah masuk, Anda bisa menemukan pengaturan wifi dan mengubahnya. Anda dapat membatasi berapa banyak pengguna yang dapat terhubung ke jaringan wifi, berapa lama mereka dapat menggunakannya, dan mengontrol bandwidth yang diberikan kepada pengguna. Dengan cara ini, Anda dapat membatasi penggunaan wifi Indihome. Berikut adalah langkah langkah detail cara membatasi penggunaan wifi infihome anda:


### Mengubah kata sandi default Wifi


Mengubah kata sandi default Wifi Indihome memungkinkan pengguna untuk mencegah orang lain dari menggunakan jaringan tanpa izin. Hal ini juga membantu melindungi privasi dan keamanan informasi pengguna dan melindungi jaringan dari serangan. Dengan mengubah kata sandi default, pengguna dapat mengunci jaringan mereka dan membatasi pengguna yang tidak dikenal dari mengaksesnya.


### Mengubah SSID Default


Pelanggan dapat mengubah SSID dan saluran default dari jaringan wifi mereka. Ini berguna karena dapat membatasi pengguna yang dapat mengakses jaringan Anda, sehingga memberikan keamanan tambahan. Dengan mengubah SSID dan saluran, pelanggan Indihome dapat menyaring dan membatasi pengguna yang dapat mengakses jaringan wifi Indihome mereka, sehingga meningkatkan tingkat keamanan jaringan mereka.


### MAC Address Filtering


MAC address adalah singkatan dari Media Access Control Address, yang merupakan alamat khusus yang terkait dengan perangkat jaringan. Alamat ini digunakan untuk mengidentifikasi perangkat jaringan di jaringan. Setiap perangkat jaringan memiliki alamat MAC yang unik dan terdaftar yang mengidentifikasi perangkat secara unik. MAC Address terdiri dari 12 digit hexadecimal yang terdiri dari angka dan huruf.


contoh :`00-8C-34-AA-1A-9A` adalah Mac Address dari perangkat milik saya yaitu BlackBerry KEY2


MAC Address Filtering adalah teknologi yang memungkinkan pengguna untuk membatasi akses jaringan Wi-Fi Indihome ke perangkat yang memiliki alamat MAC yang ditentukan. Ini membuat jaringan Anda lebih aman karena hanya perangkat yang diizinkan yang dapat terhubung ke jaringan. Ini juga membantu Anda dalam pengaturan pola akses ke jaringan dan membuat orang lain tertarik untuk menggunakan jaringan Anda.


#### MAC Address whitelist


MAC Address Whitelist WiFi Indihome adalah fitur yang memungkinkan Anda untuk mengatur jaringan Wi-Fi Anda agar hanya perangkat yang akses dengan menggunakan alamat MAC tertentu yang dapat menggunakan jaringan Anda. Dengan MAC Address Whitelist, Anda dapat membatasi akses jaringan Anda hanya ke perangkat yang diketahui dan dipercaya. Fitur ini bisa sangat bermanfaat jika Anda ingin memastikan bahwa hanya perangkat yang Anda sediakan yang dapat terhubung ke jaringan Anda.


Untuk mengaktifkan MAC Address Whitelist di Indihome, Anda harus login ke router Anda melalui browser web. Setelah login, Anda harus menemukan menu Network Management dan pilih Sub menu MAC Address Whitelist. Di sana Anda dapat mengatur alamat MAC yang diizinkan untuk mengakses jaringan Anda. Anda juga dapat memilih untuk mematikan fitur MAC Address Whitelist dengan menghilangkan semua alamat MAC yang ada di daftar.


Selain mengatur alamat MAC, Anda juga dapat mengatur keamanan yang lebih kuat untuk jaringan Anda dengan mengaktifkan fitur Encryption. Fitur ini akan memungkinkan Anda untuk mengatur enkripsi yang digunakan untuk memastikan bahwa data yang ditransmisikan melalui jaringan Anda aman dari pencurian. Dengan cara ini, Anda dapat memastikan bahwa jaringan Anda aman dari berbagai ancaman keamanan.


Secara singkat dengan mengaktifkan MAC Address whitelist pada jaringan SSID anda, maka semua semua perangkat **kecuali** perangkat yang telah anda masukan ke dalam daftar whitelist tidak akan bisa tersambung ke akses wifi anda. Jika dalam daftar whitelist anda hanya tertera 3 MAC Address (termasuk perangkat anda), Maka semua perangkat yang mencoba menyambung ke titik wifi anda akan gagal terhubung **KECUALI** 3 perangkat yang telah anda masukan kedalam daftar whitelist meskipun password wifinya benar.


#### MAC Address blacklist


Fitur ini bekerja dengan cara mencocokkan MAC Address (Media Access Control Address) jaringan yang Anda gunakan dengan MAC Address jaringan yang diblokir. MAC Address adalah nomor unik yang diberikan pada setiap perangkat yang terhubung ke jaringan Anda. Dengan menggunakan MAC Address, Indihome dapat memastikan bahwa pengguna yang tidak diinginkan tidak dapat mengakses jaringan Anda.


Untuk mengaktifkan fitur ini, Anda harus login ke Indihome melalui alamat ip 192.168.100.1. Kemudian, Anda akan menemukan fitur ini pada Halaman Pengaturan Keamanan. Setelah Anda mengaktifkan fitur ini, Anda dapat menambahkan MAC Address yang ingin Anda blokir.


Fitur ini sangat berguna untuk memastikan keamanan jaringan Anda. Dengan MAC Address Blacklist Wifi Indihome, Anda dapat memastikan bahwa hanya orang-orang yang Anda inginkan yang dapat mengakses jaringan Anda. Selain itu, fitur ini juga memungkinkan Anda untuk memblokir pengguna yang mencoba menggunakan jaringan Anda tanpa izin.


Secara singkat fitur MAC Address blacklist adalah kebalikan dari MAC Address whitelist, **Router indihome HANYA AKAN MEMBLOKIR perangkat yang anda blacklist saja**. Perangkat perangkat yang di blacklist tidak akan bisa tersambung ke akses point wifi meskipun passwordnya sudah benar.


Keuntungan dari membatasi pengguna wifi Indihome
------------------------------------------------


Restriksi Wifi Indihome memiliki beberapa keuntungan. Pertama, ini akan membantu meningkatkan produktivitas di rumah. Dengan batasan-batasan tertentu tentang siapa yang dapat mengakses jaringan dan kapan mereka dapat melakukannya, ini akan membantu para orang tua mengatur waktu anak-anak mereka dan menghindari gangguan dari penggunaan internet. Kedua, ini akan membantu mengurangi risiko keamanan.


Dengan membatasi siapa yang dapat mengakses jaringan dan apa yang mereka dapat lakukan, ini akan membantu melindungi informasi sensitif dan informasi pribadi. Ketiga, ini akan membantu menghemat biaya. Dengan mengurangi penggunaan internet yang tidak diinginkan, ini akan membantu meminimalkan biaya jaringan. Keempat, ini akan membantu meningkatkan kinerja jaringan.  
  
Dengan menghilangkan penggunaan yang tidak diinginkan, ini akan membantu meningkatkan kinerja jaringan dan memungkinkan pengguna lain untuk menikmati koneksi yang lebih cepat dan lebih andal.


Penutup
-------


Dari tulisan diatas, dapat disimpulkan bahwa membatasi pengguna WiFi IndiHome adalah cara yang tepat untuk meningkatkan kinerja jaringan dan keamanan. Dengan membatasi jumlah pengguna yang menggunakan jaringan dan memastikan bahwa mereka hanya menggunakan alokasi bandwidth yang sesuai, Anda dapat memastikan bahwa tidak ada yang mengganggu kinerja jaringan dan bahwa semua orang mendapatkan koneksi yang andal.


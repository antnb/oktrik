---
layout: post
title: Cara menambahkan musik dan lagu di story ig
date: '2022-11-11T15:17:00.002+07:00'
author: rosari J
tags:
modification_time: '2022-11-11T15:17:22.957+07:00'
blogger_id: tag:blogger.com,1999:blog-7329298365997944344.post-11898439328805922
blogger_orig_url: https://www.oktrik.com/2022/11/cara-menambahkan-musik-dan-lagu-di.html
---

Instagram telah menambahkan fitur baru yang mengizinkan pengguna untuk menambahkan musik ke dalam story mereka. Fitur ini sebenarnya sudah lama ada di Snapchat, tapi sekarang Instagram telah mengembangkannya dan menjadikannya tersedia untuk pengguna di seluruh dunia.


Menambahkan musik di story ig bisa menambahkan nilai plus untuk akun kalian. Banyak selebgram yang memanfaatkan fitur ini untuk mempromosikan lagu atau musisi kepada para followersnya. Kalian bisa menggunakan aplikasi musik atau video yang terpasang di smartphone kalian.


[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiCDhDBk1hbjQr_zo6exQc3Eaykao_rQMTP4CMvSkadJDzW5mqh5uTtBnmyaBPy6T_ja0glb6ZGRFpouYuWHouPs5xv5tCAOXZ-dLKiuFMgo3oXiqMm17iW1v0dfziSZsob2pCch6h1BnYGmJjYkjiPRmQkdgi5ONtCP_z_CN-LuvAwsM-VaMEniy0Egg/s400/ig.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiCDhDBk1hbjQr_zo6exQc3Eaykao_rQMTP4CMvSkadJDzW5mqh5uTtBnmyaBPy6T_ja0glb6ZGRFpouYuWHouPs5xv5tCAOXZ-dLKiuFMgo3oXiqMm17iW1v0dfziSZsob2pCch6h1BnYGmJjYkjiPRmQkdgi5ONtCP_z_CN-LuvAwsM-VaMEniy0Egg/s1098/ig.jpg)
Instagram Story
---------------


Instagram story adalah fitur unik di Instagram yang memungkinkan pengguna untuk membagikan sekilas tentang apa yang sedang mereka lakukan atau pikirkan. Fitur ini sangat populer karena memungkinkan orang untuk berbagi secara lebih interaktif dan sosial.


Salah satu fitur menarik dari Instagram story adalah musik. Fitur ini memungkinkan pengguna untuk memilih lagu dari daftar putar atau mencari lagu khusus untuk ditambahkan ke story mereka. Musik dapat membantu menciptakan suasana dan memberi story Anda lebih banyak karakter.


Kenapa User Instagram Ingin Menambahkan Lagu Pada Story IG mereka?
------------------------------------------------------------------


Pengguna Instagram ingin menambahkan musik ke dalam story mereka untuk membuat konten yang lebih menarik dan berkesan. Musik dapat membantu meningkatkan suasana dan menciptakan efek yang lebih dramatis, sehingga membuat story Instagram lebih menarik untuk dilihat dan disimak.


Untuk menggunakan fitur ini, pertama-tama Anda perlu mengupdate aplikasi Instagram Anda ke versi terbaru. Kemudian, buka aplikasi dan masuk ke story Anda. Di sini, Anda akan melihat opsi untuk menambahkan musik ke story Anda.


Untuk menambahkan musik, Anda perlu menekan tombol yang berlabel “Tambah Musik”. Kemudian, akan muncul daftar lagu yang tersedia untuk Anda pilih. Anda dapat menelusuri lagu berdasarkan genre, popularitas, atau mood.


Setelah menemukan lagu yang Anda sukai, Anda dapat menambahkannya ke story Anda dengan menekan tombol “Play”. Anda juga dapat menyesuaikan waktu dimulainya musik dengan menggeser tombol di bawah lagu.


Selain itu, Anda juga dapat menambahkan teks, sticker, atau efek lain ke story Anda seperti biasa. Anda hanya perlu menekan tombol “Tambah” yang ada di samping opsi musik untuk mengakses fitur-fitur tersebut.


Setelah selesai, Anda dapat melihat story Anda dengan musik dengan menekan tombol “Selesai”. Anda juga dapat [mengunduh postingan](https://www.oktrik.com/2022/11/cara-download-postingan-ig-menggunakan.html) ataustory Anda dengan musik dengan menekan tombol “Unduh”.


Anda dapat membagikan story Anda dengan musik ke media sosial lain atau ke teman-teman Anda dengan menekan tombol “Bagikan”.


Anda juga dapat mengakses daftar lagu yang tersedia untuk story Anda dengan menekan tombol “Lihat Semua” yang ada di bawah opsi musik.


Fitur ini sangat berguna bagi mereka yang sering menggunakan story IG untuk meng share kegiatan sehari-hari mereka. Selain itu, fitur ini juga dapat digunakan untuk membuat story yang lebih kreatif dan menarik.


Menambah lagu di instagram story
--------------------------------


Nah, apabila kalian ingin menambahkan musik di story ig kalian maka kalian bisa mengikuti langkah-langkah dibawah ini:


1. Buka aplikasi Instagram dan masuk ke akun kalian.
2. Pada halaman utama, swipe ke kanan untuk masuk ke halaman story.
3. Tekan ikon kamera yang ada di pojok kiri atas untuk membuat story baru.
4. Selanjutnya, tekan ikon musik yang ada di samping ikon kamera untuk menambahkan musik pada story.
5. Akan muncul daftar musik yang tersedia. Pilih musik yang kalian inginkan dan tekan tombol “play”.
6. Setelah itu, story kalian akan berisi musik yang kalian pilih.
7. Jika kalian ingin menambahkan caption atau teks pada story, kalian bisa menggunakan fitur “Type” yang ada di bawah ikon musik.
8. Terakhir, tekan tombol “Share” untuk membagikan story kalian kepada para followers.


Itulah cara menambahkan musik di story ig. Semoga bermanfaat!


---
layout: post
title: Hal Hal Penting Dan Mendasar Dalam Merancang Sebuah Jaringan Koneksi WAN
date: '2018-09-16T14:52:00.006+07:00'
author: rosari J
tags:
- wireless
- internet
modification_time: '2022-09-21T20:01:25.009+07:00'
blogger_id: tag:blogger.com,1999:blog-7329298365997944344.post-2896374583805006624
blogger_orig_url: https://www.oktrik.com/2018/09/hal-hal-penting-dan-mendasar-dalam.html
---

*Perancangan yang matang Dan Manajemen yang pintar dalam mengatur **Koneksi WAN** Atau sering disingkat Wide area network amatlah penting diperhatikan jika komunikasi data yang anda lakukan sangat kritis. Untuk itu, rencanakan dengan teliti koneksi WAN apa yang akan anda gunakan sebelum terlanjur berinvestasi.*


Koneksi WAN adalah jaringan komunikasi yang menghubungkan jaringan lokal (LAN) di berbagai lokasi geografis. Koneksi WAN dapat menghubungkan LAN di seluruh dunia, atau hanya beberapa LAN yang berdekatan. Koneksi WAN umumnya menggunakan teknologi komunikasi seperti telepon, kabel, satelit, dan radio.


Teknologi WAN atau Wide Area Network adalah sebuah jaringan komputer yang mencakup area yang luas, biasanya mencakup seluruh negara atau bahkan seluruh dunia. Teknologi WAN digunakan untuk menghubungkan berbagai kantor atau lokasi bisnis yang berada di berbagai tempat. Teknologi WAN juga dapat digunakan untuk menghubungkan komputer pribadi ke internet.


### Tipe jaringan wan

Jaringan WAN (Wide Area Network) dapat dibagi menjadi dua bagian yaitu jaringan public atau jaringan yang terhubung dengan internet dan jaringan private atau jaringan yang terhubung dengan intranet. Jaringan WAN public lebih mudah dalam pembuatannya karena alamat IP dapat diperoleh dari internet service provider (ISP).  
  
Sedangkan jaringan WAN private memerlukan alamat IP yang disediakan oleh badan yang mengatur jaringan internet, yaitu Internet Assigned Numbers Authority (IANA). Jaringan WAN dapat dibagi menjadi 3 bagian, yaitu:  
  


1. Jaringan WAN point to point. Point to point adalah jaringan WAN dimana hanya terdapat 2 node atau 2 komputer yang saling terhubung. Jaringan WAN point to point dapat menggunakan beberapa teknologi seperti T1, E1, dan SONET.
2. Jaringan WAN ring Ring adalah jaringan WAN dimana terdapat banyak node dan setiap node terhubung dengan 2 node lainnya sehingga membentuk sebuah lingkaran. Jaringan WAN ring menggunakan teknologi FDDI dan Token Ring.
3. Jaringan WAN star Star adalah jaringan WAN dimana terdapat banyak node dan setiap node terhubung dengan satu node lainnya yang berfungsi sebagai pusat jaringan (central node). Jaringan WAN star menggunakan teknologi Ethernet dan Wi-Fi.


Wide area network, Jalur Panjang Data Anda
------------------------------------------


Ketika Anda memutuskan untuk mendirikan sebuah perusahaan atau bisnis, Anda harus memiliki rencana yang matang untuk mengelola data dan komunikasi perusahaan. Untuk mendukung operasional perusahaan, Anda harus memiliki jaringan WAN (Wide Area Network) yang efektif.


Jaringan WAN merupakan sebuah jaringan komputer yang mencakup area geografis yang luas, biasanya lebih dari satu kota atau negara. Jaringan WAN dapat dibagi menjadi dua bagian utama, yaitu jaringan WAN publik dan jaringan WAN privat. Jaringan WAN publik menggunakan infrastruktur publik seperti jaringan telepon publik atau jaringan internet publik untuk menghubungkan perangkat-perangkat di jaringan. Sedangkan jaringan WAN privat menggunakan infrastruktur privat seperti jaringan leased line atau jaringan VPN untuk menghubungkan perangkat-perangkat di jaringan.


Jaringan WAN privat biasanya digunakan oleh perusahaan-perusahaan besar yang memiliki banyak cabang di berbagai daerah. Karena menggunakan jaringan privat, maka keamanan data dan komunikasi perusahaan akan lebih terjamin. Namun, biaya yang dibutuhkan untuk mengoperasikan jaringan WAN privat ini cenderung lebih mahal dibandingkan dengan jaringan WAN publik.


Jika Anda berniat untuk merancang jaringan wan, maka Anda harus memiliki rencana yang matang untuk merancang jaringan WAN yang efektif. Untuk membuat jaringan WAN yang efektif, Anda harus bekerja sama dengan seorang konsultan jaringan atau perusahaan jaringan WAN. Konsultan jaringan atau perusahaan jaringan WAN akan dapat memberikan Anda berbagai saran dan rekomendasi yang tepat untuk membuat jaringan WAN yang efektif.


Jaringan fisik untuk komunikasi WAN di Indonesia masih terbilang mahal. Maksudnya mahal, harga yang dibayarkan untuk mendapatkannya tidaklah murah seperti halnya Negara-negara lain.


Selain itu, maksud dari mahal juga karena untuk mendapatkannya tidaklah mudah meskipun anda mampu membayarnya.


Masih banyak area-area yang tidak ter-cover oleh jaringan data merupakan penyebab dari mahalnya harga ketersediaan jaringan ini.


Maka itu, sangatlah bijaksana jika anda berlaku teliti dalam memilih teknologi WAN yang ingin digunakan. Telitilah apa saja kelebihan dan kekurangan, problem-problem yang mungkin timbul, perangkat apa saja yang dapat menghantarkan jaringan WAN anda dengan baik, apa yang akan anda dapatkan jika menggunakan jaringan WAN jenis tertentu, bagaimana sistem perhitungan pembayarannya, dan banyak lagi aspek penting yang harus jelas untuk anda.


Semua harus jelas untuk anda sebelum mengambil keputusan, karena selain harganya cukup mahal, pada kebanyakan servis komunikasi WAN diterapkan sistem kontrak, di mana anda diharuskan untuk berlangganan dalam jangka waktu tertentu.


Analoginya adalah jangan sampai anda membeli mobil sport yang berkecepatan tinggi padahal anda hanya butuh berjalan di gang sempit. Demikian juga dalam memilih jaringan WAN.


 


[![jaringan wan](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgbjFS3n3KIss5jTB84uaaLbqu4_rjTdOI4sxSe1swDWgzS_NA0u4bhWrAIcs4SSADp-uUO9wBUTuP5XDyYs5MYnjn80xBCU4QSMmR_QzoPk34sFkrWqV3vYL5rRxRMGLc3ytRXuxm4LyD1KRaroBJKTNqKHNOQYQlgm93CdbJFnVxm2VuGQhDYicJViw/w640-h400/wan-1-800x500.jpg "wan")](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgbjFS3n3KIss5jTB84uaaLbqu4_rjTdOI4sxSe1swDWgzS_NA0u4bhWrAIcs4SSADp-uUO9wBUTuP5XDyYs5MYnjn80xBCU4QSMmR_QzoPk34sFkrWqV3vYL5rRxRMGLc3ytRXuxm4LyD1KRaroBJKTNqKHNOQYQlgm93CdbJFnVxm2VuGQhDYicJViw/s800/wan-1-800x500.jpg)
 


 


Bagaimana Memilih Jaringan WAN Untuk Kebutuhan Anda ?
-----------------------------------------------------


Untuk memilih jaringan WAN apa yang cocok dengan anda, sebaiknya evaluasilah semua kebutuhan yang ada dalam komunikasi data anda ini. Untuk lebih memudahkannya, area atau lokasi komunikasi data terbagi atas tiga bagian besar, yaitu :


### Central Site (Kantor Pusat)


Central Site atau pusat dari semua aktivitas jaringan komunikasi data anda, seharusnya merupakan tempat bertemunya semua jenis koneksi WAN yang digunakan oleh pengguna lain. Di sinilah semua jenis koneksi WAN milik perusahaan anda bertemu dan dihubungkan satu dengan yang lainnya. Selain itu, kantor pusat juga sering dijadikan sebagai gateway untuk menuju Internet.


Melihat fungsi ini, lokasi yang termasuk dalam Central Site ini tidak perlu memiliki banyak koneksi WAN, hanya jenis WAN yang menuju Internet atau hanya menunggu jenis WAN apa yang dibutuhkan oleh masing-masing kantor cabang yang ingin menghubunginya.


Untuk jenis WAN yang menuju ke arah Internet, sebaiknya pilihlah media komunikasi WAN yang benar-benar reliable dan berkualitas. Media jenis Leased Line sangat cocok untuk keperluan ini.


### Branch Office (Kantor Cabang)


Kantor cabang merupakan titik yang paling tidak membutuhkan satu jenis media komunikasi WAN untuk dapat menghubungi kantor pusatnya. Untuk itu, pemilihan media WAN di sinilah yang terpenting.


Terdapat cukup banyak pilihan media WAN yang cocok untuk ini, seperti Frame Relay, X.25, ISDN, DSL, Wireless dan Cable Modem.


Untuk kantor cabang yang tidak terlalu jauh dari kantor pusatnya, media **WAN Wireless** merupakan yang paling cocok. Karena media ini cukup fleksibel dan mudah diimplementasikan. Selain itu, biaya murah dan ekonomis.


Untuk kantor cabangnya yang tidak harus selalu terkoneksi 24 jam dengan kantor pusatnya, ISDN merupakan pilihan yang bijaksana karena dial saja kapan anda membutuhkan koneksinya. Harganya pun tidak terlalu mahal dan tidak akan menyia-siakan uang anda untuk koneksi yang tidak terpakai.


Untuk kantor cabang yang harus terkoneksi terus menerus, Frame Relay, X.25, DSL dan Cable Modem merupakan solusi yang tepat karena biaya yang anda bayarkan untuk koneksi 24 jam non stop akan lebih ekonomis menggunakan media-media ini. Kecepatan dan reliabilitasnya pun lebih tinggi dibandingkan media Wireless dan ISDN.


 


[![network topologi](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEj60oINacIdlukLSbqWaKiOxjtCmFB_FVwMP0dpjIqQa70JcehTB51brNX_OGl0yZyWJDsjcAXSnOYk1T7wIYkbMH13pKHBLfDtf4zDDMB6Y51IlNKDYOYI0qCFAWAKzaKxXY-CqRAdv0ZEL7on76t0fKXhO54WOhA2b-zTXHVmD6NV7ILfCXaJzozalQ/w640-h426/wan-infrastructure-management-service-500x500.png)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEj60oINacIdlukLSbqWaKiOxjtCmFB_FVwMP0dpjIqQa70JcehTB51brNX_OGl0yZyWJDsjcAXSnOYk1T7wIYkbMH13pKHBLfDtf4zDDMB6Y51IlNKDYOYI0qCFAWAKzaKxXY-CqRAdv0ZEL7on76t0fKXhO54WOhA2b-zTXHVmD6NV7ILfCXaJzozalQ/s500/wan-infrastructure-management-service-500x500.png)
 


 


**Perangkat Apa Saja Yang Cocok Digunakan Untuk Meladeni Koneksi WAN ?**
------------------------------------------------------------------------


Perangkat juga merupakan salah satu faktor yang perlu anda pertimbangkan dalam memilih teknologi WAN yang ingin digunakan. Selain jaringan komunikasi yang mahal, perangkat yang dapat menghantarkannya ke hadapan anda  juga tidak murah. Maka dari itu, harus di cermati pula pemilihannya.


Untuk lebih memudahkan pemilihan perangkat, berikut ini adalah perangkat-perangkat yang harus disediakan dilihat dari segi penempatannya :


### Central Site (Kantor Pusat)


Karena tugas pada lokasi ini cukup berat, maka perangkat router yang harus ada untuk titik ini adalah perangkat yang memiliki banyak sekali jenis interface. Tujuannya agar dengan sebuah perangkat router saja, semua koneksi dari pengguna dapat dilayani dengan baik. Mengelolanya pun tentu tidak sulit. Untuk itu, sebuah perangkat router harus memiliki jenis interface :


* Interface ISDN PRI/BRI untuk melayani pengguna SOHO ataupun kantor cabang kecil.
* Interface Asynchhronous serial dan modem untuk melayani panggilan dari pengguna rumahan yang menggunakan koneksi Asynchronous (dial up melalui line telepon biasa).
* Interface Serial untuk melayani koneksi Frame Relay dari kantor cabang.
* Interface Serial untuk melayani koneksi leased line menuju ke arah ISP.
* Interface Ethernet yang berguna untuk menghubungkan semua itu dengan jaringan [Wireless LAN]({{ site.baseurl }}{% post_url 2018-07-27-wireless-lan-jadul-namun-tahan-banting %}) yang ada di dalam Central site tersebut. Selain itu, interface Ethernet juga dapat berfungsi melayani koneksi Wireless, ADSL, maupun Cable.


Untuk memenuhi semua kebutuhan ini, perangkat router yang paling cocok adalah perangkat router berjenis modular. Maksudnya, semua interface yang ingin digunakan dibuat dengan sistem per modul, tidak seluruhnya menyatu dengan badan router.


Tujuannya adalah agar dapat dicopot pasang sehingga apa yang dibutuhkan dan apa yang tidak dapat dimodifikasi lebih lanjut. Apa yang kurang dapat anda tambahkan, apa yang kelebihan dapat anda kurangi. Menggunakan router jenis modular sangat menguntungkan pada Central Site ini.


### Branch Office (Kantor Cabang)


Kantor cabang biasanya memiliki karakteristik tidak terlalu banyak membangun koneksi dengan pihak yang lain, kecuali koneksi menuju ke kantor pusat. Karena karakteristiknya yang demikian, maka perangkat router yang digunakan untuk keperluan ini tidaklah harus secanggih dan selengkap apa yang ada di kantor pusat.


Untuk keperluan ini, router yang berjenis modular atau tetap yang bisa digunakan. Interface-interface yang  diperlukan dalam melayani koneksi WAN pada kantor cabang ini adalah :


1. Interface Serial untuk melayani koneksi Frame  
Relay atau leased line. Biasanya koneksi ini merupakan koneksi utama pada kantor cabang. Sebaiknya sediakan lebih dari satu interface jenis ini untuk berjaga-jaga jika rusak.
2. Interface BRI untuk melayani koneksi ISDN BRI. Koneksi ISDN BRI biasanya digunakan di kantor cabang sebagai link back up jika link utamanya sedang bermasalah. Interface ini tidak perlu terlalu banyak, mengingat fungsinya yang hanya sebagai back up saja.


Untuk melayani keperluan ini, router yang cocok digunakan adalah router yang cocok digunakan adalah router modular atau ber-interface tetap. Router berjenis modular diperlukan jika nantinya kantor cabang ini akan berfungsi juga sebagai jembatan penghubung antara kantor-kantor cabang yang lebih kecil lagi dengan kantor pusat.


### Telecommuter Site (Kantor/Pekerja Bergerak)


Pekerja yang sering melakukan mobilisasi atau yang sering menyelesaikan pekerjaannya bukan di kantor yang seharusnya sering disebut dengan istilah pekerja telecommuter. Untuk tetap berhubungan dengan kantor pusat, maka para pekerja jenis ini juga harus disediakan koneksi Internet. Meskipun spesifikasinya tidak perlu terlalu tinggi.


Untuk  itu, media WAN yang paling cocok untuk pekerja ini adalah media yang umum dan mudah ditemukan di mana-mana, serta fleksibel dalam hal penggunaannya. Untuk itu, media seperti ISDN atau asynchronous dial up (dial up yang umum digunakan) sangatlah cocok untuk keperluan ini.


Perangkat-perangkat yang diperlukan adalah sebagai berikut :


1. PC yang dilengkapi dengan modem dial up atau interface serial RS-232 untuk menghubungkan modem eksternal.
2. Interface BRI untuk ISDN BRI.
3. Interface Ethernet untuk berhubungan dengan LAN.


Untuk melayani kebutuhan seperti ini, perangkat router yang cocok adalah yang memiliki interface tetap yang sudah dapat melakukan semuanya untuk para pekerja ini.


Perangkat router yang memiliki interface BRI dan juga asynchronous serial sangat tetap untuk dimiliki. Namun jika anda ingin lebih leluasa berganti-ganti media, cari saja router yang juga memiliki interface ADSL, karena memang sedang ngtren di kalangan pengguna rumahan.


 


[![branch office networking](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEi6WJrdybDJqfYMl0etZVbZOjG2DmuU4WV9mV70Z9p2qxXf1dhkhacEPSCJcogWkM78QlGHiiPTRVeoIsU1zCHVMUPUGHnX16Lf7prMpjJAAYixIO4U_7b-1XgVOBmxldTD2l3z4xGp7i_OrgX23h_Qaxqray7tzZen9Ro578qLwntVwTC1s6cLnxdcSw/w640-h328/Branch%20Office.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEi6WJrdybDJqfYMl0etZVbZOjG2DmuU4WV9mV70Z9p2qxXf1dhkhacEPSCJcogWkM78QlGHiiPTRVeoIsU1zCHVMUPUGHnX16Lf7prMpjJAAYixIO4U_7b-1XgVOBmxldTD2l3z4xGp7i_OrgX23h_Qaxqray7tzZen9Ro578qLwntVwTC1s6cLnxdcSw/s579/Branch%20Office.jpg)
 


 


Jangan Salah Pilih
------------------


Media komunikasi data memang bukan faktor utama dalam berjalannya bisnis anda. Namun jika dipilih secara bijaksana dan tepat, tentu satu problem di dalam jalannya bisnis anda sudah hilang.


Jangan sampai anda memilih media yang memusingkan kepala ketika ingin di gunakan bandwidth tidak cukup atau ketika anda membutuhkannya hanya dalam jangka waktu singkat-singkat saja harga yang dibayar sudah untuk 24 jam pemakaian. Tentu akan sia-sia, bukan ? Maka itu, telitilah dengan cermat jangan sesal kemudian.


Komunikasi dalam Jaringan
-------------------------


Komunikasi dalam jaringan (KDJ) atau yang dikenal dengan istilah “network communication” dalam bahasa Inggris, adalah proses penyampaian informasi atau data dalam sebuah jaringan komputer. KDJ dapat dibagi menjadi dua jenis, yaitu komunikasi simpul-simpul (node-to-node communication) dan komunikasi simpul-sistem (node-to-system communication).  
  
Komunikasi simpul-simpul adalah proses penyampaian informasi di antara simpul-simpul dalam sebuah jaringan komputer, sedangkan komunikasi simpul-sistem adalah proses penyampaian informasi dari sebuah simpul ke sebuah sistem atau perangkat lain di luar jaringan komputer.


KDJ memiliki beberapa komponen utama, yaitu:


1. **Sumber daya komunikasi** (communication resource) Sumber daya komunikasi (communication resource) adalah segala sesuatu yang dibutuhkan untuk melakukan proses penyampaian informasi atau data, seperti komputer, jaringan komputer, perangkat lunak (software), dan lain-lain.
2. **Protokol komunikasi** (communication protocol) Protokol komunikasi (communication protocol) adalah aturan yang mengatur bagaimana data atau informasi akan disampaikan dalam sebuah jaringan komputer.
3. **Media komunikasi (communication media)** Media komunikasi (communication media) adalah segala sesuatu yang digunakan untuk menyampaikan data atau informasi, seperti kabel, nirkabel (wireless), dan lain-lain.
4. **Pengendali akses (access control)** Pengendali akses (access control) adalah segala sesuatu yang mengatur siapa saja yang dapat mengakses sebuah jaringan komputer dan apa yang dapat mereka lakukan.
5. **Keamanan jaringan (network security)** Keamanan jaringan (network security) adalah segala sesuatu yang digunakan untuk menjaga jaringan komputer dari ancaman seperti virus, serangan hacker, dan lain-lain.

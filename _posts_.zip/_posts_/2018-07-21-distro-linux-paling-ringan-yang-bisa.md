---
layout: post
title: Distro linux paling ringan Yang Bisa Anda Coba Tanpa Perlu Di install
date: '2018-07-21T15:13:00.002+07:00'
author: rosari J
tags:
- linux
- sistim operasi
modification_time: '2022-07-12T20:04:34.289+07:00'
blogger_id: tag:blogger.com,1999:blog-7329298365997944344.post-4504101798034091446
blogger_orig_url: https://www.oktrik.com/2018/07/distro-linux-paling-ringan-yang-bisa.html
---

Anda mungkin ingin masuk ke dalam dunia Linux, tetapi merasa tidak mempunyai resource dan waktu untuk menginstalasi operacting system yang sepenuhnya baru. Secara singkat, kita akan melihat konsep booting Linux secara langsung dari CD dan juga beberapa distro linux paling ringan yang di rancang sangat spesifik.


Jadi anda ingin mencoba distribusi linux untuk satu alasan atau yang lain, tetapi tidak ingin menghabiskan waktu untuk menginstalasi ke harddisk hanya untuk mengetahui bahwa Linux sama sekali bukan untuk anda ?


Kali ini, kami punya sesuatu untuk anda. Meskipun telah mempunyai salah satu distribusi terinstalasi pada komputer anda, hal ini juga menarik bagi anda. Karena sangat banyaknya ragam versi Linux yang tersedia, mengapa tidak mencoba salah satu untuk melihat bagaimana perbandingannya dengan instalasi yang anda punya ?


Yang anda butuhkan adalah `live distribution`. Lihat boks untuk mengetahui lebih banyak tentang apa itu live distribution sebenarnya, tetapi ide dasarnya adalah : operating system lengkap yang boot dari disc removable, non rewritable seperti CD atau DVD.


Banyak live distro yang berukuran cukup besar sehingga memerlukan DVD 4 GB penuh, tetapi beberapa juga akan cukup pada satu CD 700 MB. Sebetulnya ada juga distribusi yang dapat boot dari USB flash disk dan beberapa bahkan dapat dijalankan dari floppy.







 [![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiLqc-p3rw15_upo2awNXOJ0SolFiGK7E5KTLxUrmRremjjMqvisZpd8-Y65WdwrKvC_l8iXX3WFdWTtcL2PYUjMp6cDSf58tpBrJmX1VIlr_6Gv5CeuZ99oJ8rnnGsHFUnKreMp7OCBJm8L4ol5kZwC3EGi0uX3nfxQp0mKWdbgnzUF4XnCPFFcGZUqg/w640-h400/linux-1-800x500.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiLqc-p3rw15_upo2awNXOJ0SolFiGK7E5KTLxUrmRremjjMqvisZpd8-Y65WdwrKvC_l8iXX3WFdWTtcL2PYUjMp6cDSf58tpBrJmX1VIlr_6Gv5CeuZ99oJ8rnnGsHFUnKreMp7OCBJm8L4ol5kZwC3EGi0uX3nfxQp0mKWdbgnzUF4XnCPFFcGZUqg/s800/linux-1-800x500.jpg)


Linux Tanpa Install (live CD)
-----------------------------


Distro linux paling ringan yang tidak membutuhkan spesifikasi hardware yang cukup besar dan dapat anda coba tanpa perlu repot repot [menginstall linux secara manual]({{ site.baseurl }}{% post_url 2018-07-19-cara-install-linux-untuk-pemula %}) antara lain







### **Knoppix**


Dari semua live distro yang tersedia, satu yang mungkin paling sering anda dengar adalah Knoppix. Knoppix sangat bersinar dan profesional dan menyertakan banyak hal pada satu CD misalnya, deteksi hardware otomatis untuk berbagai kartu grafis dan kartu suara dan juga range perangkat USB dan SCSI yang baik. Berkat rutin dekompresi yang powerful, Knoppix yang hamper separuh isi DVD bisa diatur supaya muat pada satu CD.


Menurut [situs web Knoppix](http://www.knopper.net/knoppix/index-en.html), anda bisa menggunakan distro tersebut sebagai demo untuk melihat apakah Linux untuk anda atau tidak, sebagai alat pendidikan, atau bahkan sebagai system penolong untuk instalasi distribusi linux yang ada. Kita tahu bahwa beberapa orang membawa CD Knoppix dalam tas laptop miliknya yang digunakan pada waktu Windows tidak dapat melakukan pekerjaannya.


Bahkan seorang ahli jaringan profesional senang menggunakan Knoppix untuk mengonfigurasi router dan hardware lainnya jauh lebih cepat dibanding menginstalasi Windows pada laptopnya. Maksudnya di sini adalah Knoppix sangat fleksibel dan suatu pengenalan yang sangat baik atas gagasan distribusi Linux live paling ringan.







Instalasi linux juga tidak memerlukan hardware yang kokoh dan kuat untuk menggunakan Knoppix. Processor apapun mulai dari 486 ke atas sudah bisa menjalankan mode console yang paling dasar dan RAM 20 MB sudah mencukupi.


Untuk mode grafis yang menggunakan KDE, anda akan memerlukan 96 dan 128 MB, bergantung apakah ingin menggunakan program seperti Open Office atau tidak. Selain itu, anda hanya memerlukan drive CD bootable atau boot floppy untuk menjalankannya.


[![Knoppix linux logo](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjbk_O_jQh5lM1nB2wksx_MyT6G0pxNoHR6m8imiuL3hJjeDZAl-H6NRgItEOW_milPDPi7Q803jqn9jZaOqHb4IKX1Exq0T6FxqdkBdgY351rrwyaxoz0gStsSEfRF6iuR1jx37jppFR0eyRs8LcjzYC0cfDi13KjTO8B3TYzwZtA5fsZqxmc-taym2A/w608-h640/Knoppix_logo.svg.png)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjbk_O_jQh5lM1nB2wksx_MyT6G0pxNoHR6m8imiuL3hJjeDZAl-H6NRgItEOW_milPDPi7Q803jqn9jZaOqHb4IKX1Exq0T6FxqdkBdgY351rrwyaxoz0gStsSEfRF6iuR1jx37jppFR0eyRs8LcjzYC0cfDi13KjTO8B3TYzwZtA5fsZqxmc-taym2A/s1024/Knoppix_logo.svg.png)





### **Gnoppix**


Jika anda adalah seorang pengguna Linux yang bekerja dalam lingkungan KDE, mungkin penasaran dengan Gnome. Dalam hal ini, variasi dari Knoppix (dikenal sebagai Gnoppix) patut untuk dilihat.


Pada dasarnya, Gnoppix mirip dengan Knoppix tetapi lingkungan grafis Gnome bukan KDE. Meskipun bekerja dengan cara yang sama dengan Knoppix, Gnoppix didasarkan pada proyek yang dikenal sebagai ‘Ubuntu Linux”, yang maka mana dirinya sendiri berdasarkan inti Debian. Gnoppix merupakan titik awal yang sangat baik jika anda baru terhadap live distro linux paling ringan, tetapi tidak akrab dengan KDE.


 


[![Gnoppix screenshot](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEg4jf8hec_C4VqLxSLpzm9wPtdA0cYQH8tqBNRgtoCjmvAl9_CjmF3kpLnmYDremxUZ-yHpLuwUFKN7UuMnePPS8sPTpftgZJgIyMF6OusW-l3B5rKFrAuYmafN3HuDrfzOJEMUeJfDn94OufeGdQOj96dWHVnTf4RwvN4wwMeIdC-ZahhbwrmyhFRyDA/w640-h480/gnoppixScreenshot2.png)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEg4jf8hec_C4VqLxSLpzm9wPtdA0cYQH8tqBNRgtoCjmvAl9_CjmF3kpLnmYDremxUZ-yHpLuwUFKN7UuMnePPS8sPTpftgZJgIyMF6OusW-l3B5rKFrAuYmafN3HuDrfzOJEMUeJfDn94OufeGdQOj96dWHVnTf4RwvN4wwMeIdC-ZahhbwrmyhFRyDA/s1024/gnoppixScreenshot2.png)





### [Morphix](https://distrowatch.com/table.php?distribution=morphix)


Morphix merupakan varian lain dari Knoppix, tetapi ditujukan untuk system yang lebih modular. Ini berarti terdapat beragam versi Morphix yang tersedia tergantung kepada keinginan anda atas apa yang akan dilakukan live distro anda.


Sebagai contoh, Morphix hadir dalam versi Game, Gnome dan KDE, termasuk versi grafis yang lebih ringan yang menggunakan IceWM sebagai Windows Manager. Satu hal yang kami suka dari Morphix adalah caranya dalam menempatkan dirinya sendiri.


Instalasi linux Morphix datang dengan disk partition manager grafis dan dapat menginstalasi dirinya ke harddisk sebagai Linux “sebenarnya” jika di kemudian hari anda memutuskan ingin mendalaminya lebih serius.


 


[![Morphix](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgOk7o-cnEvsQbbuJehLzBNqhpry5rTAsaJ4ZKsS-4V_YiC_471X3J4Dc7a3iplsJCZRQk40acXGbanKdjA-HRODS-qyP8rHHUh4PQyS31Hav3IzrIxQQLQmwUt5t07M5Zy5nETmmjPvKAC58rZnVkq30YMwDMmNADLjK-DP6fCmtfgT-p58fuYPwYXDA/w640-h500/Morphix_1.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgOk7o-cnEvsQbbuJehLzBNqhpry5rTAsaJ4ZKsS-4V_YiC_471X3J4Dc7a3iplsJCZRQk40acXGbanKdjA-HRODS-qyP8rHHUh4PQyS31Hav3IzrIxQQLQmwUt5t07M5Zy5nETmmjPvKAC58rZnVkq30YMwDMmNADLjK-DP6fCmtfgT-p58fuYPwYXDA/s648/Morphix_1.jpg)





### **[SUSE Live](https://en.opensuse.org/SDB:Live_USB_stick)**


Tidak semua distribusi linux live berdasarkan varian linux paling ringan yang tidak dikenal. Jika mempunyai minat akan Linux, anda akan tahu tentang SUSE Linux. Sejak versi 6, SUSE juga telah tersedia dalam distribusi live.


SUSE adalah yang pertama dari vendor Linux utama yang merilis Live CD yang bisa di download dengan Cuma-Cuma. Karena SUSE adalah satu-satunya distro utama yang tidak bisa di download dengan Cuma-Cuma secara keseluruhan, live CD berguna sebagai demo dari versi lengkap.


Tidak seperti yang lain, instalasi linux SUSE Live memerlukan harddisk supaya dapat berjalan, meskipun tidak sebanyak yang di instalasi secara lengkap. Sebesar apapun menyukai versi lengkapnya, kami tidak bisa merekomendasikan linux paling ringan sebagai apapun selain dari satu demo, karena ia terbukti terlalu membatasi jika dibandingkan dengan Knoppix.


 


[![Logo Open Suse](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgFipnffNRtGuGv8mhokstz1TFohJOk4KcnkS4xL-t0yFcZO8HX5c6ttUpgPbKOG4tmeTbuaFs9_xn2F_7Q9x47b1zei4-UWcy7r7wQcRnVjnnGbAor671t-t65tric5FmG2HTkxUk3Ll2d7taFRc6OHrPzb1OB-IolImxuYvZP4d8wb9xlKmLqfh-wAQ/w640-h406/1200px-OpenSUSE_official-logo-color.svg.png)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgFipnffNRtGuGv8mhokstz1TFohJOk4KcnkS4xL-t0yFcZO8HX5c6ttUpgPbKOG4tmeTbuaFs9_xn2F_7Q9x47b1zei4-UWcy7r7wQcRnVjnnGbAor671t-t65tric5FmG2HTkxUk3Ll2d7taFRc6OHrPzb1OB-IolImxuYvZP4d8wb9xlKmLqfh-wAQ/s1200/1200px-OpenSUSE_official-logo-color.svg.png)





### **[DamnSmall Linux](http://www.damnsmalllinux.org/)**


Cukup mengejutkan , beberapa distribusi bahkan bisa muat dalam ruang yang lebih kecil. Jika pernah melihat CD “kartu nama” yang berbentuk segi empat, anda mungkin heran apa manfaat mereka.


Inilah jawabannya : Damn Small Linux (DSL) muat di situ, instalasi linux dengan RAM hanya 48 MB ! Dibuat oleh John Andrew dari California, DSL dimaksudkan untuk menjad distribusi linux segala keperluan yang sederhana yang dapat dibawa di dalam dompet bersama kartu kredit anda, dan ia benar-benar bisa bekerja dengan baik.


Kesimpulan
----------


Meskipun tidak bisa bersaing dengan Knoppix sebagai distribusi linux “serius”. Meskipun dimaksudkan untuk itu DSL datang dengan lingkungan grafis bersama dengan tool untuk e-mail, pengolahan data, dan bahkan main musik.


Selain live distro linux paling ringan untuk keperluan umum, live distro untuk keperluan khusus juga ada, seperti Linux untuk mereka yang ingin mengedit musik dan video, semua dari satu disc.



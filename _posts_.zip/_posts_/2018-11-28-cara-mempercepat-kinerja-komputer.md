---
layout: post
title: Cara Mempercepat Kinerja Komputer dengan Disable Windows StartUp
date: '2018-11-28T18:11:00.002+07:00'
author: rosari J
tags:
- start up
- windows
- registry
modification_time: '2022-07-10T18:13:24.445+07:00'
blogger_id: tag:blogger.com,1999:blog-7329298365997944344.post-5789047184907994199
blogger_orig_url: https://www.oktrik.com/2018/11/cara-mempercepat-kinerja-komputer.html
---

Seperti yang kita ketahui semakin banyak kita menginstal aplikasi pada komputer yang kita miliki entah itu pada sebuah laptop maupun Personal Computer, maka semakin lama pula Sistim OS untuk melakukan start up.

Banyak dari aplikasi tersebut secara otomatis masuk kedalam daftar start up windows setelah kita menginstalnya tanpa kita menyadarinya. hal ini lah salah satu penyebab lamanya windows untuk melakukan start up secara menyeluruh atau sering kita kenal dengan istilah "windows yang lemot"

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjnKZnY74pdXbSgsS7bcd6qCpW4vw16x59SMtlq_TjC8A3TM6pm71DktYLeHSSnV1Y1UkiswSKcWBXeSOkbBWCcZYPA9rGoNQCnwaQS1FTcc8Be0Y0_uIHp1N7iGEEgEyCsoWprWHpJlJh7Vb8lv38zsQCKrJJJrt_0vJP3qiIwZj2422-TCUuWlYuS0w/w640-h400/start-1-800x500.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjnKZnY74pdXbSgsS7bcd6qCpW4vw16x59SMtlq_TjC8A3TM6pm71DktYLeHSSnV1Y1UkiswSKcWBXeSOkbBWCcZYPA9rGoNQCnwaQS1FTcc8Be0Y0_uIHp1N7iGEEgEyCsoWprWHpJlJh7Vb8lv38zsQCKrJJJrt_0vJP3qiIwZj2422-TCUuWlYuS0w/s800/start-1-800x500.jpg)  
 Windows Start Up Yang Menumpuk
------------------------------

Meski jika terlalu banyak program yang masuk Kedalam daftar Windows Start Up, Namun ada beberapa aplikasi penting yang memang sebaiknya tetap dalam daftar windows Start up, Seperti Aplikasi Anti Virus Dan Program Firewall sehingga Komputer anda tetap terlindungi dari serangan virus ataupun program jahat lainnya.

Namun beberapa aplikasi sehari hari yang jarang kita gunakan sering kali masuk kedalam Daftar start up windows yang mengakibatkan OS membutuhkan daya dan waktu yang lama hal ini dikarenakan Windows akan berusaha untuk Meload semua program tersebut. Dari beragam artikel dan cara mempercepat windows 7 yang terdapat di internet, kita akan menggunakan cara yang simple namun efektif

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjBg4DGlwglmS9Mn32_0UDWbFRqlUHPdtmQvF40oJm3tkoXHnd2DF4bUM0yRzQsSky3g2cdiRJlmaw_FcsL6I_aCYrfmSgiX7rG0B3i7EICRBeEx0gyG4Ta4AvJDES9MmLeWEGzZ5cfoUPzLts9pp-sAxu9WIRyfC0IPBhc-DuTnwZmDM8o7SwGWGLoIg/w640-h426/msconfig.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjBg4DGlwglmS9Mn32_0UDWbFRqlUHPdtmQvF40oJm3tkoXHnd2DF4bUM0yRzQsSky3g2cdiRJlmaw_FcsL6I_aCYrfmSgiX7rG0B3i7EICRBeEx0gyG4Ta4AvJDES9MmLeWEGzZ5cfoUPzLts9pp-sAxu9WIRyfC0IPBhc-DuTnwZmDM8o7SwGWGLoIg/s587/msconfig.jpg)  
 **Mempercepat Windows Start Up menggunakan Msconfig**
-----------------------------------------------------

Untuk mengontrol program program yang tidak kita perlukan tersebut, Windows Mempunyai sebuah Program bawaan yang cukup berguna.

Program Ini disebut `MSconfig`, melalui MSconfig Pengguna dapat mengatur program apa saja yang akan kita hapus dari daftar [windows start up](https://www.oktrik.com/cara-menambahkan-aplikasi-kedalam.html) sehingga akan mempercepat kinerja komputer secara keseluruhan. Secara default, Msconfig tersedia hampir diseluruh Microsoft Windows OS seperti Windows 7, 8 ,vista dan Microsoft XP

Untuk Mengakses Msconfig, caranya adalah dengan menekan Logo `Windows+R` pada keyboard kita setelah itu jalankan Msconfig dengan mengetik `MSCONFIG` dan tekan enter. setelah itu Jendela system configuration Akan terbuka.

Pada Opsi Tab Start up Selection pilih menu `Selective Startup` kemudian pada Opsi Tabs `Startup` Hilangkan centang pada program yang tidak kita kehendaki untuk diload saat windows dihidupkan Klik Aply. Cara ini cukup ampuh untuk mempercepat windows karena tidak semua program berjalan dibackground

 

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEg1DTwCwtvweyTffee4ku2MIveSJT-O5yaeilsqQ_78KxWMxDlcFK9LIit78pB8zagmIuPNsWuXqOws7_yBFZAdJS4FdyCQ4v1uHO41h0p22JTfzvJA-1Usbs0TEpAHuSCiUlo4Hlm4WJSF30JHHoiF9Q27xgrv9OuAvPGfOTJdMPFrw7iKcRTgwFIOHQ/w640-h418/msconfig1.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEg1DTwCwtvweyTffee4ku2MIveSJT-O5yaeilsqQ_78KxWMxDlcFK9LIit78pB8zagmIuPNsWuXqOws7_yBFZAdJS4FdyCQ4v1uHO41h0p22JTfzvJA-1Usbs0TEpAHuSCiUlo4Hlm4WJSF30JHHoiF9Q27xgrv9OuAvPGfOTJdMPFrw7iKcRTgwFIOHQ/s582/msconfig1.jpg)  
**Mempercepat Windows Dengan Menggunakan CCleaner**
---------------------------------------------------

Ccleaner adalah Program Utility Windows Freware atau aplikasi gratisan Yang tersedia hampir untuk semua platform Windows, Meski Gratis tapi aplikasi atau program ini mempunyai banyak kegunaan. Mulai dari membersihkan `Registry`, Uninstall Program dari system, `defrag windows`, `System restore` dan lain lain.

Namun fitur Ccleaner yang akan kita gunakan kali ini adalah Fitur Manage `startup`, Caranya cukup mudah Pada interface Ccleaner pilih menu Option dan Sorot atau klik pada menu `startup` setelah itu hampir serupa dengan Cara mempercepat kinerja laptop atau Komputer dengan Msconfig yaitu tinggal kita pilih program yang tidak kita kehendaki dan klik disable

 


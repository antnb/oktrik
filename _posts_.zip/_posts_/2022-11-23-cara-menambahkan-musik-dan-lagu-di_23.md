---
layout: post
title: cara menambahkan musik dan lagu di instagram story
date: '2022-11-23T13:32:00.001+07:00'
author: rosari J
tags:
- instagram
modification_time: '2022-11-23T13:32:10.898+07:00'
blogger_id: tag:blogger.com,1999:blog-7329298365997944344.post-1258078584670909690
blogger_orig_url: https://www.oktrik.com/2022/11/cara-menambahkan-musik-dan-lagu-di\_23.html
---

Instagram atau IG merupakan sebuah aplikasi yang memungkinkan penggunanya untuk mengabadikan moment dan berbagi foto atau video. Selain itu, Instagram juga memungkinkan penggunanya untuk mengikuti akun tertentu dan melihat foto atau video yang telah diunggah oleh akun tersebut.


[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEi2GH61wc-OlH5V3UW-O8fHoVW9m07igDsnKf35lSHSU-cR3_BwUDsah6a9oC4LWRg6x3NFtvgG8WfGAFIjPuo236mxw7hyvWL2z1oKNkXPJXcQFfRwX452d3sPAt6MUgq7LlWprp_2wKgcZYOkLTLnOdE0xsCWl4OWjhsKNqrexjOxp7S7Wh5TD3CCfA/s400/instagram%20story.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEi2GH61wc-OlH5V3UW-O8fHoVW9m07igDsnKf35lSHSU-cR3_BwUDsah6a9oC4LWRg6x3NFtvgG8WfGAFIjPuo236mxw7hyvWL2z1oKNkXPJXcQFfRwX452d3sPAt6MUgq7LlWprp_2wKgcZYOkLTLnOdE0xsCWl4OWjhsKNqrexjOxp7S7Wh5TD3CCfA/s1191/instagram%20story.jpg)
Apa itu story IG?
-----------------


Instagram Stories adalah fitur Instagram yang memungkinkan pengguna untuk mengirimkan sebuah foto atau video yang akan hilang setelah 24 jam. Foto atau video yang dikirimkan melalui Instagram Stories dapat dilihat oleh semua orang yang mengikuti Anda, dan mereka dapat meninggalkan sebuah komentar jika mereka ingin.


Untuk membuat sebuah cerita, cukup buka aplikasi Instagram Anda dan tekan tombol "+" di bagian atas layar. Anda akan melihat opsi untuk membuat sebuah cerita di samping opsi untuk membuat sebuah postingan biasa. Ketika Anda memilih untuk membuat sebuah cerita, Anda akan diminta untuk mengambil sebuah foto atau video atau untuk mengambil salah satu dari koleksi foto atau video Anda yang telah Anda simpan di perangkat Anda.


Setelah Anda mengambil atau memilih sebuah foto atau video, Anda dapat menambahkan teks, stiker, atau filter untuk menyesuaikan postingan Anda. Beberapa filter yang tersedia hanya untuk cerita, seperti filter "lensa kaca". Anda juga dapat memutar atau membalikkan foto atau video dengan menggesernya ke kiri atau ke kanan.


Ketika Anda selesai mengedit postingan Anda, tekan tombol "Selesai" di bagian bawah layar. Anda akan diminta untuk memilih siapa yang akan melihat postingan Anda. Anda dapat memilih untuk menampilkan postingan Anda hanya kepada teman-teman Anda, hanya kepada orang-orang yang Anda ikuti, atau kepada semua orang.


Setelah Anda memilih siapa yang akan melihat postingan Anda, tekan tombol "Bagikan" dan postingan Anda akan langsung ditampilkan di feed Instagram Anda. Sama seperti postingan biasa, postingan dalam Instagram Story Anda akan hilang setelah 24 jam.


Jadi, jika Anda ingin berbagi sesuatu yang tidak akan terlihat lagi setelah beberapa hari, Instagram Story adalah pilihan yang tepat untuk Anda.


Cara Menambahkan Lagu ke Story IG
---------------------------------


Untuk menambahkan lagu ke story Anda, Anda perlu mengakses aplikasi Instagram dan menemukan ikon kamera di bagian bawah layar. Kemudian, Anda perlu menekan tombol story di samping ikon kamera untuk memulai proses pembuatan story.


Setelah itu, Anda akan melihat opsi untuk menambahkan lagu ke story Anda. Untuk melakukannya, Anda perlu menekan tombol music yang berada di samping ikon kamera.


Pada halaman music, Anda akan melihat daftar lagu yang tersedia. Anda dapat memilih lagu sesuai keinginan Anda dan menekan tombol play untuk memutarnya.


Setelah itu, Anda akan melihat video story Anda yang sedang diputar sambil bersamaan dengan lagu yang Anda pilih. Anda dapat menambahkan beberapa efek untuk video Anda sebelum menambahkannya ke story Anda.


Jika Anda puas dengan hasilnya, Anda dapat menekan tombol share untuk menambahkannya ke story Anda. Selain itu, Anda juga dapat mengirimkannya ke teman atau keluarga Anda melalui aplikasi seperti WhatsApp atau Facebook Messenger.


Cara membuat story IG yang menarik dengan lagu:
-----------------------------------------------


Sebuah story Instagram yang menarik tentang sebuah lagu akan selalu mencari cara untuk membuatnya lebih hidup. Untuk membuat story IG yang menarik, Anda perlu untuk terlebih dahulu memilih sebuah lagu yang akan menjadi tema dari story Anda. Pilihlah lagu yang memiliki irama yang menarik dan Anda sukai.


Setelah itu, buatlah sebuah video singkat dengan lagu tersebut sebagai temanya. Anda bisa mengambil video dari aplikasi musik atau video YouTube. Jangan lupa untuk menambahkan beberapa teks di atas video untuk menunjukkan apa yang Anda pikirkan tentang lagu tersebut.


Ketika sudah selesai, unggah video tersebut ke akun Instagram Anda. Jangan lupa untuk menambahkan beberapa hashtag yang berkaitan dengan lagu tersebut. Hal ini akan membantu orang lain untuk menemukan story Anda.


Anda juga bisa membagikan story Anda ke dalam grup atau ke teman-teman Anda. Jadi, mereka juga bisa menikmati video yang Anda unggah.


Bagaimana cara membuat story IG yang keren?
-------------------------------------------


Pertama, Anda perlu memilih gambar atau video yang akan menjadi bagian dari story Anda. Gambar atau video yang Anda pilih haruslah menarik dan berkesan. Jika Anda tidak memiliki gambar atau video yang cocok, Anda bisa mencari di internet atau mengunduh beberapa aplikasi pembuat gambar.


Kedua, setelah memilih gambar atau video, Anda perlu menambahkan teks atau caption untuk story Anda. Teks atau caption yang Anda tambahkan haruslah menarik dan berkesan. Jika Anda tidak tahu bagaimana cara menambahkan teks atau caption yang menarik, Anda bisa mencari di internet atau mengunduh beberapa aplikasi pembuat teks.


Ketiga, Anda perlu menambahkan beberapa efek pada story Anda. Efek yang Anda tambahkan haruslah menarik dan berkesan. Jika Anda tidak tahu bagaimana cara menambahkan efek, Anda bisa mencari di internet atau mengunduh beberapa aplikasi pembuat efek.


Anda juga bisa menambahkan beberapa sticker atau emoji pada story Anda. Sticker atau emoji yang Anda tambahkan haruslah menarik dan berkesan. Jika Anda tidak tahu bagaimana cara menambahkan sticker atau emoji, Anda bisa mencari di internet atau mengunduh beberapa aplikasi pembuat sticker atau emoji.


Terakhir, Anda perlu menyimpan atau publish story Anda. Jika Anda tidak tahu bagaimana cara menyimpan atau publish story Anda, Anda bisa mencari di internet atau mengunduh beberapa aplikasi pembuat story.


Penutup
-------


Jadi, sekarang Anda tahu bagaimana untuk menambahkan lagu ke story Instagram Anda. Semoga artikel ini membantu Anda dalam menambahkan lagu ke story Instagram Anda.


---
layout: post
title: Cara Mengetahui Password Wifi di Android dan Windows
date: '2018-10-27T14:40:00.008+07:00'
author: rosari J
tags:
- wireless
- internet
modification_time: '2023-01-15T20:28:41.570+07:00'
blogger_id: tag:blogger.com,1999:blog-7329298365997944344.post-2731746351076965540
blogger_orig_url: https://www.oktrik.com/2018/10/cara-mengetahui-password-wifi.html
---

Perlu kata sandi Wi-Fi atau mungkin Pernah lupa password wifi untuk wireless akses point ? Mungkin anda sedang mengunjungi rumah teman, dan Anda ingin mengetahui password wifi tetangga yang belum terhubung. Atau laptop Anda terhubung ke jaringan internet via wifi yang ada, namun ponsel Anda tidak.


Memang terdapat cara mengetahui password wifi secara nirkabel antar perangkat, tetapi jika itu bukan pilihan, berikut Cara Melihat Password Wifi Yang Terkunci dari perangkat Anda yang sudah terhubung Wifi adalah salah satu fitur konektivitas wireless yang secara standar tersedia di tiap perangkat android, termasuk di HP


Baik itu yang menggunakan OS android terbaru atau bahkan Android Dengan OS lama, Jaringan Wi-fi adalah salah satu konektivitas wireless populer kedua setelah jaringan GPRS (GSM atau CDMA)


Dan seiring waktu mungkin Smartphone anda telah terhubung dengan banyak jaringan wi-fi lewat akses point. baik itu Hotspot wifi sekolah, kantor, Bandara, Rumah teman dan banyak tempat lainnya yang sering tersedia akses wifi


Biasanya akses point ini diproteksi dengan password dan setiap kali anda mengetik password tersebut perangkat Android Anda menyimpannya untuk disimpan dengan aman dan akses mudah di kemudian hari


Apakah Anda menggunakan Wi-Fi di satu perangkat tetapi tidak dapat mengingat kata sandi di perangkat lain? Di Windows, macOS, iOS, dan Android, berikut langkah dan cara mengetahui password wifi, termasuk cara mengetahui password wifi tetangga yang belum terhubung dan cara melihat password wifi yang terkunci.







[![internet caffe wifi password](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjUtdeBh3lH1DtibtAcTdKcvihdLym4y7RE6og9bCDxdjFxlQBxq5yQZlKYDmgu_o5gs3ghfAgBSvf8zInWUk0zf9KQ_8qNWz_J6H21wVafeGfynmY8SX21xhGC5LYXTDyU1MRiJftZmzPNS-7DSLAre9L6UvlNKhgQyM7PvqrZj65WKfGpBp09MMDkxw/w640-h426/password_wifi-1.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjUtdeBh3lH1DtibtAcTdKcvihdLym4y7RE6og9bCDxdjFxlQBxq5yQZlKYDmgu_o5gs3ghfAgBSvf8zInWUk0zf9KQ_8qNWz_J6H21wVafeGfynmY8SX21xhGC5LYXTDyU1MRiJftZmzPNS-7DSLAre9L6UvlNKhgQyM7PvqrZj65WKfGpBp09MMDkxw/s1275/password_wifi-1.jpg)





Cara Melihat Kata Sandi Wi-Fi di Windows
----------------------------------------


Selama Anda saat ini terhubung ke jaringan yang bersangkutan, Windows membuat ini sederhana. Cari Status Jaringan di menu Mulai, lalu pilih tombol Ubah Opsi Adaptor di panel pengaturan. (Jika Anda menggunakan Windows 7, buka Jaringan dan `Internet > Koneksi Jaringan` di Panel Kontrol.)


Pilih `Status > Wireless Properties` dari menu klik kanan adaptor Wi-Fi komputer Anda dalam daftar. Anda akan melihat kotak kata sandi dengan titik-titik di dalamnya di bawah tab Keamanan; klik tombol Show Characters untuk melihat password dalam bentuk biasa.


Segalanya menjadi sedikit lebih rumit jika Anda mencoba melihat kata sandi untuk jaringan yang saat ini tidak terhubung dengan Anda. Pada situasi ini, Cara mengetahui password wifi dapat menggunakan aplikasi pihak ketiga seperti Magical JellyBean WiFi Password Revealer untuk melihat semua kredensial jaringan yang Anda simpan.







Anda bisa mendapatkan kata sandi melalui `Command Prompt Windows` jika Anda tidak ingin menginstal aplikasi lebih lanjut. Cari Command Prompt di Start Menu, klik kanan, dan pilih `Run As Administrator`. Kemudian, untuk menampilkan daftar jaringan Wi-Fi yang disimpan, gunakan perintah berikut:


`netsh wlan show profile`


Pilih jaringan dari daftar dan kemudian ketik perintah ini ke interface CMD:


`netsh wlan show profile MyNetwork key=clear`


(Masukkan nama jaringan yang Anda temukan sebelumnya sebagai pengganti MyNetwork.) Anda akan diberikan informasi jaringan tertentu, termasuk "Key Content", atau kata sandi.







Bagaimana cara mengetahui kata sandi WiFi di ponsel saya?
---------------------------------------------------------


Cara mengetahui password wifi tanpa aplikasi pada ponsel yang menjalankan Android 10 atau lebih tinggi. Cara mengetahui password wifi tidaklah rumit, buka Pengaturan untuk melihat kata sandi WiFi. Ketuk WiFi setelah mencari Jaringan & Internet. Jaringan WiFi Anda saat ini akan berada di bagian atas daftar. Untuk melihat opsi jaringan, pilih sekali diperlukan.


Pilih tombol Bagikan dari menu tarik-turun. Untuk melanjutkan, Anda harus memvalidasi wajah/sidik jari Anda atau memasukkan kode PIN Anda. Setelah Anda menyelesaikan langkah-langkahnya, Anda akan menemukan kata sandi Wi-Fi jaringan Anda tercantum di bawah kode `QR`.







### Wifi Security


Keamanan nirkabel/Wifi Security adalah Fitur untuk Mencegah akses tidak sah atau kerusakan pada komputer atau data menggunakan jaringan nirkabel. Baik [WPA](#WPA) dan WPA2 mampu untuk mengamankan jaringan Internet nirkabel dari akses yang tidak diinginkan


WPA: Wi-Fi Protected Access. Standar keamanan bagi pengguna perangkat komputasi yang dilengkapi koneksi internet nirkabel untuk mengenkripsi data melalui Wi-Fi yang meningkatkan keamanan [[1]](#footnote-1). Anda juga akan melihat WPA2 - ide yang sama, tetapi standar yang lebih baru.


* Password WPA atau Kunci Keamanan: Adalah kata sandi untuk menghubungkan jaringan nirkabel ke perangkat yang ingin anda gunakan [[2]](#footnote-2). Password WPA juga disebut Password Wifi Dikalangan masyarakat secara umum, Kunci WEP, atau Frasa Sandi WPA / WPA2.
* WEP: Wired Equivalent Privacy. Ini adalah standar keamanan untuk Wi-Fi, tetapi meskipun digunakan secara luas, ini adalah yang paling tidak aman dari semuanya[[3]](#footnote-3). Cari WPA atau WPA2 sebagai gantinya.







Namun permasalahannya disini adalah walaupun telah tersimpan dalam perangkat android anda, Anda tidak dapat melihat kata sandi Wi-Fi yang disimpan pada perangkat Anda.


Mungkin Anda ingin menghubungkan perangkat kedua ke salah satu jaringan ini, atau Anda bersama teman yang ingin masuk ke hotspot yang sama namun anda lupa akan password wifi tersebut sehingga anda tidak akan bisa menyambungkan perangkat kedua tersebut karena tidak tau passwordnya. perangkat kedua ini bisa berupa PC, Laptop ataupun perangkat elektronik yang mempunyai konektivitas Via jaringan Wi-Fi







### Instal Aplikasi Password Wifi


Aplikasi Wifi ini dikembangkan oleh Alexandros Schillings dengan nama WiFi Key Recovery , dan tersedia di Google Play Store secara gratis. Ketik WiFi Key Recovery pada kolom pencarian di Google playstore untuk menginstallnya nanti anda akan diarahkan menuju halaman download. Jangan lupa untuk memeriksa apakah apakah perangkat anda telah disupport oleh wifi key recovery


Namun tidak perlu cemas karena telah tersedia aplikasi khusus smartphone android yang secara langsung bisa melihat profile Wi-fi berikut password yang tersimpan di perangkat android anda dan bisa langsung anda install melalui google playstore dengan kata kunci [WiFi Key Recovery](https://play.google.com/store/apps/details?id=aws.apps.wifiKeyRecovery) oleh pengembang Alexandros Schillings. aplikasi recovery password wi-fi ini Gratis







### Wifi warden


WiFi Warden adalah aplikasi networking yang memungkinkan Anda dengan cepat memeriksa informasi penting tentang jaringan WiFi yang Anda sambungkan. Jika Anda menduga ada masalah dengan koneksi Anda, Anda dapat memeriksa apa yang terjadi dengannya kapan saja dan memastikannya aman.


Anda selalu dapat memeriksa produsen modem, enkripsi dan keamanan, frekuensi dan saluran yang Anda gunakan, jarak antara Anda dan router dan daya yang diakibatkannya, dan bahkan nama dan alamat titik akses yang Anda gunakan menggunakan aplikasi ini. Jika Anda ingin memastikan jaringan WiFi yang Anda sambungkan aman, baik di rumah atau di kantor, perpustakaan, atau di tempat lain, ini berguna.


Selain semua pilihan berharga ini, Anda dapat lebih meningkatkan keamanan dengan membuat kata sandi yang sulit ditebak dan kecil kemungkinannya untuk didekripsi. Temukan semua yang dapat dilakukan WiFi Warden untuk Anda, memberikan Anda ketenangan pikiran saat menjelajahi web sepuasnya.







Melihat Sandi Wi-Fi Yang Tersimpan
----------------------------------


Setelah terinstal, Maka cara mengetahui password wifi sangat mudah anda cukup Jalankan aplikasi password wifi tadi untuk melihat password akses point yang tersimpan pada perangkat android anda. secara otomatis aplikasi ini akan meminta akses secara full terhadap perangkat anda (superuser), ketuk "`Grant`" atau izinkan pada popup yang muncul,setelah itu maka aplikasi password wifi ini akan memunculkan semua profile wifi berikut passwordnya.


Namun perlu dicatat apabila perangkat anda telah terhubung dengan banyak wifi, maka akan sulit mencari profile yang anda cari. untuk memudahkan pencarian maka anda dapat menggunakan menu "SSID Quicksearch"







Secara garis besar cara mengetahui password wifi hanya itu saja yang perlu anda lakukan untuk melihat password wifi tersebut, anda dapat melakukan hal tersebut langsung dari perangkat android anda tanpa memerlukan bantuan dari perangkat lain seperti PC, laptop atau smartphone lainnya.


Selain itu aplikasi ini tidak hanya bisa untuk melihat password wifi, namun anda bisa melakukan export daftar profile wifi tadi kedalam format text dan dari sini bisa anda teruskan untuk disimpan ke media penyimpanan yang anda kehendaki








Referensi
---------


[1] Editor, CSRC Content. *Wi-Fi Protected Access-2 (WPA2) - Glossary | CSRC*. https://csrc.nist.gov/glossary/term/wi\_fi\_protected\_access\_2. Accessed 14 May 2021.


[2] *Wi-Fi Protected Access (WPA)*. https://www.oit.va.gov/Services/TRM/StandardPage.aspx?tid=5316. Accessed 14 May 2021.


[3] “What Is Wired Equivalent Privacy (WEP)?” *Fortinet*, /resources/cyberglossary/wired-equivalent-privacy-wep. Accessed 14 May 2021.



 


Last Updated: 



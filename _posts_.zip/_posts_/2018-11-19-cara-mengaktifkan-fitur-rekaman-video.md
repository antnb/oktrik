---
layout: post
title: Cara Mengaktifkan Fitur Rekaman Video 4K UHD Pada Redmi Note 5 Pro
date: '2018-11-19T14:27:00.001+07:00'
author: rosari J
tags:
- redmi
- android
- video
modification_time: '2022-07-10T14:29:04.145+07:00'
blogger_id: tag:blogger.com,1999:blog-7329298365997944344.post-4025141329379012724
blogger_orig_url: https://www.oktrik.com/2018/11/cara-mengaktifkan-fitur-rekaman-video.html
---

Redmi Saat ini adalah Salah Satu merk smartphone yang paling dicari oleh Para penggila gadget tanah air,hal ini dikarenakan selain Kaya Akan fitur smartphone ini juga dijual dengan kisaran harga yang relatif terjangkau.

Namun begitu tidak menjadikan smartphone ini murahan karena begitu diluncurkan, hardware atau sparepart yang digunakan rata rata tidak menggunakan hardware yang asal asalan sehingga rata rata umurnya biasanya lama atau tidak cepat rusak.

Setiap varian smartphone yang diluncurkan oleh perusahaan ini biasanya berada diposisi 10 besar Salam hal penjualan Dan fitur yang ditawarkan .Dalam artikel ini kita Akan mengulas *Cara Dan tips untuk mengaktifkan fitur rekaman video 4k uhd pada ponsel redmi note 5 pro*

Spesifikasi Dan Keunggulan Redmi Note 5 Pro
-------------------------------------------

Varian terbaru pada kelas menengah keatas asalan [redmi note 5 pro](https://www.gsmarena.com/xiaomi_redmi_note_5_pro-8893.php). Redmi note 5 pro mendapat sambutan yang hangat dikalangan Para pecinta gadget. Pada model ini user dimanjakan dengan fitur fitur terkini yang disematkan pada smartphone ini yang ditunjang dengan kualitas hardware yang mumpuni yang membuatnya mampu untuk bersaing dengan merk merk papan atas dikelasnya.

Namun Ada Satu kelemahan yang terdapat pada **redmi note 5 pro** yang dikeluhkan oleh Para penggunanya yaitu minimnya support rekaman video 4K UHD. Meskipun redmi note 5 pro susah Kaya Akan fitur, namun Secara resmi smartphone ini tidak support melakukan rekaman video dalam mode 4K Dan untuk mengaktifkan mode video recording dengan kualitas 4K UHD Ada beberapa langkah yang terlebih dahulu mesti kita lakukan

Seperti yang kita ketahui Redmi Note 5 Pro tidak support untuk melakukan rekaman video dengan kualitas 4K meskipun hardware yang terdapat dalam smartphone ini mampu untuk melakukan hal itu, namun tidak anda temukan opsi untuk mengaktifkan nya.

User di Forum XDA developer [Vidhanth](https://forum.xda-developers.com/m/vidhanth.5514501/) telah berhasil menemukan cara untuk membuat Redmi Note 5 Pro Support Untuk melakukan rekaman Video dengan kualitas 4K. cara nya adalah sebagai berikut harap di ingat Perangkat smartphone wajib telah di root terlebih dahulu

[![Fitur Rekaman Video 4K UHD](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgvvQNS5hFsu-jdQ67P51v1wfXzTrCIZ0OFUpuLShlUDTuCxQfD1hfBZ5L6jnkXYhoevrVfjM83BiQGc3QdfErHlniuIMBpG8DzaYo3BzUeYVGSflYC_RRFzPX_-bz_UbCGr1GdotzBouJuFVXnA_lvI5LSDKmTm4a7z5owCdLPvBTAzdDhn3BWnsnHcQ/w640-h400/redmi-1-800x500.jpg "Rekaman Video 4K UHD")](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgvvQNS5hFsu-jdQ67P51v1wfXzTrCIZ0OFUpuLShlUDTuCxQfD1hfBZ5L6jnkXYhoevrVfjM83BiQGc3QdfErHlniuIMBpG8DzaYo3BzUeYVGSflYC_RRFzPX_-bz_UbCGr1GdotzBouJuFVXnA_lvI5LSDKmTm4a7z5owCdLPvBTAzdDhn3BWnsnHcQ/s800/redmi-1-800x500.jpg)  
 Aktivasi menggunakan Root File MANAGER
--------------------------------------

* Buka aplikasi file manager dengan terlebih dahulu diberikan akses root terhadap file system
* Browse ke folder */system/etc/device\_features/*
* dalam folder ini edit file *whyred.xml* dan cari line support\_camera\_4k\_quality
* untuk mengaktifkan mode video 4K, rubah nilai pada line tersebut menjadi TRUE

### Mengaktifkan menggunakan module magisk

* download [module ini](https://drive.google.com/file/d/1OEU9xMqCNRqNLv-Z2TT472dDRB8Lf35f/view?usp=drive_open) dan simpan ke penyimpanan telepon
* kemudian buka aplikasi magisk pada perangkat smartphone
* ketuk menu ikon dan pilih "module"
* browse ke module yang telah anda download sebelumnya
* tunggu hingga proses instalasi selesai
* Reboot Redmi note 5 pro anda

Pada tahap ini trik atau **cara untuk mengaktifkan mode video 4K UHD** telah selesai dan dapat langsung anda coba. Buka aplikasi kamera dan pilih menu seting video quality maka akan tersedia opsi tambahan "UHD 4K"


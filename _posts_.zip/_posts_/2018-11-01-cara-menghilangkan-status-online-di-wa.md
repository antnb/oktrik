---
layout: post
title: Cara Menghilangkan Status Online Di WA
date: '2018-11-01T14:37:00.001+07:00'
author: rosari J
tags:
- pesan
- image
- privacy
- whatsapp
- accesibility
- android
modification_time: '2022-07-10T14:39:59.681+07:00'
blogger_id: tag:blogger.com,1999:blog-7329298365997944344.post-4225814202714971578
blogger_orig_url: https://www.oktrik.com/2018/11/cara-menghilangkan-status-online-di-wa.html
---

Whatsapp adalah salah satu aplikasi messaging paling populer untuk perangkat ponsel pintar baik itu ponsel android ataupn IOS, dengan whatsapp kita dapat bertukar pesan dan berkomunikasi dengan siapapun baik dengan keluarga,teman ataupun rekan sejawat.

Berbeda dengan olah pesan tradisional seperti menggunakan MMS,SMS ataupun panggilan telepon konvensional, dengan whatsapp memungkinkan kita untuk mengolah pesan dengan beragam format seperti pesan text standar,mengirim gambar atau video atau bahkan melakukan panggilan video secara langsung. dan semua ini tanpa menggunakan biaya apapun selama ponsel kita memunyai akses internet

Namun begitu terkadang beberapa orang pengguna whatsapp ingin mendapatkan kontrol privacy lanjutan seperti notifikasi "last seen" atau kapan terakhir pengguna tersebut terlihat atau online.

Pada versi build yang lama, kita tidak akan bisa merubah apa pun pada keterangan atau notifikasi tersebut sehingga semua kontak dapat melihat informasi tersebut pada layar ponsel mereka.

[![Seting status WA](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEicxnb1Nax4m-3fZGmBcYEj_NEFOB2i7XH-ybUEAKv5zOmgiP9e-WjVtNfzrEo30nI44S-ki1ATKdxqTYgiIsgmx4WdsrwTOzpu6UNNKjPA3DaIoYZSQbIsyc2VGqu8loTLt0v0HfUI0ztozF8seKFDxzgMZsxIuFnszikKJUXJdnj5fcq8EHWsK_s9PA/w640-h400/whatsapp-1-800x500.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEicxnb1Nax4m-3fZGmBcYEj_NEFOB2i7XH-ybUEAKv5zOmgiP9e-WjVtNfzrEo30nI44S-ki1ATKdxqTYgiIsgmx4WdsrwTOzpu6UNNKjPA3DaIoYZSQbIsyc2VGqu8loTLt0v0HfUI0ztozF8seKFDxzgMZsxIuFnszikKJUXJdnj5fcq8EHWsK_s9PA/s800/whatsapp-1-800x500.jpg)  
 Extra privacy Pada Aplikasi Whatsapp
------------------------------------

Nah bagi anda yang ingin mendapatkan extra privacy dengan seperti pesan spam atau pun pesan yang tidak kita kehendaki, pada aplikasi whatsapp keluaran terbaru kita diperbolehkan untuk menyembunyikan keterangan tersebut dari profile kita.

Caranya cukup mudah dan tidak memerlukan software tambahan ataupun bantuan via aplikasi tambahan lainnya dan cara ini hanya memakan waktu 3-menit saja

Menonaktifkan status online Anda di WhatsApp cukup sederhana, tetapi ada trade-off yang akan kami bahas nanti di posting.

Untuk saat ini, ikuti petunjuk di bawah ini untuk menyembunyikan status online WhatsApp Anda:

1. Luncurkan WhatsApp.
2. Di sudut kanan atas, klik tiga titik vertikal.
3. Pilih Pengaturan.
4. Pilih Akun dari menu Pengaturan.
5. Setelah itu, pilih Privasi.
6. Dari menu tarik-turun, pilih Terlihat Terakhir.
7. Pilih Tidak Ada di jendela pop-up.

Jadi, bagaimana dengan kompromi itu? Anda tidak akan dapat melihat status online orang lain jika Anda menonaktifkan status online Anda. Ini menghentikan pengguna dari memata-matai satu sama lain sementara juga menyembunyikan aktivitas mereka sendiri.

[![seting last seen whatsapp](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiJwbAGZ9Trd3JM8zD1TFvHhcicXM-hsZqucBsMieonwdAK8gN5akfm-w_SixPpHUEo5oHfVAvKyfpvYOkrY9YksLbz-glmFFLKKtf-2W73lOo-zoFmnPkZKvR6ARIPeWduE5fx0rCKx1rgXaX6XRiV5EbNXC3RePkeWYUdrmvOPahNOA4TGNwcRN4Qrw/w360-h640/WhatsApp-Last-Seen.png)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiJwbAGZ9Trd3JM8zD1TFvHhcicXM-hsZqucBsMieonwdAK8gN5akfm-w_SixPpHUEo5oHfVAvKyfpvYOkrY9YksLbz-glmFFLKKtf-2W73lOo-zoFmnPkZKvR6ARIPeWduE5fx0rCKx1rgXaX6XRiV5EbNXC3RePkeWYUdrmvOPahNOA4TGNwcRN4Qrw/s1191/WhatsApp-Last-Seen.png)  
 Mengatur tampilan status online
-------------------------------

Sayangnya, tidak ada cara yang simple untuk mengatur tampilan status online Anda kepada daftar contact anda. Sulit, misalnya, untuk memberi tahu keluarga dan teman Anda bahwa Anda sedang online sambil mencegah atasan Anda melihat informasi yang sama.

Buka aplikasi whatsapp pada smartphone anda (android atau pun IOS) kemudian ketuk atau masuk pada pengaturan whatsapp. setelah berada pada menu pengaturan hal yang perlu anda lakukan adalah melakukan seting privacy pada opsi akun anda

Saat anda berada pada opsi privacy,maka akan muncul opsi opsi lainya yaitu

* siapa yang dapat melihat info pribadi anda
* terakhir terlihat
* status
* foto profile whatsapp

Maka anda tinggal melakukan penyesuaian terhadap level privacy yang anda kehendaki ,pada opsi "terakhir terlihat" maka anda akan mengatur opsi ini pada pilihan "tidak seorang pun" atau mengatur ke "hanya darikontak saya" apabila memperbolehkan "terakhir terlihat" diketahui oleh daftar kontak anda

Kesimpulan
----------

Secara default, Aplikasi WhatsApp memungkinkan kontak Anda mengetahui kapan Anda terakhir kali membuka aplikasi whatsapp.

Jika anda sering mendapat broadcast spam atau pun pesan masuk yang tidak anda kehendaki ada bagusnya apabila anda menyembunyikan informasi ini sehingga orang tidak bertanya-tanya mengapa Anda tidak menanggapi pesan mereka.

 


---
layout: post
title: Cara Memperkecil Ukuran Video Tanpa Mengurangi Kualitas [Handbrake]
date: '2017-12-05T17:05:00.002+07:00'
author: rosari J
tags:
- audio
modification_time: '2022-07-20T21:46:59.773+07:00'
blogger_id: tag:blogger.com,1999:blog-7329298365997944344.post-893223050656829685
blogger_orig_url: https://www.oktrik.com/2017/12/cara-memperkecil-ukuran-video-tanpa.html
---

Bagi anda yang sering melakukan convert video pastinya sudah tidak asing lagi dengan software yang bernama "*HANDBRAKE*", Software untuk memperkecil ukuran video ini dibagikan secara gratis hampir untuk semua platform baik itu [Windows 10]({{ site.baseurl }}{% post_url 2018-11-28-cara-mempercepat-kinerja-komputer %}), MacOS X dan Linux. Handbrake adalah software konversi video Open source dan merupakan salah satu *software terbaik dalam kategori aplikasi untuk convert video*

Namun begitu untuk mendapatkan setingan terbaik saat proses mengecilkan file video sehingga mendapatkan hasil konversi video yang optimal bukanlah perkara yang mudah, terkadang kualitas hasil konversi sudah bagus namun Ukuran file yang dihasilkan sering kali berukuran terlalu besar.

Idealnya kita menginginkan agar video yang kita konversi memiliki kualitas yang baik namun juga tidak terlalu berukuran besar sehingga memakan space yang tersedia didalam media penyimpanan. pada artikel ini akan kita bahas tips dan trik dan seting encoder pada software **handbrake** agar mendapatkan hasil konversi video yang kita inginkan

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgF2ZmFoeWH5_-5cBoXxu5z6W8sM6JCGfnLbzJq4suAcxTHIxar9KeRtNeBWznwrTuzkFH5ahcPTqEL4OhbablRtMDqX0odWwEoKF6NXnTnoGEZutZ-Z9_AAP84BKEH1MOkNETLiTIGy-g6cD31iSL34GR5-l0IdONuEFepbgTUI11HaKI-8UZtvuO1kQ/w640-h400/handbrake-1-800x500.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgF2ZmFoeWH5_-5cBoXxu5z6W8sM6JCGfnLbzJq4suAcxTHIxar9KeRtNeBWznwrTuzkFH5ahcPTqEL4OhbablRtMDqX0odWwEoKF6NXnTnoGEZutZ-Z9_AAP84BKEH1MOkNETLiTIGy-g6cD31iSL34GR5-l0IdONuEFepbgTUI11HaKI-8UZtvuO1kQ/s800/handbrake-1-800x500.jpg)  
 Tentang Handbrake
-----------------

HandBrake adalah transcoder video open-source berlisensi GNU General Public License (GPL) Versi 2 yang berjalan di Linux, Mac, dan Windows.

HandBrake akan memperkecil ukuran video yang ada menjadi format video baru yang dapat diputar di ponsel, tablet, pemutar media TV, konsol game, komputer, atau browser web Anda apa saja yang mendukung format video modern.

HandBrake mendukung berbagai file dan format video, termasuk yang diproduksi oleh kamera video konsumen dan profesional, perangkat seluler seperti ponsel dan tablet, rekaman layar game dan komputer, serta cakram DVD dan Blu-ray.

HandBrake menggunakan program seperti `FFmpeg`, `x264`, dan `x265` untuk mengubah Sumber ini menjadi file video MP4 atau MKV baru. HandBrake adalah alat pengonversi video yang dapat menyalin dan mengonversi file video sehingga dapat diputar di berbagai perangkat.

[HandBrake](https://handbrake.fr/downloads.php) adalah aplikasi memperkecil ukuran video terbaik untuk mengedit video yang disimpan secara lokal di hard drive Anda. Dari format hingga pengkodean hingga trek audio, Anda memiliki jumlah opsi yang praktis tak terbatas untuk dimainkan.

 Aplikasi memperkecil ukuran video Ini adalah solusi terbaik jika Anda perlu mengonversi video dengan format apa pun yang telah Anda simpan ke dalam format tertentu yang kompatibel dengan PC, ponsel cerdas, perangkat iOS, konsol, atau TV Anda. Selain itu, Anda dapat mengekstrak dan mengonversi format fisik seperti DVD dan cakram Blu-Ray.

Alat ini dapat mengecilkan file video dan mengconvert video hingga kualitas 4K dan hampir semua rasio aspek yang Anda butuhkan, dengan format yang telah ditentukan sebelumnya untuk hampir semua standar: Android, Apple, Playstation, Vimeo, YouTube, Windows, dan Matroska, antara lain. Kerugian utama adalah bahwa Anda harus mengubah semuanya secara manual di luar preset untuk mengatur dimensi, codec, membuat pemotongan, memodifikasi subtitling, bitrate, dan sebagainya.

**Optimisasi Seting video encoder**
-----------------------------------

Sebelum memulai proses konversi audio atau video menggunakan Handbrake terlebih dahulu kita harus mebagi kriteria kriteria apa saja yang kita inginkan. kriteria tersebut biasanya terbagi dalam

* mengecilkan file video sesuai Ukuran file yang kita inginkan
* Kualitas video tidak mengalami perubahan
* Kecepatan encoding

Secara pribadi menurut kami seting encoder terbaik untuk mengecilkan file video harus berimbang dari segi kualitas video yang dihasilkan begitu juga ukuran file hasil konversi. Waktu untuk memproses konversi video tersebut pun haruslah masuk akal, namun terkadang perbedaan waktu encoding pun ikut menentukan hasil akhir.

Ada kalanya extra 15 menit dalam melakukan konversi dapat menghasilkan Video dalam kualitas terbaik namun juga berukuran kecil. Jika kita mundur sekitar 4 atau 5 tahun kebelakang, tidaklah aneh jika waktu yang dibutuhkan untuk mengkonversi sebuah DVD memerlukan waktu hingga 8 jam.

Namun hal hal tersebut dewasa ini sudah dapat dihindarkan menimbang begitu pesatnya kemajuan teknologi saat ini, kita dapat dengan mudah melakukan konversi video dari dvd ke format lain dengan hanya memakan waktu 15 menit saja

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEixE9phUMgBOWpqPr1dp3O_f1Etube0kMDh7c4D0eMm_sLjAVXW3S4PfalVDyNUMbFRhmToQgC-lWjDLvkk8O5-y6xaJjrSuZxKrs38Ut2msr1zLAOh5zUhX0nBc8VxH2LeiFXxS8WQqsgVZoKIzRGTI6zSaXkBxvT17EbLnNoMj2koVaMtsPpF7f-P2A/w640-h426/Handbrake-interface.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEixE9phUMgBOWpqPr1dp3O_f1Etube0kMDh7c4D0eMm_sLjAVXW3S4PfalVDyNUMbFRhmToQgC-lWjDLvkk8O5-y6xaJjrSuZxKrs38Ut2msr1zLAOh5zUhX0nBc8VxH2LeiFXxS8WQqsgVZoKIzRGTI6zSaXkBxvT17EbLnNoMj2koVaMtsPpF7f-P2A/s640/Handbrake-interface.jpg)  
 **File asli tidak menentukan hasil akhir (MP4, MKV, AVI)**
----------------------------------------------------------

FIle asli yang akan anda konversi tidak mempunyai pengaruh apapun pada hasil akhir konversi video, dan jika pun mempunyai pengaruh maka itu pun sangatlah kecil. Oleh karena itu kami menyarankan untuk menggunakan Video file yang kompatible dengan perangkat yang nantinya akan memutar video tersebut.

AVI sudah banyak didukung oleh banyak perangkat maupun software yang ada dipasaran, namun begitu MP4 saat ini pun hampir mengalahkan popularitas yang dimiliki AVI hampir semua perangkat audio/video sudah memiliki support untuk memutar MP4.

Sedangkan MKV meski sudah cukup dikenal, namun support untuk File Video tersebut tidak sepopuler AVI dan MP4. Handbrake sudah dapat untuk memproses semua file dengan video format seperti diatas dengan bantuan video codec yang terdapat pada software Handbrake.

Harap diingat pilihan codec yang digunakan untuk mengecilkan file video cukup berpengaruh untuk menentukan kualitas dan ukuran video yang dihasilkan

*Jika memungkinkan Kami menyarankan MP4 sebagai Output dalam handbrake*

**Video codec mempunyai pengaruh yang cukup besar**
---------------------------------------------------

Dalam dunia konversi AUDIO/VIDEO tentunya kita sudah tidak asing lagi dengan istilah `CODEC`, Ada bermacam macam codec yang semuanya mempunyai fungsi dan kegunaan yang beragam pula.

Beberapa Video Codec Mempunyai Fungsi memperkecil ukuran video yang cukup bagus dalam mengkompres video sehingga hasil yang dihasilkan pun relatif kecil.

Harap diingat terkadang Video Codec "jadul" seperi `MPEG-2` bahkan bisa mengalahkan performa Video Codec keluaran terbaru seperti `h264`. dan bila kita cukup cermat, terkadang salah memilih Codec yang akan dipakai mampu mengecilkan file video dengan kualitas yang tidak baik dan berukuran sangat besar.

Sebagai contoh perangkat media player yang telah support video codec h264, mungkin saja belum support untuk opsi opsi detil tambahan yang terdapat dalam h264 yang pada akhirnya kualitas video pun menjadi buruk bahkan tidak dapat diputar pada perangkat media tersebut

*Kami menyaran menggunakan Codec h264 dalam handbrake seting*

**Bitrates yang tinggi tidak berarti Kualitas konversi pun tinggi**
-------------------------------------------------------------------

Walapun pada umumnya mayoritas menganggap bahwa bitrate yang tinggi maka kualitas video pun pasti tinggi, namun pada kenyataannya tidaklah begitu. memilih Bitrate tertinggi tidak selalu menjadi jaminan Kualitas konversi Video pun baik.

Seringkali meskipun berukuran kecil, Hasil kompress video pun memiliki kualitas yang cukup baik. memahami fungsi dari tiap tiap seting pada handbrake sangatlah penting seperti pemilihan proses `SINGLE PASS` akan menghasilkan video dengan kualitas standar dan sangat jauh hasilnya dibandingkan dengan `MULTI PASS` atau pun `DOUBLE PASS`

*kami sarankan menggunakan Opsi never use a bitrate higher than the source file pada handbrake seting*

**Cropping Video**
------------------

Seringkali User yang mengkompres video menggunakan Handbrake ikut pula mengaktifkan opsi `Upscalling` atau memperbesar resolusi video. Kami menyarankan jangan mengaktifkan opsi tersebut.

Karena opsi tersebut tidak memberikan pengaruh apapun dalam segi meningkatkan kualitas video namun lebih buruk seting tersebut, akan menambahkan data data tambahan yang tidak akan mempengaruhi hasil kualitas video.

Malahan hasil convert video dari aplikasi memperkecil ukuran video ini seringkali akan pecah dan berukuran menjadi lebih besar hal tersebut dikarenakan penambahan data data yang tidak diperlukan saat proses `upscalling`. secara default, HANDBRAKE mampu untuk mendeteksi ukuran file, aspect rotation dan cropping video itu sendiri.

Kami menyarankan untuk melakukan cropping pada latar belakang berwarna hitam yang biasanya terdapat pada Video namun hindari melakukan upscalling atau menerapkan setting melebihi yang disarankan oleh Handbrake

 


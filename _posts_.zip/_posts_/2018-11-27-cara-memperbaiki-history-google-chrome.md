---
layout: post
title: Cara memperbaiki history google chrome Yang Hilang (Korup)
date: '2018-11-27T18:20:00.004+07:00'
author: rosari J
tags:
- back-up
- windows
- registry
modification_time: '2022-07-10T18:22:56.584+07:00'
blogger_id: tag:blogger.com,1999:blog-7329298365997944344.post-8458864549233508755
blogger_orig_url: https://www.oktrik.com/2018/11/cara-memperbaiki-history-google-chrome.html
---

Pernahkah anda saat memulai session browsing internet menggunakan Google Chrome dan akan meneruskan session sebelumnya namun saat membuka tabs history google chrome kosong atau semua url tidak terdaftar pada menu history Google Chrome? Hal ini terjadi dikarenakan Korupnya Profile User Pada Google Chrome anda

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEg2J1jKSZhA2c50YPKYlAidwkOGTrAZsh1IBfUFBBF5Eaddsp48waAsrnI5ysg3GZfkXZyBhoLvOBH0ZqDQjJuUC32slBxoV33_WOXdh4XP6LzFl1VgqVxc9dPgHrkQTgWvQjW0FGbghPv1tE7nw4UzubkIIO6sdTCe64Ji8B1YSUNrOjL_0XXvYty2rA/w640-h400/browser-1-800x500.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEg2J1jKSZhA2c50YPKYlAidwkOGTrAZsh1IBfUFBBF5Eaddsp48waAsrnI5ysg3GZfkXZyBhoLvOBH0ZqDQjJuUC32slBxoV33_WOXdh4XP6LzFl1VgqVxc9dPgHrkQTgWvQjW0FGbghPv1tE7nw4UzubkIIO6sdTCe64Ji8B1YSUNrOjL_0XXvYty2rA/s800/browser-1-800x500.jpg)  
 langkah langkah Cara Memperbaiki Riwayat atau history yang kosong pada Google Chome
-----------------------------------------------------------------------------------

### **1.Export bookmarks Pada Google Chome anda**

Jika Pada Profile Google Chrome anda telah melakukan sign in, maka anda tidak perlu melakukan export bookmark karena semua aktifitas anda telah di sinkronkan melalui cloud server Google chrome. Cara ini berlaku bagi anda yang mengaktifkan anonymouse Profile ( tidak sign in)

Setelah melakukan export bookmark kemudian yang akan anda lakukan adalah mengakses folder Temp dengan cara Menekan tuts *logo windows dan R* secara bersamaan kemudian kopi dan paste perintah berikut

Bagi yang menggunakan windows Xp  
`%USERPROFILE%Local SettingsApplication DataGoogleChromeUser Data`

Bagi yang menggunakan Windows 7,8 ,10  
 `%LOCALAPPDATA%GoogleChromeUser Data`  
Dan tekan enter pada box perintah maka jendela user data seting Chrome akan terbuka

### **2.Back up Folder Default Chrome**

Cari Folder dengan nama "Default" kemudian Backup folder tersebut atau cukup lakukan "Rename" saja pada folder Chrome Default, caranya cukup mudah yaitu cukup dengan klik kanan dan pilih "RENAME"

### **3.Start Google Chrome**

Setelah melakukan cara tersebut diatas maka yang perlu anda lakukan adalah browse internet seperti biasa dan secara default maka Chrome secara otomatis akan membuat Folder "DEFAULT" di folder user setting Google Chrome

### **4.Import Bookmark**

setelah memperbaiki Folder setting Google Chrome maka yang perlu anda lakukan adalah mengimport bookmark dengan Cara menekan CTRL+H dan riwayat peramban anda akan muncul pada tabs history

Identifikasi Penyebab Masalah Dengan Debug Error
------------------------------------------------

Penyebab Browser Google Chrome yang bermasalah seperti history google chrome yang tidak valid dapat diperbaiki dengan mengidentifikasi error log yg dibuat oleh aplikasi peramban google chrome.

Anda bisa melihat log error pada build pengembangan seperti Canary atau dev.  pengguna yang stabil juga mengalami masalah server pembaruan dengan kesalahan 3 dan kesalahan 7. Sebenarnya sebagian besar dapat ditangani dengan menginstal ulang chrome yang mungkin bukan solusi yang diinginkan semua orang.

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhfOseTwy1Wy6UAObtMENdbzEm502ShUvcmP5NWAfIlTYxBUP3Hf1qFfQmLn4I9TvUGn643rWIDwTV_A0zc-XDIAr5ySfQ-xN6N4aeGI3YybTDjb3nyyFfIi_kNNbRQz5zRMl3n4iDtTxGzdXT__ZHZDDwefTXhTbJaLJvB_0utSzjuXOKcrgJvKDIA-Q/w640-h348/command.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhfOseTwy1Wy6UAObtMENdbzEm502ShUvcmP5NWAfIlTYxBUP3Hf1qFfQmLn4I9TvUGn643rWIDwTV_A0zc-XDIAr5ySfQ-xN6N4aeGI3YybTDjb3nyyFfIi_kNNbRQz5zRMl3n4iDtTxGzdXT__ZHZDDwefTXhTbJaLJvB_0utSzjuXOKcrgJvKDIA-Q/s427/command.jpg)  
 Mengakses Log Pada Google Chrome
--------------------------------

1. Buka bilah menu Chrome.
2. Pilih Alat Lainnya > Alat Pengembang dari menu tarik-turun.
3. Untuk mengakses log yang Anda perlukan, buka Tab Jaringan atau Konsol, bergantung pada log mana yang Anda perlukan.
4. Untuk jendela popup, kami mungkin meminta Anda untuk mengaktifkan DevTools (seperti saat memecahkan masalah akun yang terhubung). Untuk mencapai ini di Chrome, ikuti langkah-langkah berikut:
5. Seperti sebelumnya, buka Alat Pengembang.
6. Buka halaman "Pengaturan".
7. Aktifkan DevTools buka otomatis untuk popup (ingat untuk mematikannya setelah Anda selesai memecahkan masalah!).

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEi9Bw2ZjkAJhxSxXkQWhZBaQQPdyzoa-wrYn4wZ1edqW1YRt8EiPKUdlpO2qmgulWmyGIwtvGcoM4I9Gti3Hu92Qkjzo_lj97F7c--0ZhkyXDDUQLh0PQYIGDr6rV67mSEd8Q_lKDI5PL0WfZkK1MgrJMyUMsrL57Lj4zdwVscOiHrQ7vVjzuiQoL7yjw/w640-h448/seting%20chrome.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEi9Bw2ZjkAJhxSxXkQWhZBaQQPdyzoa-wrYn4wZ1edqW1YRt8EiPKUdlpO2qmgulWmyGIwtvGcoM4I9Gti3Hu92Qkjzo_lj97F7c--0ZhkyXDDUQLh0PQYIGDr6rV67mSEd8Q_lKDI5PL0WfZkK1MgrJMyUMsrL57Lj4zdwVscOiHrQ7vVjzuiQoL7yjw/s912/seting%20chrome.jpg)  
 Cara Memperbaiki Kesalahan Chrome File preferensi telah rusak atau tidak valid lagi (corupt).
---------------------------------------------------------------------------------------------

Anda dapat melihat pesan kesalahan yang mengatakan "file preferensi Anda salah atau salah" ketika Anda mencoba untuk memulai Google Chrome. 'Google Chrome tidak dapat mengambil preferensi Anda.' Menyetel ulang setelan Chrome


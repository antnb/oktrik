---
layout: post
title: Cara Melihat Orang Yang Melihat FB Kita (Plugin Dan Source Code)
date: '2017-12-03T17:17:00.003+07:00'
author: rosari J
tags:
- social media
- facebook
modification_time: '2022-11-05T15:45:29.833+07:00'
blogger_id: tag:blogger.com,1999:blog-7329298365997944344.post-4068567168262533543
blogger_orig_url: https://www.oktrik.com/2017/12/cara-melihat-orang-yang-melihat-fb-kita.html
---

Jika Anda seorang yang cukup aktif menggunakan social media tentunya anda sudah tidak asing lagi dengan yang namanya Facebook. Facebook pertamakali diluncurkan pada 4 Februari tahun 2004 oleh Mark Zuckerberg Bersama dengan beberapa Teman kuliahnya.

Sejarah Facebook
----------------

Pada Awal pertamakali berdiri layanan facebook dikhususkan hanya untuk kalangan terbatas yaitu hanya untuk mereka yang berstatus Mahasiswa dari Universitas Harvard atau kalangan teman teman perkuliahan dari mark Zuckerberg

Namun seiring waktu, sambutan para pengguna Facebook pun cukup positif sehingga Layanan Facebook pun berkembang dari yang awal mulanya dikhususkan Kepada Murid/mahasiswa Harvard university, meluas kebeberapa perguruan tinggi lainnya di amerika antara lain stanford University, Ivy League School dan beberapa institusi pendidikan di Wilayah boston.

Yang pada akhirnya layanan Facebook pun dapat diakses oleh seluruh kalangan dan tidak terbatas hanya dari kalangan pendidikan, siapapun yang mengklaim telah berumur diatas 13 tahun dapat mendaftar atau membuat profile facebook

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEj0IP4VgCkQHV9bwwqbR2uF3HQ2C6YTILnKhGr2l40oAr_hxVMxaL5LyBLDdV2WI6m_PCCcW6bap_gCf_hm58PwXd1Z-ypon_3J8W5jaCl1zwQ_Sr9DFFiEoudxpOPIJRAs1qI5WBQEmxxDK9yM4Lw7yTwwLp6PqhVd4zEIpg7oy2I8w5nKoe3bXZK9pw/w640-h400/fb-profile-1-800x500.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEj0IP4VgCkQHV9bwwqbR2uF3HQ2C6YTILnKhGr2l40oAr_hxVMxaL5LyBLDdV2WI6m_PCCcW6bap_gCf_hm58PwXd1Z-ypon_3J8W5jaCl1zwQ_Sr9DFFiEoudxpOPIJRAs1qI5WBQEmxxDK9yM4Lw7yTwwLp6PqhVd4zEIpg7oy2I8w5nKoe3bXZK9pw/s800/fb-profile-1-800x500.jpg)  
 Mencari teman di facebook
-------------------------

Dewasa ini, Hampir bisa dipastikan bahwa setiap pengguna internet saat ini memiliki Facebook Profile. Karena dengan semakin banyaknya fitur fitur yang tambahkan Oleh Tim facebook menjadikan Facebook menjadi kian populer sebagai social media platform.

Pengguna dapat berinteraksi dengan kawan, mengunggah gambar, memberikan komentar pada status teman facebook dan segudang fitur yang tersedia dalam layanan facebook. namun yang sering menjadi pertanyaan banyak orang antara lain Bagaimanakah melihat daftar orang yang telah melihat profile facebook kita?

Cara melihat orang yang melihat profil fb kita
----------------------------------------------

Terkadang kita penasaran siapa sajakah yang telah mengunjungi profile facebook kita, apakah ada cara melihat orang yang melihat fb kita? Ada banyak Layanan yang mengklaim dapat melihat teman yang telah mengunjungi profile facebook kita, namun apakah klaim tersebut benar

### **Web browser Plugin**

Jika anda menginstal plugin plugin tambahan pada peramban internet anda seperti pada Mozilla Firefox atau [Google Chrome](https://www.oktrik.com/cara-memperbaiki-riwayat-google-chrome.html), kami sarankan untuk menghapus plugin tersebut dari peramban web anda. Karena apapun klaim dari Plugin tersebut dipastikan tidak ada plugin atau extensi web browser yang dapat melihat orang yang melihat fb kita.

Walaupun Banyaknya review, klaim instalasi yang mencapai puluhan bahkan ribuan pada halaman plugin tersebut namun secara garis besar plugin plugin tersebut tidak dapat berfungsi seperti yang di iklankan dan sering kali review ataupun jumlah instalasi yang mencapai ribuan tersebut didapat menggunakan Bot atau software khusus

Dan tidak sedikit pula kasus plugin plugin yang telah disusupi virus dan malware yang berjalan dibackground tanpa sepengetahuan anda, Malware seperti Injeksi cookies, ads Injeksi dan bahkan Keylogger yang malah akan mencuri Pasword Pasword anda

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhlIPCajCFYb9lGJWADtNeyxBZzMF_rQurH36-zCWG6PrM6MkWnOywy8om8IaxQvGKt6Hk4fZ3xZp_UJ86MI0UOYGVXKzILvd-1mkq6nt7rN3aOm0NAM88Ieot-o6Tnsd1SZNu2zjXp2cVtsD79KeQBEXTJNa0d_O7lIIT2xXM1kEbgcVAf-oIL4PVRIw/w640-h394/FB-social-plugin.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhlIPCajCFYb9lGJWADtNeyxBZzMF_rQurH36-zCWG6PrM6MkWnOywy8om8IaxQvGKt6Hk4fZ3xZp_UJ86MI0UOYGVXKzILvd-1mkq6nt7rN3aOm0NAM88Ieot-o6Tnsd1SZNu2zjXp2cVtsD79KeQBEXTJNa0d_O7lIIT2xXM1kEbgcVAf-oIL4PVRIw/s640/FB-social-plugin.jpg)  
 ### **Chat Friends List**

Ada banyak layanan dan aplikasi di internet yang mengklaim mampu memberikan informasi daftar teman atau cara melihat orang yang melihat fb kita dan teman facebook kita , Namun dipastikan semua layanan tersebut tidak berfungsi sebagaimana yang telah diklaim.

Dan dari beberapa artikel dan forum post di internet metode yang ramai dibicarakan yaitu trik dan cara melihat orang yang melihat fb kita yaitu melalui source code pada layanan `Facebook Chat Friend List`.

Cara melihat orang yang melihat fb kita seperti yang di klaim pada layanan tersebut sangatlah mudah dan dapat anda praktekan sendiri menggunakan web browser favorit anda. jika anda telah login menggunakan akun anda, yang perlu anda lakukan hanyalah menekan tuts `CTRL+U` pada keyboard anda setelah itu maka akan terbuka jendela baru yang isinya berupa code code, masih pada keyboard anda Tekan `CTRL+F` atau menu facebook pencarian dan kopi paste text berikut pada kolom pencarian `InitialChatFriendsList`.

Pada klaim atau informasi yang beredar mengenai cara melihat orang yang melihat fb kita, userid yang berada pada Source Code tersebut adalah user yang telah mengunjungi Profile Facebook anda. namun hal tersebut tidaklah benar, meskipun Nomer pada field `USERID` tersebut memanglah benar Pengguna Facebook asli (bukan Bot).

Namun USERID tersebut merupakan daftar pengguna facebook maupun teman facebook yang telah melakukan interaksi dengan anda, seperti berkirim pesan, like status dengan anda dan diurutkan dengan frekuensi ataupun waktu

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjrMQClLODCIligcnI6cy7aTGFL8_wkwGH05gvuAfHXZswqWT0pNIjrk_C8s0T2kpPG8llHmbdCTjZmZms4uTxBZf4g_sbsKCDVneP50b1qyS8Z8HpClofZfaMp49LeINO8lG9OUUosmba_b_ayGAhGp7AUqdgfBC6hUKy5h3hWgCB5pSnxvBq3WASxUw/w640-h314/Facebook-Chat-Friend-List.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjrMQClLODCIligcnI6cy7aTGFL8_wkwGH05gvuAfHXZswqWT0pNIjrk_C8s0T2kpPG8llHmbdCTjZmZms4uTxBZf4g_sbsKCDVneP50b1qyS8Z8HpClofZfaMp49LeINO8lG9OUUosmba_b_ayGAhGp7AUqdgfBC6hUKy5h3hWgCB5pSnxvBq3WASxUw/s640/Facebook-Chat-Friend-List.jpg)  
 Apakah ada cara melihat orang yang sering melihat fb kita?
----------------------------------------------------------

Sayangnya, tidak ada cara melihat orang yang melihat fb kita di Facebook. Tidak, Facebook tidak mengizinkan siapa pun melacak siapa yang melihat profil teman facebook kita," catatan kebijakan resmi perusahaan dalam jawaban di [halaman Bantuannya](https://www.facebook.com/help).

Itu tidak berarti situs tersebut belum menerimanya sebelumnya. Menurut Eric Griffith, editor di PCMag.com, Facebook secara singkat menawarkan fungsionalitas ini di aplikasi iOS untuk iPhone pada tahun 2018, menyusul insiden Cambridge Analytica, yang mengekspos data pribadi pengguna dalam pelanggaran keamanan.

Pengguna Facebook dapat melihat siapa yang telah mengunjungi halaman mereka dalam 30 hari terakhir, serta siapa yang telah melihat posting terbaru mereka, selama waktu yang singkat saat fitur itu tersedia. Opsi itu tidak tersedia lagi.

Beberapa pengguna LinkedIn, platform media sosial untuk jaringan profesional, dapat melihat siapa yang telah melihat profil mereka jika mereka membayar keanggotaan "premium". "LinkedIn adalah satu-satunya layanan yang saya ketahui [melakukannya]," kata Griffith. Meskipun klaim berkala sebaliknya, Facebook tidak pernah memberikan keanggotaan berbayar atau bernilai tambah hanya salah satu dari banyak "fakta" palsu Facebook.

Terlepas dari kenyataan bahwa Facebook tidak mengizinkan Anda untuk mengetahui siapa yang telah melihat halaman Anda, Anda dapat melihat siapa yang mengikuti dan berhenti mengikuti Anda.

### cara mengetahui orang yang sering melihat facebook kita tanpa aplikasi

Ada beberapa cara untuk mengetahui apakah seseorang sering mengunjungi profil Facebook Anda tanpa menggunakan aplikasi pihak ketiga. Pertama, Anda dapat memeriksa bagian tampilan di profil Anda. Jika Anda melihat seseorang telah melihat profil Anda beberapa kali, kemungkinan mereka tertarik dengan Anda.  
  
Cara lain untuk mengetahui apakah seseorang sering melihat profil Facebook Anda adalah dengan melihat komentar dan suka pada posting Anda. Jika Anda memperhatikan bahwa seseorang secara konsisten menyukai atau mengomentari kiriman Anda, itu pertanda baik bahwa mereka tertarik pada Anda.  
  
Anda juga dapat mengetahui apakah seseorang sering melihat profil Facebook Anda dengan melihat pesan yang mereka kirimkan kepada Anda. Jika seseorang mengirimi Anda banyak pesan, kemungkinan mereka tertarik pada Anda.  
  
Terakhir, Anda dapat mengetahui apakah seseorang stalking (melihat profil Facebook Anda) dengan melihat teman-teman yang memiliki kesamaan dengan Anda. Jika seseorang memiliki banyak teman yang sama dengan Anda, kemungkinan mereka tertarik pada Anda.   


Kesimpulan
----------

Ada banyak artikel di internet tentang cara melihat orang yang melihat fb kita atau teman facebook kita, namun semua [tips dan trik](https://www.oktrik.com/) tersebut dipastikan tidak benar. dikarenakan hal ini menyangkut dengan privacy dan keamanan facebook sendiri, dan tentu saja Pihak Facebook tidak akan mungkin untuk membuka celah keamanan bagi server mereka sendiri

 


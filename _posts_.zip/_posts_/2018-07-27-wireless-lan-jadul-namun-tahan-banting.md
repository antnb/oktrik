---
layout: post
title: Wireless LAN Jadul Namun Tahan Banting, Surecom EP-9001GP
date: '2018-07-27T14:56:00.001+07:00'
author: rosari J
tags:
- hardware
- wireless
modification_time: '2022-07-10T14:58:41.139+07:00'
blogger_id: tag:blogger.com,1999:blog-7329298365997944344.post-1865879201492440027
blogger_orig_url: https://www.oktrik.com/2018/07/wireless-lan-jadul-namun-tahan-banting.html
---

Didirikan pada tahun 1987, Surecom telah menempatkan landasannya sebagai produsen alat-alat yang mengaplikasikan jaringan komputer, baik lokal maupun global. Produk Surecom mengonversikan data, suara sampai video dalam aplikasi networking/internetworking.

Target Surecom mulai dari pemakai komputer pribadi sampai perusahaan-perusahaan yang memanfaatkan teknologi jaringan IT. Surecom telah membuktikan kualitasnya produknya dengan memperoleh penghargaan dari PC Magazine, Chip Magazine, Nikkei Byte, Euro Trade dan symbol kualitas tertinggi di Taiwan “Symbol of Excellence Winner”.

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEi84R4Sj9XVrDgXqZy-m8hbFbFzidUAjY1P9tuQ1Xs8oUL4FQP9OYYjtBP_jbJs2zrrCT7mSnVl6vWJ6kvt6ZsbW1Wbbs-U0PLjaz6bcI_Zuc4MGfAX3VOZNg7y2FC607KKo8ADhfrdbKl6hq_Znh_TA39p7j5TRihH77AIRPDz1NLmY-FO9uasmUfncw/w640-h400/lan-800x500.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEi84R4Sj9XVrDgXqZy-m8hbFbFzidUAjY1P9tuQ1Xs8oUL4FQP9OYYjtBP_jbJs2zrrCT7mSnVl6vWJ6kvt6ZsbW1Wbbs-U0PLjaz6bcI_Zuc4MGfAX3VOZNg7y2FC607KKo8ADhfrdbKl6hq_Znh_TA39p7j5TRihH77AIRPDz1NLmY-FO9uasmUfncw/s800/lan-800x500.jpg)  
 Produksi Surecom didasari oleh “Right Time, Right Product, and Right Price” guna terjaminnya kepuasan pelanggan. Produk Surecom meliputi :

* 802.11 b/g/a Wireless LAN Series.
* Broadband Router dan IP Networking Application Series.
* Fast and Gigabit Ethernet Series.
* Fiber Converter Series.
* USB 1.1/2.0 Series.
* Home Plug Networking Series.

Salah satu produk Surecom yang baru adalah *Wireless LAN 108 Mbps USB 2.0 adapter* dengan kode EP-9001GP. EP-9001GP buatan Surecom ini bisa dipasangkan atau kompatibel dengan produk Wireless LAN dari merek-merek lain baik yang berbasis g ataupun b.

Memiliki dimensi 94x32, 2x7,3 mm yang notabene seukuran dengan flash disk, memudahkan EP-9001GP dibawa ke mana-mana. EP-9001GP menggunakan interface USB 2.0 sehingga dapat dipasang pada port USB komputer desktop ataupun notebook yang anda miliki.

Adanya super GTM dan Extended Range Technology menjadikan kecepatan transfer data mencapai 108 Mbps. Jadi bagi anda yang membutuhkan sambungan Wireless LAN dengan segala kemudahan dan kecepatan transfer data yang tinggi, maka EP-9001GP adalah satu-satunya jawaban untuk anda saat ini.

 


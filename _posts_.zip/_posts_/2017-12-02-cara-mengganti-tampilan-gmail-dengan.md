---
layout: post
title: Cara Mengganti Tampilan GMail Dengan Custom Image
date: '2017-12-02T17:21:00.008+07:00'
author: rosari J
tags:
- email
- gmail
- background
modification_time: '2022-11-05T15:21:48.967+07:00'
blogger_id: tag:blogger.com,1999:blog-7329298365997944344.post-4174502484577752412
blogger_orig_url: https://www.oktrik.com/2017/12/cara-mengganti-tampilan-gmail-dengan.html
---

Jika anda Sering berhubungan dengan client anda ataupun sering melakukan komunikasi menggunakan layanan yang disediakan oleh email provider Gmail maka adakalanya anda merasa bosan dengan tampilan standar yang disediakan oleh Tim Gmail.

Gmail memiliki fitur yang memungkinkan Anda untuk menyesuaikan latar belakang kotak masuk Anda. Anda dapat memilih dari pilihan latar belakang yang telah dibuat sebelumnya, atau Anda dapat mengunggah gambar Anda sendiri.   


Meski Gmail sendiri telah menyediakan beberapa opsi tampilan theme yang dapat anda rubah rubah sendiri sesuai selera namun theme tersebut menggunakan gambar latar yang biasa biasa saja dan anda ingin mengganti latar belakang GMAIL dengan Gambar atau Foto yang anda miliki

 [![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhcPqhWhptobrsboi1wK2F5A-h-mnXQ3bzsk9lG1S7rSmZJOXEBj_a0V23wYSyJD2D9sPKCvhL1w88NKErJ8woPuf-wJ4zsXNi_4_LMwa50q7_sDr-vERAifwDsmei4U60H1FF4Ji0gkgzV3av6rvQeoiL7EvY5x87zQGVgMnfweImJDsNbfNSYDRLqYQ/w640-h400/gmail-1-800x500.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhcPqhWhptobrsboi1wK2F5A-h-mnXQ3bzsk9lG1S7rSmZJOXEBj_a0V23wYSyJD2D9sPKCvhL1w88NKErJ8woPuf-wJ4zsXNi_4_LMwa50q7_sDr-vERAifwDsmei4U60H1FF4Ji0gkgzV3av6rvQeoiL7EvY5x87zQGVgMnfweImJDsNbfNSYDRLqYQ/s800/gmail-1-800x500.jpg)

  
Cara mengganti latar belakang Gmail cukup mudah dan tidak memakan waktu lama. step step atau langkah langkah yang diperlukan untuk merubah latar belakang Gmail intinya hanya dengan mengupload atau mengganti Gambar latar belakang dengan gambar yang anda miliki. yang perlu diperhatikan adalah gambar tersebut harus berukuran cukup besar dengan kualitas gambar yang baik pula agar nantinya gambar tersebut tidak pecah

Mengganti Background Email
--------------------------

Fitur latar belakang Gmail memungkinkan Anda menyesuaikan tampilan kotak masuk dengan menambahkan sentuhan pribadi. Anda dapat memilih dari berbagai latar belakang yang telah dibuat sebelumnya atau mengunggah gambar Anda sendiri untuk digunakan sebagai latar belakang pesan Anda. Panduan ini akan menunjukkan cara mengubah latar belakang Gmail Anda.  
  
Untuk mengubah latar belakang Gmail Anda:  
  
1. 1. Masuk ke akun Gmail Anda.
2. 2. Klik ikon roda gigi di sudut kanan atas dan pilih "Pengaturan".
3. 3. Gulir ke bawah ke bagian "Tema".
4. 4. Klik tautan "Ubah gambar latar belakang".
5. 5. Pilih latar belakang dari opsi yang disediakan atau klik "Foto Saya" untuk mengunggah gambar Anda sendiri.
6. 6. Setelah Anda memilih latar belakang, klik tombol "Simpan Perubahan" di bagian bawah halaman.

  
Latar belakang baru Anda sekarang akan diterapkan ke kotak masuk Gmail Anda.Cara mengganti background Gmail yaitu setelah login dan anda dihadapkan dengan interface GMAIL, Klik ikon GEAR yang berada di pojok kanan bagian atas pada web browser anda, kemudian pada menu drop down kit apilih menu Themes.

Setelah itu maka akan terbuka pilihan Themes default yang telah disediakan oleh GMAIL. Namun karena kita akan merubah Background dengan custom Image dari komputer kita, tentunya menu themes tersebut tidak akan kita pakai atau kita pilih, namun kita akan memilih menu "MY Photos" pada bagian kanan bawah.

Setelah itu Menu tambahan untuk mengupload Gambar pun akan tersedia. Disini kita mempunyai beragam Opsi lanjutan untuk menggunakan source gambar background, apakah itu berasal dari album online (picasa, google drive), Menggunakan remote Upload ataupun mengupload dari komputer. Dan Menu "upload from computer" inilah yang akan kita gunakan

Idealnya Gambar yang akan kita gunakan berukuran lebih besar dari resolusi monitor yang kita gunakan, namun begitu Menu upload background tersebut Menerima Gambar dengan format dan resolusi apa pun

 

 


---
layout: post
title: Cara melihat kata sandi instagram Tanpa Harus Reset Password
date: '2022-11-07T15:40:00.001+07:00'
author: rosari J
tags:
- social media
- instagram
modification_time: '2022-11-07T15:40:09.630+07:00'
blogger_id: tag:blogger.com,1999:blog-7329298365997944344.post-4605093668024718494
blogger_orig_url: https://www.oktrik.com/2022/11/cara-melihat-kata-sandi-instagram-tanpa.html
---

Apakah Anda lupa password Instagram Anda? Jika Anda lupa password Instagram, ada beberapa hal yang dapat Anda lakukan selanjutnya. Pertama, Anda dapat mengatur ulang dengan mengetuk "Lupa password?" Di layar login. Kemudian, ikuti instruksi yang ada di layar untuk mengatur ulang.


Namun, jika Anda sudah login ke Instagram, Anda mungkin bertanya-tanya bagaimana cara melihat password Instagram Anda di aplikasi tanpa perlu mengatur ulang. Setelah semua, melihat password Instagram Anda adalah alternatif yang lebih baik daripada mengatur ulang. Dalam panduan ini, Anda akan belajar bagaimana melihat password Instagram Anda saat Anda login di perangkat iPhone dan Android.


[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiRHG976YSpBuL7EWGQf329eJGVmp4x7bNXBWQwE8WgUyGEXu_IPE-FBj1qICThkwSUzQQfG5hqhK55TCCVpty0HLEMdfKuwrKc4dIrb2wBWXiY4he9-ckl9DdBk80neTur6fXelIQyhZv3G-3X2ZAqqOHXaXcnRP9BCskjnkRR9lM2fz8nVds9cAqfTg/s400/instagram.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiRHG976YSpBuL7EWGQf329eJGVmp4x7bNXBWQwE8WgUyGEXu_IPE-FBj1qICThkwSUzQQfG5hqhK55TCCVpty0HLEMdfKuwrKc4dIrb2wBWXiY4he9-ckl9DdBk80neTur6fXelIQyhZv3G-3X2ZAqqOHXaXcnRP9BCskjnkRR9lM2fz8nVds9cAqfTg/s1511/instagram.jpg)
Untuk melihat password Instagram Anda, Anda perlu menavigasi ke password yang tersimpan di perangkat Anda. Anda dapat melakukan ini untuk kedua perangkat iPhone dan Android. Jika Anda menggunakan iPhone, Anda dapat melihat password Instagram Anda dengan menavigasi ke pengaturan telepon Anda. Kemudian, navigasilah ke "Passwords", temukan "instagram.com" dan ketuklah untuk melihat password Instagram Anda.


Di Android, Anda dapat melihat password Instagram Anda dengan menavigasi ke Akun Google Anda melalui pengaturan telepon Anda. Kemudian, ketuklah "Kelola Akun Google Anda" diikuti oleh "Security" dan Anda akan dapat melihat password yang tersimpan di "Password Manager". Beberapa password secara otomatis tersimpan di perangkat Anda. Oleh karena itu, ada kemungkinan yang tinggi bahwa Anda dapat menemukan password Instagram Anda di perangkat Anda karena mungkin tersimpan.


Melihat password Instagram Anda di iPhone
-----------------------------------------


Untuk melihat password Instagram Anda di iPhone, pergilah ke pengaturan telepon Anda dan ketuk "Password". Kemudian, temukan dan ketuk "instagram.com" dan Anda akan bisa melihat password Instagram Anda. Ingatlah bahwa kode sandi / wajah ID / sentuhan ID Anda diperlukan untuk melihat password Anda. Setelah Anda mengetuk "instagram.com", Anda juga akan bisa melihat username Instagram Anda.


Selanjutnya, salin password Instagram Anda dan tempelkan di bidang "password" pada layar login Instagram. Jika Anda tidak bisa menemukan "instagram.com", Anda dapat mencari "facebook.com" sebagai gantinya. Ini karena password Facebook Anda mungkin mirip dengan password Instagram Anda. Oleh karena itu, Anda dapat menggunakan password Facebook Anda dan mencoba login ke akun Instagram Anda dengan itu. Berikut adalah panduan langkah demi langkah tentang bagaimana Anda dapat melakukannya


1. Pergi ke pengaturan telepon Anda Pertama-tama, Anda perlu pergi ke pengaturan telepon Anda. Untuk pergi ke pengaturan telepon Anda, geser ke bawah dari bagian atas layar Anda. Kemudian, cari "Pengaturan" di bilah pencarian dan ketuk tombol "cari". Anda kemudian akan melihat beberapa hasil pencarian termasuk sebuah ikon pengaturan. Ketuk ikon pengaturan untuk pergi ke pengaturan telepon Anda. Lanjutkan ke langkah selanjutnya untuk mempelajari bagaimana menampilkan password yang tersimpan di iPhone Anda
2. Ketuk "Password" Di pengaturan telepon Anda, geser ke bawah dan ketuk "Password" untuk melihat password yang tersimpan. Setelah Anda berada di pengaturan telepon Anda, Anda akan melihat beberapa tab termasuk "Mode Pesawat", "Wi-Fi", "Bluetooth", dan lainnya. Tab yang ingin Anda cari adalah tab "Password". Ini karena tab "Password" memungkinkan Anda untuk melihat password yang tersimpan termasuk password akun Instagram Anda. Geser ke bawah halaman pengaturan sampai Anda menemukan tab "Password". Tab "Password" seharusnya berada langsung di bawah tab "Dompet & Apple Pay". Ketuk tab "Password" untuk pergi ke halaman password. Lanjutkan ke langkah terakhir untuk mempelajari bagaimana menemukan password Instagram Anda di iPhone Anda.
3. Ketuk "Instagram.com"Temukan dan ketuk "instagram.com" dan Anda akan dapat melihat detail login Instagram Anda termasuk nama pengguna dan kata sandi Anda. Setelah Anda mengetuk "Kata Sandi", Anda harus membukanya terlebih dahulu. Akan ada pop-up yang meminta Anda untuk menggunakan Touch ID, Face ID, atau kode sandi Anda untuk membuka kunci halaman.


Jika Anda diminta untuk menggunakan Touch ID, cukup tekan ibu jari Anda pada tombol beranda untuk membukanya. Jika Anda diminta untuk menggunakan ID Wajah, posisikan wajah Anda di depan kamera. Terakhir, masukkan kode sandi 6 digit Anda jika Anda diharuskan melakukannya. Setelah itu, Anda akan mendarat di halaman "Kata Sandi".


Pada halaman "Sandi", Anda akan melihat semua sandi tersimpan di berbagai situs web. Gulir ke bawah halaman hingga Anda menemukan tab "instagram.com". Ketuk "instagram.com" untuk melihat detail login Anda. Jika Anda tidak dapat menemukan "instagram.com", Anda dapat mengetuk "facebook.com" karena kata sandi Facebook Anda mungkin mirip dengan kata sandi Instagram Anda.


setelah Anda mengetuk opsi button "instagram.com", Anda akan melihat nama pengguna dan kata sandi Instagram Anda. Anda dapat menyalin kata sandi Instagram Anda dengan mengetuk dan menahan bidang "Kata Sandi". Kemudian, ketuk "Salin" untuk menyalinnya!


"Pengelola Kata Sandi" di Akun Google Anda memungkinkan Anda melihat kata sandi yang disimpan. Untuk melihat kata sandi Instagram Anda di Android, pertama-tama Anda harus menavigasi ke Akun Google Anda di pengaturan ponsel Anda. Selanjutnya, ketuk "Kelola Akun Google Anda, ketuk "keamanan", dan ketuk "Pengelola Kata Sandi" untuk melihat kata sandi Instagram Anda.


Google Password Manager
-----------------------


Google memiliki "Password Manager" yang menyimpan beberapa password Anda.


Oleh karena itu, ada kemungkinan besar bahwa Anda dapat menemukan password Instagram Anda di sana.


Berikut adalah panduan langkah demi langkah tentang bagaimana Anda dapat melakukannya:


1. Buka pengaturan di ponsel Anda.
2. Scroll ke bawah dan ketuk "Google".
3. Ketuk "Manage your Google Account".
4. Scroll ke kanan dari bar navigasi dan ketuk "Security".
5. Scroll ke bawah dan ketuk "Password Manager".
6. Pilih "Instagram" untuk melihat password Instagram Anda.


Setelah Anda mengetuk "Instagram", Anda akan perlu mengverifikasi identitas Anda dengan mengisi kode sandi atau menggunakan sidik jari Anda.Juga, Anda perlu mengetuk ikon/simbol mata untuk menampilkan password Instagram Anda. Jika Anda tidak dapat menemukan tab "Instagram", Anda dapat mengetuk "Facebook" sebagai gantinya.Ini karena password Facebook dan Instagram Anda mungkin mirip.


Kesimpulan
----------


Jika Anda tidak pernah logout dari akun Instagram Anda selama bertahun-tahun, Anda mungkin tidak ingat password Anda.


Jika panduan ini membantu Anda dalam menemukan dan melihat password Instagram Anda, pastikan untuk mencatatnya di suatu tempat.


Dengan demikian, Anda tidak perlu repot menemukan atau meresetnya lagi.


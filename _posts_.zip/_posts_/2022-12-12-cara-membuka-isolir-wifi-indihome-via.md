---
layout: post
title: Cara membuka isolir indihome (Wifi Dan Lan) via Call Center dan internet tunelling
date: '2022-12-12T15:42:00.012+07:00'
author: rosari J
tags:
- indihome
- internet
modification_time: '2023-01-11T21:44:29.090+07:00'
blogger_id: tag:blogger.com,1999:blog-7329298365997944344.post-4546459471486388182
blogger_orig_url: https://www.oktrik.com/2022/12/cara-membuka-isolir-wifi-indihome-via.html
---

Indihome merupakan salah satu layanan internet yang paling banyak digunakan di Indonesia. Namun, dalam situasi tertentu, layanan ini bisa terputus karena Anda belum membayar tagihan layanan internet Indihome. Pemutusan layanan internet Indihome akibat belum membayar dapat memiliki dampak yang serius, terutama bagi mereka yang bergantung pada koneksi internet untuk menjalankan bisnis mereka.


Layanan internet Indihome dapat diputus akibat berbagai alasan, termasuk karena Anda belum membayar tagihan. Biasanya, jika Anda belum membayar tagihan layanan [internet Indihome](https://www.oktrik.com/search/label/indihome) dalam jangka waktu yang telah ditentukan, layanan akan diputus. Putusan ini biasanya dilakukan dengan menonaktifkan sambungan internet Anda.


Pelanggan Indihome harus membayar tagihannya tepat waktu agar dapat menikmati layanan internet tanpa gangguan. Jika tagihan tidak dibayar tepat waktu, maka layanan internet Indihome akan diputus.


Pemutusan internet Indihome terjadi ketika pelanggan telat membayar tagihan mereka. Di awal, pelanggan akan menerima pemberitahuan dari Indihome bahwa tagihan mereka sudah jatuh tempo. Jika pemberitahuan ini diabaikan, maka Indihome akan memutus saluran internet pelanggan. Keputusan ini akan berlaku sampai tagihan pelanggan dibayar dan dikonfirmasi oleh Indihome.


Ketika Indihome memutuskan saluran internet, pelanggan tidak dapat menggunakan layanan internet. Ini berarti bahwa pelanggan tidak akan dapat mengakses internet, streaming, atau menonton TV kabel. Jika pelanggan berusaha mengakses internet melalui router Indihome, akan muncul pesan “Tidak ada koneksi” dan akan dialihkan ke halaman isolir ke website indihome yang meminta anda untuk menghubungi call centre indihome.


Untuk menghindari pemutusan internet(Isolir), pelanggan Indihome harus membayar tagihan mereka tepat waktu. Pelanggan dapat membayar tagihannya melalui ATM, internet banking, atau melalui aplikasi MyIndihome. Setelah pembayaran dikonfirmasi oleh Indihome, layanan internet akan kembali aktif.


Jadi, jika Anda telat membayar tagihan Indihome, maka layanan internet Anda akan diputus sampai Anda membayar tagihan Anda dan dikonfirmasi oleh Indihome. Jadi, pastikan Anda membayar tagihan Anda tepat waktu untuk menikmati layanan internet tanpa gangguan.


Isolir IndiHome sendiri berlaku untuk semua layanan IndiHome yang telah diaktifkan oleh pelanggan, termasuk TV Kabel, Internet, dan Telepon. Pada saat isolir, semua layanan IndiHome yang telah diaktifkan oleh pelanggan akan dinonaktifkan dan tidak akan bisa digunakan lagi.


Sehingga, pelanggan yang ingin mengaktifkan kembali semua layanan IndiHome yang telah dinonaktifkan harus menghubungi kantor Telkom dan membayar biaya yang telah ditentukan sebelumnya. Setelah pembayaran selesai, layanan akan diaktifkan kembali.


[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEj9MPnOWY0RAQPBBfcHayP3i9BokcuZmeXWSoa2zKfBhyVHKH_LKbKl3GpkEPIx6pRuKxt_Ll8bo58kpNO-woTbMcAv5JwZPrESsE-736ZhikzqZgtMKn6d7GVwuH0lGp7-WFkplxsD715d0iJuV1t62xryjKzfhXZg_HbxGgkEnjn2dx8Wr3MCVJF3JQ/s600/internet%281%29.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEj9MPnOWY0RAQPBBfcHayP3i9BokcuZmeXWSoa2zKfBhyVHKH_LKbKl3GpkEPIx6pRuKxt_Ll8bo58kpNO-woTbMcAv5JwZPrESsE-736ZhikzqZgtMKn6d7GVwuH0lGp7-WFkplxsD715d0iJuV1t62xryjKzfhXZg_HbxGgkEnjn2dx8Wr3MCVJF3JQ/s1700/internet%281%29.jpg)
Apa itu isolir IndiHome
-----------------------


Istilah isolir IndiHome mengacu pada proses menonaktifkan layanan internet dan telepon rumah dari IndiHome. Proses ini dilakukan pada pelanggan yang memiliki tagihan yang tertunggak atau pelanggan yang menghendaki berhenti berlangganan. Isolir IndiHome juga dapat dilakukan untuk memelihara jaringan IndiHome dari pelanggan yang melakukan penyalahgunaan layanan (pelangggaran TOS). Proses isolasi berarti bahwa pelanggan tidak dapat menggunakan layanan internet dan telepon dari IndiHome sampai mereka membayar tagihan yang tertunggak atau berlangganan lagi.


Cara Mengatasi Isolir IndiHome
------------------------------


Cara Mengatasi pemutusan internet oleh IndiHome adalah dengan menghubungi customer service IndiHome jika isolasi terjadi dikarenakan adanya gangguan layanan, Namun bila isolir terjadi karena anda belum membayar tagihan, maka cara untuk mengatasi isolir indihome adalah dengan membayar tagihan bulan itu.


Customer service akan membantu Anda untuk mengetahui alasan pemutusan internet dan memberi Anda solusi untuk mengatasinya. Anda juga bisa mengunjungi toko IndiHome terdekat atau mengikuti petunjuk di website resmi IndiHome untuk mendapatkan bantuan lebih lanjut.


### Lapor Call centre Indihome


Lapor Gangguan Layanan IndiHome adalah salah satu cara untuk mengirimkan masalah yang terkait dengan layanan IndiHome kepada tim layanan pelanggan IndiHome. Melalui laporan ini, pelanggan dapat memberi tahu tim layanan pelanggan tentang masalah yang dihadapi, sehingga tim IndiHome dapat memecahkan masalah dan menyediakan layanan yang lebih baik. Dengan laporan ini, pelanggan dapat memastikan bahwa mereka akan mendapatkan bantuan yang cepat dan efektif.


1. **Lapor via aplikasi My IndiHome**  
Pastikan bahwa sebelum melaporkan isolir layanan IndiHome, kamu telah melakukan instalasi aplikasi My IndiHome di HP dan melakukan registrasi koneksi Internet IndiHome dan nomor telepon dengan menggunakan aplikasi My IndiHome.
2. **Lapor via aplikasi My IndiHome**  
Indihome menyediakan layanan Call Center untuk membantu pelanggan dalam mengirim laporan gangguan layanannya. Pelanggan dapat menghubungi Call Center Indihome di 147 untuk menyampaikan laporan gangguan layanan. Pada saat melapor gangguan, pelanggan harus menyediakan informasi seperti nomor pelanggan, nama pelanggan, alamat, dan informasi tentang gangguan yang dialami. Setelah laporan gangguan diterima, tim teknisi akan segera menuju lokasi untuk memperbaiki masalah.
3. **Lapor via aplikasi social media**  
Lapor Gangguan Layanan Indihome via Facebook Telkom Care adalah cara yang dapat digunakan oleh pelanggan Indihome untuk melaporkan gangguan layanan yang mereka alami. Pelanggan dapat mengirimkan laporan mereka melalui Halaman Facebook Telkom Care. Mereka juga dapat mengirimkan detail informasi tentang masalah yang mereka hadapi, seperti nomor pelanggan, nomor HP, dan nomor referensi laporan. Telkom Care akan memberikan balasan untuk memastikan bahwa laporan pelanggan telah diterima dan akan ditangani oleh tim teknisi Indihome.
4. **Membayar Tagihan Internet Anda**  
Layanan Internet indihome yang diblokir oleh pihak telkom bisa menimbulkan masalah. Jika tagihan ini tidak dibayar, maka layanan IndiHome akan terblokir (isolir). Untuk membayar tagihan, Anda bisa menggunakan [metode pembayaran indihome](https://www.oktrik.com/2022/12/langkah-langkah-mengecek-tagihan.html) yang disediakan oleh pihak telkom, seperti transfer bank, ATM, dan layanan pembayaran online. Anda juga dapat menghubungi customer service IndiHome untuk meminta bantuan.


Bypass isolir indihome dengan teknik internet tunelling
-------------------------------------------------------


Cara Mengatasi internet indihome yang di isolir dengan internet tunelling adalah salah satu cara yang dapat digunakan untuk melewati blokiran yang diterapkan oleh pihak telkom. Teknik ini memungkinkan pengguna untuk menghubungkan ke jaringan yang di blokir dengan menggunakan protokol yang disebut sebagai tunel. Tunel ini akan menyembunyikan identitas asli pengguna dan memungkinkan mereka untuk terhubung ke jaringan yang diblokir tanpa diketahui oleh pihak telkom.


### Tuneling Menggunakan OpenVpn


Tunneling OpenVPN adalah cara untuk mengakses internet yang diblokir (isolir).OpenVPN menggunakan teknologi tunneling untuk menghubungkan Anda ke jaringan lokal yang aman dan memungkinkan Anda untuk mengakses konten yang diblokir oleh pihak telkom tanpa harus menghadapi pembatasan yang diterapkan pihak indihome/Telkom.


Dengan menggunakan OpenVPN, Anda dapat membuka situs web, aplikasi, dan layanan yang diblokir oleh pemerintah dan ISP tanpa khawatir tentang privasi atau keamanan data Anda. Ini adalah cara yang efektif untuk mengakses konten yang diblokir tanpa harus menghadapi risiko privasi atau keamanan. Layanan indihome yang diisolir karena telat membayar tagihan bisa diatasi menggunakan tunelling menggunakan protocol `UDP` pada port 520


### Tuneling Menggunakan stunnel


Tunneling Stunnel adalah teknik yang digunakan untuk mengakses internet yang diblokir. Teknik ini menggunakan sistem enkripsi untuk menghubungkan dua jaringan secara aman, memungkinkan pengguna untuk mengakses informasi yang diblokir tanpa khawatir tentang privasi. Dengan Stunnel, lalu lintas jaringan terenkripsi dan lokasi IP pengguna tidak akan terdeteksi oleh pihak indihome. Pihak indihome akan mendeteksi bahwa anda sedang mengakses Portal isolasi indihome pada url isolir.indihome.co.id padahal anda sedang mengakses situs youtube.


Tunneling Stunnel memungkinkan pengguna layanan internet indihome untuk mengakses berbagai situs web tanpa batasan dari negara mana pun meskipun layanan internetnya telah di isolir oleh pihak telkom. Layanan indihome yang diisolir bisa di akali dengan menggunakan Stunnel Tunneling menggunakan protocol `SSL` pada port 443 dengan metode ssl certificate host spoofing yaitu isolir.indihome.co.id


Catatan
-------


Teknik tuneling hanya bersifat sementara atau selama portal isolasi telkom masih bisa diakses oleh pengguna. Biasanya Masa Isolir indihome berlangsung dari tanggal 21 hingga tanggal 30 tiap bulannya, Setelah itu (masuk tanggal 1) pihak telkom akan memutus secara total jaringan internet anda (jaringan akan tetap terhubung namun sama sekali tidak ada internet).


Jalan satu satunya untuk membuka kembali isolir indihome setelah masa pemutusan total ialah hanya dengan membayar tagihan internet anda


Kesimpulan
----------


Bagi Anda pelanggan internet indihome dan belum membayar tagihannya, maka layanan internet Anda akan diisolir. Oleh karena itu, penting untuk membayar tagihan Anda tepat waktu untuk mencegah pemblokiran layanan internet. Jika Anda menunda untuk membayar tagihan, maka biaya tambahan akan dikenakan dan Anda dapat mengalami gangguan layanan yang lebih lama. Oleh karena itu, penting bagi Anda untuk membayar tagihan segera setelah menerima notifikasi agar isolir indihome tidak terjadi lagi .


---
layout: post
title: Gestures Swipe, Mengaktifkan Fitur tombol back Pada Android OS Terbaru
date: '2019-10-12T12:13:00.001+07:00'
author: rosari J
tags:
- accesibility
- android
modification_time: '2022-07-10T12:16:06.760+07:00'
blogger_id: tag:blogger.com,1999:blog-7329298365997944344.post-2451351205839132549
blogger_orig_url: https://www.oktrik.com/2019/10/gestures-swipe-mengaktifkan-fitur.html
---

OS Android 10 merupakan sistem operasi terbaru
 yang di rilis oleh google, menggantikan sistem operasi lama mereka yang
 hampir semua nya menggunakan nama-nama desert, seperti Pie, 
Marshmallow, Lollipop dan lain sebagainya.


Untuk kali pertama google menggunanakan nama sistem operasi android 
dengan angka, setelah 25 tahun lama nya mereka menggunakan trend nama 
dessert. Selain perubahan nama, tentu juga google akan menyediakan 
fasilitas berupa fitur-fitur baru yang lebih canggih. Salah satu fitur 
baru nya adalah Gestures Swipe.

Gestures swipe merupakan pengganti dari **tombol back** atau kembali. Yaitu dengan cara menggeser untuk kembali ke halaman sebelum nya.



Nah, jika kamu masih bingung bagaimana **cara mengaktifkan navigasi gestures swipe atau back button** di OS Android 10, kami akan memberikan cara untuk mengaktifkan nya.

[![gesture swipe android](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgisaLaADuwRdREZX8EU8U2J3nloQuzdnrWBIE07DRkLq78W-uUu128jRlbPwMu3zoUgGjvcdA0VhSMpNJktvmplaoUWCpo0wOTA1mDgsSW46pmRM_foivz5f0wYlrNk4QWpWJmHLvDr-ljqCDY0eXnI28xiscssCrsKIrwKPIi4eVgJ6mdQp1iNOCsYQ/w640-h360/Gestures%20Swipe_640x360.jpg "gesture swipe")](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgisaLaADuwRdREZX8EU8U2J3nloQuzdnrWBIE07DRkLq78W-uUu128jRlbPwMu3zoUgGjvcdA0VhSMpNJktvmplaoUWCpo0wOTA1mDgsSW46pmRM_foivz5f0wYlrNk4QWpWJmHLvDr-ljqCDY0eXnI28xiscssCrsKIrwKPIi4eVgJ6mdQp1iNOCsYQ/s640/Gestures%20Swipe_640x360.jpg)  

Cara Mengaktifkan dan Menonaktifkan Gesture Swipe di Android 10
---------------------------------------------------------------


Berikut akan kami berikan cara untuk mengaktifkan navigasi gestures swipe atau **tombol navigasi android** pada OS Android 10. Simak penjelasan artikel di bawah ini :


1. Langkah pertama yang harus kamu lakukan adalah masuk ke menu setting atau pengaturan pada handphone android milik mu.
2. Pada menu pengaturan tersebut, kamu scroll ke bawah dan cari menu dengan nama ‘system’.
3. Klik pada menu ‘system’ tersebut.
4. Pada menu ‘system’, kamu pilih sub menu dengan nama ‘gestures’.
5. Akan muncul beberapa sub menu lagi, lalu kamu pilih sub menu yang bernama ‘ swipe up on home button’.
6. Setelah itu aktifkan tombol swipe pada ikon tombol back tersebut sehingga berubah warna menjadi hijau.
7. Jika gestures telah aktif, akan menghilangkan salah satu dari tiga 
tombol yaitu home, back dan recent, hanya menjadi dua tombol saja yaitu 
home dan back yang berbentuk seperti kapsul atau pil.
8. Maka tombol navigasi gestures swipe telah aktif dan siap digunakan.


Untuk cara penggunaan nya sediri sebenarnya cukup mudah, hanya mungkin bagi yang pertama kali mencoba *tombol back android* akan merasa kebingungan dan kesusahan.



Cara menggunakan navigasi gestur swipe
--------------------------------------


1. Untuk kembali ke menu depan atau home, kamu cukup sentuh sekali tombol home tersebut.
2. Jika ingin kembali ke halaman sebelumnya, cukup sentuh tombol back sekali saja.
3. Jika ingin membuka tampilan recent, kamu hanya tinggal swipe up ke 
atas pada tombol home tersebut. Kamu bisa membuka aplikasi yang telah di
 buka atau menutup aplikasi tersebut pada tampilan recent ini.
4. Jika kamu ingin menscroll aplikasi secara perlahan, maka kamu hanya 
melakukan swipe tombol home ke kanan dan jika ingin membuka aplikasi 
yang kamu pilih, maka tahan tombol home tersebut.
5. Jika ingin membuka aplikasi yang sebelumnya sudah kamu pilih, kamu 
hanya perlu swipe tombol home ke arah kanan dan tidak perlu menahan 
tombol home tersebut.
6. Jika ingin membuka menu google assistant, kamu harus sentuh dan menahan tombol home tersebut.


Nah, jika kamu ingin mematikan **fitur gestures swipe** tersebut, cara nya sangat mudah.  

Kamu [hanya perlu melakukan](https://android.gadgethacks.com/how-to/use-android-10s-new-swipe-gestures-demo-gifs-0207040/)
 seperti langkah ketika mengaktifkan navigasi gestures swipe seperti 
yang ada di atas. Yaitu masuk ke menu pengaturan, lalu pilih system dan 
pilih gestures, klik menu swipe up on home button dan terakhir kamu 
nonaktifkan ikon hijau pada menu tersebut. Sangat mudah kan?


Nah, itulah cara mengaktifkan, menggunakan dan menonaktifkan fitur gestures swipe pada OS Android 10.

 


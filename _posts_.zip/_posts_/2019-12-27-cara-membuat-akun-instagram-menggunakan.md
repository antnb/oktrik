---
layout: post
title: Cara Membuat Akun Instagram Menggunakan HP Android
date: '2019-12-27T11:29:00.004+07:00'
author: rosari J
tags:
- social media
- instagram
modification_time: '2022-07-12T13:47:45.951+07:00'
blogger_id: tag:blogger.com,1999:blog-7329298365997944344.post-6677198431369260243
blogger_orig_url: https://www.oktrik.com/2019/12/cara-membuat-akun-instagram-menggunakan.html
---

Di saat sekarang, Instagram merupakan sosial media yang paling populer dan paling banyak digunakan di seluruh dunia. Negara Indonesia sendiri menjadi peringkat ke empat sebagai pendaftar akun instagram terbanyak, yaitu sekitar 56 juta pengguna aktif.


Pada peringkat ketiga ada negara India dengan 64 juta, di peringkat kedua ada negara Brazil dengan 66 juta pengguna dan di peringkat pertama ada Negara Amerika serikat dengan pengguna instagram berjumlah kurang lebih sekitar 110 juta user.


Banyak nya pengguna instagram lantaran platform berbagi foto dan video ini selalu melakukan evolusi dan pembaharuan yang lebih canggih dan menarik minat banyak orang.


Di negara kita, instagram tidak hanya digunakan untuk ajang pamer foto dan video semata, namun digunakan juga untuk mencari nafkah dengan berjualan berbagai produk lewat platform tersebut. Para pemula yg belum begitu paham tentang internet pun mencari tahu langkah mendaftar akun instagram atau cara bikin akun instagram melalui hp


Jika kamu belum memiliki **instagram**, kami akan memberikan **cara untuk membuat akun instagram** bagi pemula.









Cara Buat Akun Instagram Langsung Dari HP Android
-------------------------------------------------


Simak penjelasan cara membuat akun instagram di HP Android dengan mudah.


1. Download aplikasi instagram lewat google playstore atau Appstore.
2. Instal dan buka aplikasi tersebut.
3. Setelah kamu buka instagram, kamu pilih menu daftar atau sign up.
4. Kemudian masukan alamat **email** atau nomer telepon yang masih aktif dan sedang kamu gunakan, agar mempermudah langkah selanjutnya. Tergantung pilihan apakah anda akan buat akun ig menggunakan email atau no telephone
5. Kemudian klik Next dan instagram akan mengirimkan sms atau email berupa kode konfirmasi.
6. Setelah mengkonfirmasi, kamu buat nama pengguna dan kata sandi. Kamu bisa menggunakan nama asli, nama beken atau terserah kamu. Dan untuk kata sandi, kamu buat yang mudah di ingat saja. Jangan yang rumit yang akan membuat kamu lupa.
7. Selanjutnya instagram akan meminta persetujuan apakah instagram milik mu akan ditautkan pada facebook atau tidak. Dalam hal ini hak sepenuh nya ada di tangan mu.
8. Instagram juga akan menyarankan nama-nama akun instagram yang ada pada kontak di handphone mu. Kamu bisa follow atau tidak, itu terserah kamu.
9. Dan setelah semua langkah itu kamu lakukan, maka kamu telah bisa menggunakan instagram untuk berbagai hal, semisal [follow akun atau unfollow profile instagram](https://www.oktrik.com/2019/12/cara-follow-unfollow-instagram-orang.html) orang , live ig, posting foto dan lain sebagainya.









Fitur Instagram Yang Dapat Anda Nikmati Setelah Mempunyai Akun Instagram
------------------------------------------------------------------------


Beberapa fitur instagram yang harus di ketahui oleh para pengguna pemula platfoam sosial media instagram. Berikut beberapa fitur instagram yang akan anda dapatkan setelah mendaftar akun instagram.


### Follow dan Unfollow.


Follow berarti kamu mengikuti akun instagram milik orang lain dan Unfollow berarti kamu berhenti untuk mengikuti akun instagram tersebut.









[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhGsVcNdfAT50gUR9awSwbddfH07pHNacW40-nGHqIfJwxUI8c5-jty_sRWqOjYV0oHxaPIzM06wbdcge9JGrorFrLmEQvwX46yMNTNS1Wh4oO0nzLcRFZZ-yprbmkBAP9ME2qgSLFOvljWKaTtW71sspTvg87weaeZtgnl4oUF2Mrct-YqWhrumocYEA/s600/5WMnlcN_640x373.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhGsVcNdfAT50gUR9awSwbddfH07pHNacW40-nGHqIfJwxUI8c5-jty_sRWqOjYV0oHxaPIzM06wbdcge9JGrorFrLmEQvwX46yMNTNS1Wh4oO0nzLcRFZZ-yprbmkBAP9ME2qgSLFOvljWKaTtW71sspTvg87weaeZtgnl4oUF2Mrct-YqWhrumocYEA/s640/5WMnlcN_640x373.jpg)


### Profil Bisnis


Profil bisnis merupakan fitur khusus yang instagram berikan kepada para pelaku pebisnis online. Di dalam fitur tersebut banyak sekali manfaat dan kegunaan, semisal untuk memantau trafik pengunjung di akun instagram tersebut, seberapa efektif akun kita menjangkau banyak audiens dan lain sebagainya.https://help.instagram.com/307876842935851/?helpref=hc\_fnav&bc[0]=Bantuan%20Instagram&bc[1]=Instagram%20untuk%20Bisnis









 [![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEi8Oyoqr9L65v2kPiXwdf4TCmU8WBGv7xsUUuX5i_LZesJNkCGpx9itblm5czg5FR9We7dPDnLmuhctjaX8tmQwVb7MlYqZyhFFcrkUDiDpLg1daAq86TFwIW3SPmTAd2C_ESs1yr2r6A34tRxNWzYl2ujWS5fhn-pSMYU54l7sAeI4OWg1H-Ra1bw0Ug/w640-h344/akun-bisnis-instagram-untuk-apa_640x344.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEi8Oyoqr9L65v2kPiXwdf4TCmU8WBGv7xsUUuX5i_LZesJNkCGpx9itblm5czg5FR9We7dPDnLmuhctjaX8tmQwVb7MlYqZyhFFcrkUDiDpLg1daAq86TFwIW3SPmTAd2C_ESs1yr2r6A34tRxNWzYl2ujWS5fhn-pSMYU54l7sAeI4OWg1H-Ra1bw0Ug/s640/akun-bisnis-instagram-untuk-apa_640x344.jpg)







### Instagram stories


Instagram stories merupakan fitur instagram yang digunakan untuk posting foto seperti pada story whatapps. Yaitu postingan tersebut akan otomatis terhapus dalam waktu kurun 24 jam. Fitur ini bisa digunakan untuk kamu yang ingin banyak posting foto dengan cara cepat.


### Live IG


Fitur ini digunakan untuk kamu berinteraksi dengan pengguna lain secara langsung. Kamu bisa melakukan siaran langsung dan menyapa para followers mu. Namun, kamu harus sadar diri. Jika follower mu cuma dua ya jangan memaksakan diri untuk live, karena pasti tidak ada yang nonton bung.https://help.instagram.com/292478487812558









Penutup
-------


Nah, itulah penjelasan tentang **cara membuat akun instagram** dan beberapa fitur yang harus kamu ketahui.


 


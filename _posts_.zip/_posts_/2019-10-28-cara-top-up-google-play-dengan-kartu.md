---
layout: post
title: Cara Top Up Google Play Dengan Kartu Debit
date: '2019-10-28T12:02:00.004+07:00'
author: rosari J
tags:
- payment
- google play
modification_time: '2022-07-12T19:06:57.609+07:00'
blogger_id: tag:blogger.com,1999:blog-7329298365997944344.post-632710636039888473
blogger_orig_url: https://www.oktrik.com/2019/10/cara-top-up-google-play-dengan-kartu.html
---

Kartu google play Gift Card adalah sebuah voucher yang digunakan untuk membeli berbagai macam layanan yang bersifat premium atau berbayar di Play Store Google terutama untuk membeli, aplikasi, game, musik atau lagu, buku, film dan lainnya.


[metode pembayaran google play](https://www.oktrik.com/2019/10/metode-pembayaran-google-play-melalui.html) untuk membeli aplikasi atau game premium atau berbayar di google playstore ada banyak pilihan loh. Salah satu cara top up google play yang bisa digunakan adalah  menggunakan kartu kredit atau kartu debit.


Kartu debit sendiri merupakan metode pembayaran elektronik yang diterbitkan oleh pihak bank untuk memudahkan transaksi para nasabah nya. Ada banyak kartu kredit yang disediakan berbagai bank, semisal **Bank Mandiri, Bank Central Asia atau BCA, BRI, BNI** dan lain sebagai nya.


Jika kamu masih kebingungan bagaimana cara beli Aplikasi dan Game Berbayar di Google Play menggunakan kartu debit atau kartu kredit? Tenang, berikut ini, kami akan jelaskan cara top up google play menggunakan metode pembayaran kartu debit atau kartu kredit.







 [![Cara Top Up Google Play](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjDAiLTyDgCOL8s_F_7908qq9IA_UoAig4IEOKOXCjeHs2-sKx5d_bQugPdoRbpMotJd4KzF6NeZxp8huge43NXzXyLlqKFuamjVzcFukbWFUdwfWIrVBno3QZt_xQ9bL8xE9l0G0Dg_FjrnUZXKz8qrw06DhWq4kCtRSSr6_JxyyNrkXlUNy08p4wvAg/w640-h400/debit-1-800x500.jpg "Top Up Google Play")](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjDAiLTyDgCOL8s_F_7908qq9IA_UoAig4IEOKOXCjeHs2-sKx5d_bQugPdoRbpMotJd4KzF6NeZxp8huge43NXzXyLlqKFuamjVzcFukbWFUdwfWIrVBno3QZt_xQ9bL8xE9l0G0Dg_FjrnUZXKz8qrw06DhWq4kCtRSSr6_JxyyNrkXlUNy08p4wvAg/s800/debit-1-800x500.jpg)


**Topup google play Menggunakan Kartu Kredit dan Debit**
--------------------------------------------------------


Simak penjelasan artikel [oktrik](https://www.oktrik.com/) di bawah ini untuk mengetahui langkah-langkahnya :


1. **Masuk google play**  
 Langkah pertama yang harus kamu lakukan adalah dengan masuk pada aplikasi google play yang ada di handphone android mu.
2. **Menu di google play**  
 Pada aplikasi google play, kamu klik pada ikon di pojok kiri atas yang berupa garis tiga berderet ke bawah. Pilih dan klik menu ‘my account’
3. **Pilih Metode pembayaran**  
 Setelah masuk pada akun, kamu pilih menu yang bertuliskan ‘tambahkan metode pembayaran’ dan kamu pilih kartu kredit atau debit sebagai metode pembayaran utama
4. **Masukan nomer rekening**  
 Setelah kamu memilih metode pembayaran utama menggunakan kartu debit atau kartu kredit, kemudian masukan nomer rekening kartu debit atau kredit mu yang berjumlah 16 digit angka. Masukan juga tanggal, bulan dan tahun kapan kartu kredit atau kartu debit mu kadarluarsa dan masukan juga tiga angka berupa kode ccv yang berada di bagian paling kanan di belakang kartu debit atau kartu kredit mu. Setelah itu kamu kamu klik ‘simpan’.  
  **Berhasil**  
 Jika kartu kredit atau kartu debit mu berhasil di aktivasikan, maka akan muncul 4 digit angka terakhir nomer rekening kartu debit atau nomer reking kartu kredit mu. Langkah terakhir yang harus kamu lakukan adalah mengklik ‘simpan’ atau ‘save’.


Maka kamu sudah bisa melakukan pembelian berbagai konten premium yang tersedia di google playstore.







 [![Metode pembayaran google via android](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiJG8fshWgmdt3PCXoXz3yECNJxOjXRZQyjkmDjcZ4YvxvZFxZl7rfQJyT3Utpz-gF5j2EUGvQqaCDDTosPLbyRpJPN-BdYSLfnYBF5c8wSz6tBhWXNwuU-9mKQ0Ix6g-ALY6y0yuUTDoq8sKvs7I77v53OJRMhxEGZJd3dgcSj5yfHeoPGWZbQNUv5DA/w640-h594/payment-methods-tab-google-play-store_518x480.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiJG8fshWgmdt3PCXoXz3yECNJxOjXRZQyjkmDjcZ4YvxvZFxZl7rfQJyT3Utpz-gF5j2EUGvQqaCDDTosPLbyRpJPN-BdYSLfnYBF5c8wSz6tBhWXNwuU-9mKQ0Ix6g-ALY6y0yuUTDoq8sKvs7I77v53OJRMhxEGZJd3dgcSj5yfHeoPGWZbQNUv5DA/s518/payment-methods-tab-google-play-store_518x480.jpg)


Cara Beli Aplikasi dan Game Berbayar di Google Play Menggunakan Kartu Kredit dan Debit
--------------------------------------------------------------------------------------


Cara melakukan pembelian aplikasi dan game di google playstore dengan menggunakan kartu debit atau kartu kredit, langkah-langkah nya adalah sebagai berikut :


* Cari dan pilih game atau aplikasi yang ingin kamu beli.
* Pilih menu cara top up google play, yaitu menggunakan kartu debit atau kartu kredit yang telah di daftarkan pada google play mu, akan muncul otomatis tulisan visa atau mastercard di bawah nama game atau aplikasi yang kamu pilih dan juga empat digit terakhir nomer rekening kartu debit atau kartu kredit.
* Kemudian klik ‘beli’
* Masukan pasword jika diminta untuk memasukan password, kemudian klik konfirmasi.
* Jika kamu berhasil, maka akan muncul notifikasi pemberitahuan bahwa Top Up yang kamu lakukan sukses dan kamu telah dapat mendownload serta menginstal aplikasi atau game premium yang kamu inginkan tersebut.







Penutup
-------


Cukup mudah bukan cara top up google play menggunakan kartu debit atau kartu kredit dan juga cara melakukan pembelian aplikasi atau game premium di google play?  
 Mungkin itu saja yang bisa kami jelaskan, selanjutnya tinggal kamu praktekan ilmu yang kamu dapat diatas.


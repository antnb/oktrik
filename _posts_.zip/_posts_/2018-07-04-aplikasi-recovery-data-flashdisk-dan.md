---
layout: post
title: Aplikasi Recovery Data Flashdisk Dan MMC Untuk mengembalikan file yang terhapus
date: '2018-07-04T15:57:00.002+07:00'
author: rosari J
tags:
- data recovery
- memory card
modification_time: '2022-11-07T13:21:17.582+07:00'
blogger_id: tag:blogger.com,1999:blog-7329298365997944344.post-6303572033863741725
blogger_orig_url: https://www.oktrik.com/2018/07/aplikasi-recovery-data-flashdisk-dan.html
---

Kadang tidak sengaja tangan kita memencet tombol erase pada kamera, sehingga data yang seharusnya dapat disimpan, hilang tidak sengaja, file terhapus untuk selamanya. Hal ini tentu sangat di sayangkan. Namun jangan takut ada banyak software dan aplikasi recovery data untuk mengembalikan file terhapus dan cara recovery data flashdisk dan MMC akan kita bahas dalam tulisan ini

Tentang Kartu MMC
-----------------

Multimedia Card (MMC) adalah kartu memori digital flash solid-state sederhana dengan nama pendek. Kartu MMC adalah jenis perangkat penyimpanan data yang banyak digunakan. Media penyimpanan Ini ditemukan di berbagai gadget portabel, termasuk smartphone, kamera digital, pemutar media, dan banyak lagi.

Kelebihan kartu MMC adalah dapat dengan cepat dipasang ke sistem PC untuk akses cepat ke data seperti gambar dan video. Data penting ini kadang-kadang bisa hilang secara tidak sengaja.

Lantas, bagaimana jika file hilang di flashdisk? Apakah mungkin untuk memulihkan data hilang dari kartu MMC? Jika Anda memiliki salah satu dari masalah ini, jangan khawatir; Saya yakin bahwa artikel recovery file terhapus ini akan membantu Anda dalam menyelesaikan masalah Pemulihan Data di Kartu Multimedia Anda menggunakan aplikasi recovery data.

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEi7vqwaRKn0Lb9WV_vAxnWYygJK52YWJsT_rrO4cEKzIospI2ZLBwnwvKxsoRKgT5S08bXMz7-E8h3GFESmSELoi7gbYhtGisxlm5owsfH4V6JFdvEd7s4DUaNR2AekBgBX3iCpqjvz7yV58QUpWti7cnDziOXyOxnyuqKwX6HDDBI6AKM_mKEQFb23PA/w640-h400/recovery-1-800x500.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEi7vqwaRKn0Lb9WV_vAxnWYygJK52YWJsT_rrO4cEKzIospI2ZLBwnwvKxsoRKgT5S08bXMz7-E8h3GFESmSELoi7gbYhtGisxlm5owsfH4V6JFdvEd7s4DUaNR2AekBgBX3iCpqjvz7yV58QUpWti7cnDziOXyOxnyuqKwX6HDDBI6AKM_mKEQFb23PA/s800/recovery-1-800x500.jpg)  
 Penyebab Paling Umum file di flashdisk hilang
---------------------------------------------

Berikut ini adalah beberapa kemungkinan penyebab data hilang dari kartu MMC:

1. Foto atau file terhapus secara tidak sengaja atau tidak sengaja dari kartu MMC jika kartu tidak ditangani dengan benar.
2. Tiba-tiba mencabut kartu MMC di tengah transfer file
3. Infeksi virus
4. Memformat kartu tanpa terlebih dahulu membuat cadangan data di dalamnya
5. Saat daya rendah atau ada ruang kosong di kartu, menggunakan kamera atau ponsel

Recovery file terhapus Pada Memory Card
---------------------------------------

Tetapi, kini anda tidak perlu panik karena data hilang dan file terhapus tersebut masih dapat diselamatkan menggunakan aplikasi recovery data dibawah ini. Caranya sangat mudah.

### **Jalankan Aplikasi**

Download aplikasi recovery data Recovery Manager situs resminya, kemudian instal dan jalankan. Pada bagian sebelah kiri terdapat daftar Removable Storage apa saja yang pada saat itu terhubung ke komputer anda. Sedangkan di sebelah kanan berisikan informasi mengenai Removable Storage yang anda pilih.

Mulai nama media, versi Firmware, Drive yang digunakan, kapasitas, label setiap volume serta file system. Selain itu, anda juga dapat mengetahui berapa jumlah kapasitas yang sudah terpakai atau berapa kapasitas yang kosong.

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjwUXHniK6VoJNXlyLLdhbMEqWBET1pCNWNvenlh3Q4gjmXgx_ztLyRC0MHnKyZ6ua3O-GExAySggqz8WSok-rHFeYvugd86wsPX-jX_fzqQ4DjDJQrWN1EP1nd3Xe6MlFAk8DAmTCxrmNsP_XuXLMHe4m_cnsSYI5wvJ2Ix1Ia0CtUUliH7-OyIkFzOg/w640-h472/filerecovery.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjwUXHniK6VoJNXlyLLdhbMEqWBET1pCNWNvenlh3Q4gjmXgx_ztLyRC0MHnKyZ6ua3O-GExAySggqz8WSok-rHFeYvugd86wsPX-jX_fzqQ4DjDJQrWN1EP1nd3Xe6MlFAk8DAmTCxrmNsP_XuXLMHe4m_cnsSYI5wvJ2Ix1Ia0CtUUliH7-OyIkFzOg/s646/filerecovery.jpg)  
 ### **Back Up**

Bila ingin memback-up media yang anda miliki, pilih halaman backup. Proses back-up ini sama halnya dengan memindahkan seluruh isi media anda ke dalam komputer. Caranya cukup dengan menekan icon folder di sebelah boks backup file name.

Lalu arahkan folder mana anda akan mem-back-up isi memori card. Berikan nama lalu tekan Save. Anda juga dapat langsung mem-back-up ke CD. Di bagian bawah anda ditanya, apakah akan mem-back-up bagian yang sudah terisi saja atau seluruhnya. Pilih saja yang anda inginkan. Lalu tekan tombol back-up.

### **Restore**

Yang dimaksud Restore adalah menyimpan kembali file terhapus yang ada pada komputer ke dalam memori card. Selain menyimpan kembali file yang sudah dipindahkan, fitur ini juga dapat digunakan untuk memindahkan data dari komputer ke memori card.

Asalkan formatnya adalah FMB. Caranya cukup menekan icon folder yang ada di sebelah boks Filename to Restore. Kemudian tentukan file yang akan dipindahkan ulang, kemudian tekan tombol Open. Setelah selesai menentukan file, tekan tombol Restore.

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhaLmfGOlBlDNgyc3knG-46H01Ix-Jqd3aVZPSXKmLwYLcth04TVmJYCQIWUt1QM5Dge35sbLTunwlBRQKknFbVgNwpDC-gRgxYuKcHRKiiw-SO0Eh2ClDugHqeZrjCle6myDhOH-DB40rsAsqzWIrNIOjaxB1RDcxXuZPclAnl_bAjJsSTvZBFJK50DA/w640-h478/file-terhapus.png)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhaLmfGOlBlDNgyc3knG-46H01Ix-Jqd3aVZPSXKmLwYLcth04TVmJYCQIWUt1QM5Dge35sbLTunwlBRQKknFbVgNwpDC-gRgxYuKcHRKiiw-SO0Eh2ClDugHqeZrjCle6myDhOH-DB40rsAsqzWIrNIOjaxB1RDcxXuZPclAnl_bAjJsSTvZBFJK50DA/s640/file-terhapus.png)  
 ### **Duplicate**

Duplicate atau duplikasi dapat dilakukan langsung antar media yang terpasang tanpa harus memasukkan data ke komputer terlebih dahulu. Sebelum proses duplikasi dimulai, terlebih dahulu anda siapkan media (memori card) yang akan digunakan sebagai duplikatnya.

Setelah itu barulah proses dimulai. Caranya tekan tombol Duplicate pada memori card yang ingin diduplikasi. Setelah komputer selesai membaca isi media yang pertama, ia akan meminta media lain sebagai tempat duplikasi. Masukkan memori card, lalu tekan OK. Hati-hati, karena bila terdapat isi pada media yang kedua, komputer secara otomatis akan menghapusnya.

### **Recovery Data**

Ini adalah halaman utama yang dinanti-nanti. Anda dapat me-recovery file terhapus dari memori card anda menggunakan aplikasi recovery data ini. Caranya sangat mudah, namun yang perlu diingat adalah jangan menyimpan apapun dahulu sebelum data hilang pada media selesai direcovery.

Sebelum proses recovery dimulai, tekanlah tombol Option untuk menentukan format apa saja yang ingin di recover. Dibalik tombol Option, anda juga diminta untuk menentukan folder tempat file recovery akan berada, serta atribut lainnya yang berhubungan dengan proses Recovery.

### **Format Media Card**

Anda juga dapat langsung memformat media yang diinginkan melalui aplikasi recovery data ini. Semua atribut format lengkap disediakan pada halaman ini. Mulai dari format sistemnya sampai nama medianya. Format system yang ditawarkan umum, yaitu Quick dan Full.

Bila menggunakan Quick, maka semua data hilang akan dihapus oleh komputer, hanya saja cara ini tidak akan me-recover blok rusak yang ada di media. Sedangkan dengan cara yang kedua (Full), tidak hanya data hilang yang akan dihapus tapi blok rusak juga akan di perbaiki. Hanya saja waktunya lebih panjang dari Quick.

Menampilkan file tersembunyi pada kartu SD Dan Flash Disk menggunakan CMD
-------------------------------------------------------------------------

Ada kemungkinan bahwa beberapa file di kartu SD Anda telah disembunyikan. CMD dapat digunakan untuk membuka file rahasia pada kartu SD atau flash drive. Sangat penting untuk memahami mengapa file disembunyikan untuk menghindari lebih banyak masalah.

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjGdG9EUlWVBhycLGYNgdlyMiG4Qx4N81qVX7sASLfTHyJaeiduqn4fHaMCvSscOWjZQCrPAErOOcWGe0gHzYIj-arcS72G3AQQPOVmb7QdhFNm1v_rbT2t0jZAzfBRuKp6XiklffqV0D9yCApVqphWW0VjXdcXuIDiSculgDzylB-x5DnstPRQYMaWhQ/w640-h490/data-hilang1.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjGdG9EUlWVBhycLGYNgdlyMiG4Qx4N81qVX7sASLfTHyJaeiduqn4fHaMCvSscOWjZQCrPAErOOcWGe0gHzYIj-arcS72G3AQQPOVmb7QdhFNm1v_rbT2t0jZAzfBRuKp6XiklffqV0D9yCApVqphWW0VjXdcXuIDiSculgDzylB-x5DnstPRQYMaWhQ/s1112/data-hilang1.jpg)  
 ### Cara menggunakan CMD untuk memulihkan file tersembunyi dari kartu SD

1. Langkah 1: sambungkan card reader paka komputer anda, kemudian sambungkan kartu SD ke komputer Anda.
2. Langkah 2: Di jendela Run, tekan `Windows + R` dan ketik `CMD`
3. Langkah 3: Ketik perintah "attrib" ke jendela command prompt untuk membuat file tersembunyi terlihat. `attrib -h -r -s /s /d E:\*.*` (ganti E dengan huruf drive kartu SD) harus menjadi perintah lengkap.

Kesimpulan
----------

Semoga, Anda akan dapat memulihkan file terhapus dengan benar dari kartu MMC setelah menggunakan Alat Pemulihan Kartu MMC. Ketika Anda kehilangan data pada kartu multimedia Anda, hal pertama yang harus Anda lakukan adalah memeriksa apakah Anda memiliki cadangan. Ada baiknya jika Anda memiliki Flashdik atau MMC cadangan karena Anda dapat dengan mudah mengembalikan data yang hilang dari sana.

Untuk mengembalikan file terhapus dari kartu MMC, Anda dapat menggunakan opsi prompt perintah. Jadi, saya yakin solusi ini cukup untuk orang yang salah kehilangan data dari kartu MMC.

 


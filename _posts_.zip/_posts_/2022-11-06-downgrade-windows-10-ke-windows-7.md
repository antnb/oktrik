---
layout: post
title: downgrade windows 10 ke windows 7
date: '2022-11-06T18:39:00.003+07:00'
author: rosari J
tags:
- windows
modification_time: '2022-11-06T18:41:33.435+07:00'
blogger_id: tag:blogger.com,1999:blog-7329298365997944344.post-3992343612750777196
blogger_orig_url: https://www.oktrik.com/2022/11/downgrade-windows-10-ke-windows-7.html
---

Windows 10 adalah sistem operasi komputer pribadi yang dikembangkan dan dirilis oleh Microsoft sebagai bagian dari keluarga sistem operasi Windows NT. Itu dirilis pada 29 Juli 2015.


Windows 10 memperkenalkan fitur baru yang digambarkan Microsoft sebagai "aplikasi universal"; memperluas aplikasi bergaya Metro, aplikasi ini dapat dirancang untuk berjalan di beberapa keluarga produk Microsoft dengan kode yang hampir sama‍ termasuk PC, tablet, smartphone, sistem tertanam, Xbox One, dan HoloLens.

[![interface windows 10](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEj53eafizmkezPWhajN-T9Pq3lJfTxgeG5g9_Tv-QNpi_QCQltcM2ERbwQOehOmrWtIsvy6Ko5gQSmzewTs2P89puLMc-CpvhspLYUzvy-ZccTTNXgjpiokESNHnPOI85QdynsAPvelYH-3ZdOtbMRZvXoLU0w1MRFp2ZSgmBHfS79NEr70h_mg2N63SA/w640-h390/interface.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEj53eafizmkezPWhajN-T9Pq3lJfTxgeG5g9_Tv-QNpi_QCQltcM2ERbwQOehOmrWtIsvy6Ko5gQSmzewTs2P89puLMc-CpvhspLYUzvy-ZccTTNXgjpiokESNHnPOI85QdynsAPvelYH-3ZdOtbMRZvXoLU0w1MRFp2ZSgmBHfS79NEr70h_mg2N63SA/s1395/interface.jpg)  
 
Antarmuka pengguna Windows 10 dirancang untuk menangani transisi antara antarmuka berorientasi mouse dan antarmuka yang dioptimalkan untuk layar sentuh berdasarkan perangkat input yang tersedia​—​​terutama pada PC 2-in-1, kedua antarmuka menyertakan menu Mulai yang diperbarui yang menggabungkan elemen menu Start tradisional Windows 7 dengan tile Windows 8.


Windows 10 juga memperkenalkan Task View, sistem desktop virtual, browser web Microsoft Edge, dukungan untuk login sidik jari dan pengenalan wajah, fitur keamanan baru seperti Microsoft Passport, dan integrasi langsung dengan OneDrive (dan platform penyimpanan berbasis cloud lainnya).


Windows 10 menerima sebagian besar ulasan positif setelah dirilis. Kritikus memuji keputusan Microsoft untuk menyediakan antarmuka berorientasi desktop yang sejalan dengan versi Windows sebelumnya, kontras dengan pendekatan berorientasi tablet Windows 8. Namun, beberapa pengulas mengkritik perubahan perilaku sistem operasi, termasuk pembaruan wajib, masalah privasi atas data. pengumpulan dilakukan oleh OS, dan adware disertakan dengan instalasi default.


Microsoft bertujuan untuk menginstal Windows 10 pada setidaknya satu miliar perangkat dalam dua hingga tiga tahun pertama peluncurannya. Terlepas dari tujuan ini, dan sebagian karena struktur harganya yang kontroversial, pada Juni 2018, pangsa pasar Windows 10 hanya 27%.


Alasan User ingin melakukan downgrade window 10 ke window 7
-----------------------------------------------------------


Alasan utama mengapa pengguna PC tidak menyukai Windows 10 salah satunya adalah opsi update yang dipaksakan. opsi update ini tidak hanya mengganggu, tetapi juga berpotensi merusak system. Di masa lalu, Microsoft telah merilis pembaruan yang menyebabkan layar biru kematian, file rusak, dan masalah serius lainnya. Berikut ini adalah alasan alasan utama para pengguna ingin mendowngrade OS mereka:


### Windows 10 di kritik karena diketahui melakukan pelanggaran privasinya


Windows 10 telah dikritik oleh banyak orang karena pelanggaran privasinya. Sistem operasi telah diketahui mengumpulkan banyak data dari pengguna, yang telah menimbulkan kekhawatiran tentang seberapa aman data tersebut. Selain itu, Microsoft diketahui menggunakan taktik menipu untuk membuat pengguna meningkatkan ke Windows 10, yang juga menyebabkan masalah privasi.


### masalah performance


Windows 10 telah diketahui menyebabkan masalah kinerja pada beberapa komputer. Sistem operasi telah diketahui menggunakan banyak sumber daya, yang dapat menyebabkan kinerja lebih lambat. Selain itu, beberapa fitur Windows 10 dapat menghabiskan banyak sumber daya, yang juga dapat menyebabkan masalah kinerja.


### masalah keamanan


Windows 10 telah diketahui memiliki masalah keamanan. Sistem operasi telah dikenal rentan terhadap malware dan ancaman keamanan lainnya. Selain itu, Microsoft telah dikenal untuk merilis pembaruan keamanan yang dapat merusak kompatibilitas dengan beberapa perangkat lunak dan perangkat keras.


### sulit digunakan


Windows 10 memang dikenal sulit digunakan bagi sebagian orang. Sistem operasi bisa rumit untuk digunakan, dan beberapa fitur mungkin sulit ditemukan. Selain itu, Windows 10 mungkin sulit untuk dikustomisasi, sehingga sulit digunakan oleh sebagian orang.


Cara downgrade windows 10 ke windows 7
--------------------------------------


Jika Anda memiliki komputer yang disertakan dengan Windows 10, Anda mungkin tidak menyukai sistem operasi yang baru tersebut. Mungkin Anda lebih suka interface Windows 7 yang lama, atau Anda mungkin bukan penggemar browser Microsoft Edge yang baru. Apapun alasannya, jika Anda ingin melakukan downgrade Windows 10, sebenarnya caranya cukup mudah untuk dilakukan.


Berikut cara downgrade Windows 10 dan kembali ke Windows 7 atau 8.1.


Persiapan Sebelum Proses downgrade
----------------------------------


Sebelum Anda melakukan downgrade Windows 10, ada beberapa hal yang harus Anda lakukan terlebih dahulu.


* Pertama, Anda harus memiliki serial number atau windows key yang valid untuk versi Windows yang ingin Anda turunkan versinya. Jika Anda tidak memiliki serial number tersebut, maka proses downgrade tidak akan bisa dilakukan.
* Kedua, backup seluruh file penting yang tersimpan dalam hard drive. Dengan begitu, jika terjadi kesalahan selama Proses downgrade windows, Anda masih memiliki file back up untuk digunakan kembali.
* Terakhir, pastikan Anda memiliki semua driver yang Anda butuhkan untuk versi Windows yang Anda turunkan versinya. Misalnya, jika Anda menurunkan versi dari Windows 10 ke Windows 7, Anda harus memastikan bahwa Anda memiliki driver yang tepat untuk kartu suara, kartu video, dan perangkat keras lain yang Anda miliki.


Jika semua langkah tersebut diatas telah dilakukan,maka anda telah siap untuk melakukan downgrade windows. Berikut adalah langkah dalam mendowngrade windows .


Cara menurunkan versi Windows 10


1. Buka Pengaturan > Perbarui & keamanan > Pemulihan.
2. Di bawah "Kembali ke versi sebelumnya", klik Mulai.
3. Ikuti petunjuk di layar. Anda akan ditanya mengapa Anda menurunkan versi, dan Anda harus memberikan kunci produk yang valid untuk versi Windows yang Anda turunkan.
4. Setelah proses selesai, komputer Anda akan restart dan Anda akan menjalankan versi Windows yang lebih lama.


Itu saja! Menurunkan versi dari Windows 10 ke versi Windows yang lebih lama cukup mudah, dan hanya membutuhkan beberapa menit. Pastikan Anda memiliki kunci produk yang valid untuk versi Windows yang Anda turunkan versinya, dan Anda memiliki semua driver yang Anda butuhkan.


Downgrade windows Melalui ISO
-----------------------------


Sudah lebih dari setahun sejak Microsoft merilis Windows 10, dan sistem operasinya secara umum diterima dengan baik. Tetapi seperti halnya perangkat lunak baru, pasti ada beberapa bug dan gangguan. Jika Anda mengalami masalah dengan Windows 10, atau hanya ingin kembali ke versi OS sebelumnya, Anda dapat melakukannya dengan menurunkan versi salinan Windows 10 Anda.


Berikut cara downgrade Windows 10 dan kembali ke Windows 7 atau 8.1:


Sebelum Anda mulai, pastikan Anda memiliki cadangan file penting Anda karena Anda akan melakukan instalasi bersih dari versi Windows sebelumnya.


1. Unduh Alat Pembuatan Media Windows 10 dari Microsoft.
2. Jalankan alat dan pilih "Buat media instalasi untuk PC lain".
3. Pilih bahasa, edisi, dan arsitektur (64-bit atau 32-bit) untuk Windows 10.
4. Pilih "USB flash drive" sebagai media untuk membuat.
5. Hubungkan flash drive USB dengan setidaknya 4GB ruang kosong.
6. Klik "Next" dan alat akan membuat media instalasi Windows 10.
7. Setelah proses selesai, buka USB flash drive dan klik dua kali pada file "Setup.exe" untuk memulai proses downgrade.
8. Pilih "Instalasi khusus" saat diminta.
9. Pada "Di mana Anda ingin menginstal Windows?" layar, pilih partisi atau drive tempat Anda ingin menurunkan versi ke Windows 7 atau 8.1.
10. Klik "Format" dan kemudian "Berikutnya" untuk melanjutkan.
11. Proses instalasi sekarang akan dimulai. Ikuti petunjuknya dan pilih pengaturan Anda sampai proses selesai.


Setelah downgrade selesai, Anda akan menjalankan versi Windows sebelumnya. Jika ternyata Anda masih ingin menggunakan Windows 10, Anda selalu dapat memutakhirkan lagi dengan menjalankan Media Creation Tool dan memilih opsi "Tingkatkan PC ini sekarang".


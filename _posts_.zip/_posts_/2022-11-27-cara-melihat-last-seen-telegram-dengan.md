---
layout: post
title: Cara melihat last seen telegram Dengan Mudah
date: '2022-11-27T16:56:00.000+07:00'
author: rosari J
tags:
- telegram
modification_time: '2022-11-27T16:56:06.648+07:00'
blogger_id: tag:blogger.com,1999:blog-7329298365997944344.post-1608531960216549082
blogger_orig_url: https://www.oktrik.com/2022/11/cara-melihat-last-seen-telegram-dengan.html
---

Telegram telah menambahkan fitur baru yang berguna, yakni Last Seen. Fitur ini memungkinkan pengguna untuk melihat waktu terakhir kapan seseorang menggunakan aplikasi Telegram.


Biasanya, pengguna hanya bisa melihat waktu terakhir aktif seseorang di aplikasi seluler, namun sekarang pengguna juga dapat melihat waktu terakhir kapan seseorang menggunakan Telegram di perangkat lain, seperti PC atau laptop.


Fitur Last Seen Telegram ini berguna untuk mengetahui seberapa sering seseorang menggunakan aplikasi Telegram. Selain itu, pengguna juga dapat melihat waktu terakhir aktif seseorang di perangkat lain, seperti PC atau laptop.


Fitur Last Seen Telegram ini berguna untuk mengetahui seberapa sering seseorang menggunakan aplikasi Telegram. Selain itu, pengguna juga dapat melihat waktu terakhir aktif seseorang di perangkat lain, seperti PC atau laptop. Dengan fitur ini, pengguna dapat lebih mudah mengontrol privasi dan keamanan akun Telegram.


[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjMmv_8waQ2vXofkDPvnKdYCFG2oiB-YPZwW40e7_mcqidvUQFM7RRxF06zNi14TpD1FtZf8kdIuKodQkGHpOl2wNNG265C-JOJhRMYwWAOfL85ZirWubIv_W7GegiUCPRUeIvdl-6tx2-b7qF9_vHVj1wlqJQXHu8UziYXmG7c5Cx5VZ4SIF6ZXSNXTw/s400/last%20seen.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjMmv_8waQ2vXofkDPvnKdYCFG2oiB-YPZwW40e7_mcqidvUQFM7RRxF06zNi14TpD1FtZf8kdIuKodQkGHpOl2wNNG265C-JOJhRMYwWAOfL85ZirWubIv_W7GegiUCPRUeIvdl-6tx2-b7qF9_vHVj1wlqJQXHu8UziYXmG7c5Cx5VZ4SIF6ZXSNXTw/s1511/last%20seen.jpg)
Mengapa Banyak pengguna telegram mengaktifkan Fitur "Last Seen"
---------------------------------------------------------------


Banyak pengguna Telegram mengaktifkan fitur ini karena banyak keuntungan yang bisa didapatkan. Pertama, pengguna bisa tahu kapan seseorang aktif di aplikasi. Kedua, pengguna bisa tahu kapan seseorang akan aktif di aplikasi sehingga pengguna bisa mengirimkan pesan tepat waktu. Ketiga, pengguna bisa mengetahui apakah seseorang sedang sibuk atau tidak.


Namun, ada juga beberapa kelemahan dari fitur ini. Pertama, pengguna bisa dengan mudah mengetahui waktu terakhir kapan seseorang menggunakan aplikasi. Kedua, beberapa orang menganggap fitur ini sebagai fitur yang menyebalkan karena bisa membuat orang lain tahu apakah mereka sedang sibuk atau tidak.


Cara mengaktifkan fitur privasi last seen di aplikasi Telegram
--------------------------------------------------------------


Untuk mengaktifkan fitur privasi last seen, pengguna Telegram perlu mengakses menu pengaturan aplikasi. Dalam menu pengaturan, pengguna perlu menemukan opsi privasi dan keamanan. Opsi privasi dan keamanan memungkinkan pengguna untuk mengakses pengaturan privasi dan keamanan aplikasi. Dalam opsi privasi, pengguna perlu menemukan opsi last seen. Opsi last seen memungkinkan pengguna untuk mengatur siapa yang bisa melihat waktu terakhir kali mereka online. Pengguna juga bisa mengatur agar last seen hanya ditampilkan kepada teman atau orang-orang tertentu saja. Untuk mengaktifkan atau menonaktifkan fitur Last Seen Telegram, pengguna perlu masuk ke Pengaturan (Settings), lalu pilih Privasi dan keamanan (Privacy and Security).


Setelah itu, pengguna dapat mengaktifkan atau menonaktifkan fitur Last Seen Telegram sesuai keinginan. Untuk mengaktifkan atau menonaktifkan fitur Last Seen Telegram, pengguna perlu masuk ke Pengaturan (Settings), lalu pilih Privasi dan keamanan (Privacy and Security).


Bagaimana cara melihat last seen telegram?
------------------------------------------


Last seen Telegram adalah fitur yang menunjukkan waktu terakhir kapan pengguna menggunakan aplikasi. Fitur ini berguna untuk mengetahui apakah teman Anda sedang online atau tidak. Untuk mengaktifkan atau menonaktifkan last seen Telegram, ikuti langkah-langkah di bawah ini.


Bagaimana cara melihat last seen Telegram?


1. 1. Buka aplikasi Telegram dan masuk ke Pengaturan.
2. 2. Pilih Privasi dan Keamanan.
3. 3. Pilih Last Seen.
4. 4. Anda akan melihat opsi untuk mengaktifkan atau menonaktifkan last seen Telegram. Pilih opsi yang Anda inginkan.
5. 5. Jika Anda ingin mengaktifkan last seen Telegram, Anda akan melihat opsi untuk menentukan siapa yang dapat melihat last seen Anda. Pilih opsi yang Anda inginkan.
6. 6. Tekan Simpan.
7. 7. Selesai!


Bagaimana cara menonaktifkan last seen Telegram?
------------------------------------------------


Last seen adalah fitur yang berguna, tetapi juga dapat menjadi hal yang mengganggu bagi beberapa orang. Untungnya, Telegram memungkinkan Anda untuk menonaktifkan fitur last seen jika Anda tidak ingin dilihat oleh orang lain.


Berikut adalah panduan singkat tentang bagaimana cara menonaktifkan last seen Telegram:


1. Buka aplikasi Telegram di perangkat Anda.
2. Pilih "Settings" dari menu drop-down di sisi kanan atas layar.
3. Pilih "Privacy and Security" dari daftar opsi yang tersedia.
4. Di bawah "Privacy", Anda akan melihat opsi "Last seen". Pilih "Nobody" dari daftar opsi.
5. Anda sekarang telah berhasil menonaktifkan fitur last seen Telegram. Selanjutnya, orang lain tidak akan dapat melihat kapan Anda terakhir online.


Cara Melihat Last Seen Telegram Yang Disembunyikan
--------------------------------------------------


Mungkin kamu pernah mengalami situasi dimana seseorang mengirimkan pesan kepada kamu via Telegram, namun kamu tidak bisa melihat waktu terakhir kali mereka online. Padahal, kamu sangat ingin tahu apakah mereka sedang mengabaikan pesanmu atau tidak.


Nah, jika kamu ingin tahu cara melihat last seen Telegram yang disembunyikan, simaklah informasi berikut ini.


Last seen Telegram adalah fitur yang menampilkan waktu terakhir kali seseorang online di Telegram. Fitur ini sangat bermanfaat untuk mengetahui apakah seseorang sedang mengabaikan pesanmu atau tidak.


Namun, ada juga beberapa orang yang tidak ingin diketahui oleh orang lain waktu terakhir kali mereka online. Untuk itu, Telegram menyediakan opsi untuk menyembunyikan last seen.


Cara Melihat Last Seen Telegram Yang Disembunyikan


1. Buka aplikasi Telegram di ponsel kamu.
2. Pada menu utama, buka opsi Pengaturan.
3. Pada opsi Pengaturan, buka opsi Privasi dan Keamanan.
4. Pada opsi Privasi dan Keamanan, kamu akan melihat opsi Last Seen. Ubah opsi ini menjadi Sembunyikan Last Seen.
5. Selanjutnya, buka opsi Who Can See My Last Seen.
6. Pada opsi Who Can See My Last Seen, kamu bisa memilih opsi My Contacts atau Everybody. Jika kamu memilih opsi My Contacts, maka hanya teman yang ada di kontak kamu yang bisa melihat waktu terakhir kali kamu online.
7. Sedangkan, jika kamu memilih opsi Everybody, maka semua orang yang menggunakan Telegram bisa melihat waktu terakhir kali kamu online.
8. Kamu juga bisa memilih opsi Nobody jika kamu tidak ingin siapapun tahu waktu terakhir kali kamu online.
9. Setelah itu, klik tombol Simpan.
10. Selesai.


Jadi, sekarang Anda tahu bagaimana cara melihat Telegram terakhir yang dilihat oleh seseorang. Selamat mencoba!


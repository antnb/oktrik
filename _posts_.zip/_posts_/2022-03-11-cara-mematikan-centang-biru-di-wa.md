---
layout: post
title: Cara Mematikan Centang Biru Di Wa Dengan Cepat Dan Mudah
date: '2022-03-11T11:05:00.002+07:00'
author: rosari J
tags:
- pesan
- whatsapp
- android
modification_time: '2022-07-20T21:49:46.057+07:00'
blogger_id: tag:blogger.com,1999:blog-7329298365997944344.post-2644254826263800940
blogger_orig_url: https://www.oktrik.com/2022/03/cara-mematikan-centang-biru-di-wa.html
---

 Apa ada cara mematikan centang biru di wa? Adalah pertanyaan yang paling
 sering ditanyakan oleh para pengguna whatsapp yang sedang malas untuk 
membalas pesan text yang masuk, Hal ini dikarenan jika pesan masuk 
tersebut tidak dibalas sedangkan telah terdapat tanda ceklis dua maka si
 penerima tentunya akan merasa sungkan terhadap si pengirim pesan.

Tentang tanda centang Biru Pada Aplikasi Whatsapp
-------------------------------------------------


Tanda centang biru/ceklis biru telah digunakan oleh WhatsApp sejak 
lama, Tanda ini digunakan untuk menunjukkan kepada pengirim bahwa 
penerima yang dituju telah menerima dan membaca pesan yang dikirimkannya
 tersebut. Namun, tidak semua orang menyukai centang biru ini, dan 
banyak orang ingin mematikan centang biru wa karena berbagai alasan.


Oleh karena alasan tersebut diatas, WhatsApp menyediakan opsi untuk 
mematikan centang biru di WA ini, Hal memungkinkan pengirim untuk tetap 
tidak mengetahui apakah sang penerima pesan telah menerima pesan atau 
tidak. Saat Anda mematikan fitur centang biru, fitur ini akan tetap 
dimatikan untuk pesan baru yang akan masuk sehingga Anda perlu untuk 
mengaktifkannya kembali.


Hari ini, kami akan menunjukkan cara mematikan centang biru di wa di [Android](https://www.oktrik.com/search/label/android) dan iOS. Jika Anda menggunakan fungsi yang sama untuk melihat status online seseorang, Anda tidak akan terlihat.

[![gambar tanda baca receipt whatsapp](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEi5yoNDvh0nizOuLm75OoK8c9__B-7P_o3DuXEWbGx6H_YO6UdTt5BAnWNKNMtbWHUc8-OpOhhwHOJt6ZGmhfuvKe-u0jPgnLqJNb_G27QrZVVP68BTH8MBzVzdwwVi20baPGfxc48w25HTPtBUQJKGXLsmUblqdLYnZJ84c9fICIQickPMvORBkVthPg/w640-h376/receipt-1024x602.jpg "Reading receipt")](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEi5yoNDvh0nizOuLm75OoK8c9__B-7P_o3DuXEWbGx6H_YO6UdTt5BAnWNKNMtbWHUc8-OpOhhwHOJt6ZGmhfuvKe-u0jPgnLqJNb_G27QrZVVP68BTH8MBzVzdwwVi20baPGfxc48w25HTPtBUQJKGXLsmUblqdLYnZJ84c9fICIQickPMvORBkVthPg/s1024/receipt-1024x602.jpg)  
 Cara Mematikan centang biru di whatsapp Grup
--------------------------------------------


Perlu untuk diingat bahwa mematikan centang biru di wa atau tanda 
terima baca hanya bisa diterapkan pada menu obrolan individu. Sedangkan 
ntuk obrolan grup, opsi cara mematikan centang biru wa ini tidak dapat 
diterapkan di aplikasi obrolan. Dengan menggunakan layar info grup, 
pengirim dapat melihat apakah Anda telah membaca pesan tersebut.


Tanda terima telah dibaca adalah fitur centang biru yang, jika 
dinonaktifkan, akan membuat si pengirim tidak menerima pemberitahuan 
apakah pesan telah terbaca atau tidak meskipun dia telah membaca pesan 
yang dikirrimkan namun jika opsi ini diaktifkan, Maka tanda terima atau 
ceklis dua tidak akan mucul. Dengan begitu berarti Anda tidak harus 
segera membalas pesan dan dapat meluangkan waktu Anda untuk urusan 
lainnya.


Seperti telah dijelaskan diatas, Jika Anda adalah anggota grup WA 
yang sedang mencari cara untuk menonaktifkan tanda terima baca di 
Whatsapp untuk grup tertentu, Maka anda tidak akan dapat melakukannya 
untuk saat ini, karena untuk saat ini belum tersedia. Namun fitur ini 
akan tersedia di kemudian hari.

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhuxAvq6keimX0iUiqECiqFg3LE1nsE6nITyUUf242i4l5zBiT7WBkUcQj-IXpeM0euk5S8nuWeJxMc7wRjodtKNYPnPBIXdO4bcSwWsJEOXV_vsxfqgYr_kNInlRcsMpPy84YXN7oWCxuWkVCV_StiAi0g7ZjxnrlWqdlYMbkd9PlRWfuNJ9M2DHI96A/w640-h484/wa-1024x774.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhuxAvq6keimX0iUiqECiqFg3LE1nsE6nITyUUf242i4l5zBiT7WBkUcQj-IXpeM0euk5S8nuWeJxMc7wRjodtKNYPnPBIXdO4bcSwWsJEOXV_vsxfqgYr_kNInlRcsMpPy84YXN7oWCxuWkVCV_StiAi0g7ZjxnrlWqdlYMbkd9PlRWfuNJ9M2DHI96A/s1024/wa-1024x774.jpg)  
Cara agar wa centang 1 setelah terbaca
--------------------------------------


Tidak sedikit pengguna WA yang dipusingkan tentang cara mematikan 
centang biru di wa. Padahal caranya sangat mudah, Anda dapat membaca 
seluruh pesan yang terkirim kepada anda tanpa memunculkan notifikasi 
centang biru. Dan pengirim pesan pun tidak akan mengetahui apabila anda 
mengaktifkan fitur ini pada whatsapp.


**Pengirim tidak akan dapat mengetahui apakah Anda telah membaca pesan tersebut**.


Untuk melakukan hal itu maka Anda harus menonaktifkan tanda terima 
baca di setingan Whatsapp untuk mematikan centang biru wa. Namun, Anda 
harus ingat bahwa jika Anda menonaktifkan centang biru pada tanda terima
 membaca, Maka anda tidak akan pernah tau apakah orang tersebut telah 
membaca pesan teks Anda atau tidak.

 

[![tanda baca whatsapp](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhArgmmZs-EGJdYLvQ91A1G0LgHdCr7fxDQJi3ftImlS5jiUkUJVEaKZWmprICkYaWCd9IfDYsLHjnbuMXOEei56Fyo0Q2SrcVVLcDLfkkZk7f5RuBG7Q-5QSVUFK72K4LjLzolaSqd2ARksuNhI-yXGCebL0tsl7GKvK0PzKV_9MiuZz6pKP9y1HLcWw/w640-h376/Blue-Tick-Marks-1024x602.jpg "Blue Tick Marks")](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhArgmmZs-EGJdYLvQ91A1G0LgHdCr7fxDQJi3ftImlS5jiUkUJVEaKZWmprICkYaWCd9IfDYsLHjnbuMXOEei56Fyo0Q2SrcVVLcDLfkkZk7f5RuBG7Q-5QSVUFK72K4LjLzolaSqd2ARksuNhI-yXGCebL0tsl7GKvK0PzKV_9MiuZz6pKP9y1HLcWw/s1024/Blue-Tick-Marks-1024x602.jpg)  
Langkah untuk mematikan centang biru di wa
------------------------------------------


Untuk melakukannya, ikuti langkah-langkah berikut:


1. Ketuk tiga titik vertikal di sudut kanan atas layar untuk membuka WhatsApp.
2. Apa cara terbaik untuk mematikan tanda terima baca di Whatsapp?
3. Pilih Pengaturan dari menu tarik-turun.
4. Pilih Akun dari menu tarik-turun.
5. Opsi Baca Tanda Terima ditemukan di bawah opsi Privasi.
6. Cukup geser ke kiri untuk mematikannya, dan selesai.


cara membuat whatsapp centang 1 tanpa aplikasi Menggunakan Mode Flight
----------------------------------------------------------------------


Beberapa orang ingin mengetahui status pesan yang telah dikirimkan, 
Apakah sudah terbaca oleh penerima atau belum. Itu sebabnya mereka tidak
 ingin menonaktifkan fitur tanda terima baca untuk komunikasi WhatsApp, 
tetapi mereka juga tidak ingin pengirim mengetahui bahwa pesan telah 
dibaca.


Dalam skenario ini, Anda harus mengaktifkan mode Flight di ponsel 
Anda. Saat Anda menerima pesan WhatsApp yang ingin Anda lihat tetapi 
tidak tahu siapa yang mengirimnya, Anda dapat Mengaktifkan mode Flight.


Anda dapat melihat pesan WhatsApp dan mematikan mode airplane saat 
mode masih aktif. Ini berarti Anda tidak akan menggunakan data seluler 
apa pun, dan pengirim tidak akan mengetahuinya.


Dengan cara mematikan ceklis biru di wa ini, Anda masih dapat membaca
 pesan, tetapi pengirim tidak akan mengetahui jika anda telah membaca 
pesan tersebut, dan Anda dapat mematikan notifikasi centang biru wa 
dengan metode ini.

[![flight mode whatsapp](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgPLCp405juVka3JPAjiYZAKluO0w5n7d3FhYRvNrso0k06V3Pc-kORP4vOtGif0ixzz6Su1FbKxJB_R5mpWlDA6Q0VL9uiVbBCvYNacILuXkorYhjNOjP3uBS1rpEcfXP7AagwZwHt2OHQWYYrSpVveDrB0imDP7gRpMfYkZNynUqsStKTiTyJO_6Ijg/w640-h428/flight-1024x684.jpg "flight mode")](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgPLCp405juVka3JPAjiYZAKluO0w5n7d3FhYRvNrso0k06V3Pc-kORP4vOtGif0ixzz6Su1FbKxJB_R5mpWlDA6Q0VL9uiVbBCvYNacILuXkorYhjNOjP3uBS1rpEcfXP7AagwZwHt2OHQWYYrSpVveDrB0imDP7gRpMfYkZNynUqsStKTiTyJO_6Ijg/s1024/flight-1024x684.jpg)  
 Bagaimana saya bisa mengirim pesan Whatsapp kosong?
---------------------------------------------------


Untuk meningkatkan tingkat privasi Anda, Ada satu hal terakhir yang 
dapat anda lakukan . Yaitu dengan opsi untuk mematikan last seen wa. 
Artinya, tidak ada yang bisa mengetahui kapan Anda terakhir online. Cara
 mematikan status terakhir dilihat sangatlah mudah.


Buka Pengaturan WhatsApp setelah membuka aplikasi. Setelah itu, buka 
Akun dan kemudian Privasi. Anda kemudian dapat mematikan status 
pengiriman.


Mematikan Centang Biru Di Grup Whatsapp?
----------------------------------------


Banyak pengguna WA yg bertanya mengenai cara mematikan tanda terima 
baca di obrolan grup WhatsApp. WhatsApp, Sayangnya kita tidak dapat 
melakukan hal itu , Pihak Whatsapp belum menyediakan fitur seperti itu 
untuk perpesanan grup WhatsApp.


Cara mematikan centang biru di wa hanya bisa dilakukan untuk chat 
individu atau pribadi; opsi ini tidak tersedia untuk grup chat.  Dalam 
WA grup Jika Anda telah membaca pesan, maka tidak akan ada tanda centang
 abu-abu.


Bagaimana cara mematikan ceklis biru di wa Whatsapp Di iOS?
-----------------------------------------------------------


Pengguna iPhone harus terlebih dahulu meluncurkan WhatsApp lalu ketuk
 Pengaturan. Pilihan ini berada di dekat bagian bawah halaman.


Lalu buka Akun dan pilih Privasi dari menu tarik-turun. Opsi “Baca Tanda Terima” sekarang akan muncul.


Seharusnya ada menu yang dapat Anda geser untuk mematikan notifikasi 
ceklis biru. Dan hanyatanda centang abu-abu yang akan ditampilkan ke 
pengirim.


Bagaimana Saya Mematikan Tanda Terima Baca Di Ponsel Android Saya?
------------------------------------------------------------------


Langkahnya hampir sama dengan iOS. Buka aplikasi WhatsApp Anda dan 
ketuk tiga titik atau titik vertikal di sudut kanan atas untuk mematikan
 centang biru.

### Apa cara terbaik untuk mematikan tanda terima baca di Whatsapp?


Sekarang pilih Akun dari menu tarik-turun di bawah Pengaturan. Pada 
layar berikut, Anda akan melihat opsi “Baca Tanda Terima”, yang dapat 
Anda matikan dengan menggeser ke kiri.


Di layar percakapan, pengirim sekarang hanya akan melihat centang 
ganda yang tidak berwarna biru. Ini juga berarti bahwa tidak seorang pun
 akan dapat mengetahui apakah Anda telah melihat pembaruan status 
seseorang.


Namun Anda harus mencatat bahwa cara mematikan ceklis biru di wa ini 
tidak berfungsi dengan file audio WhatsApp. Pengirim masih tetap akan 
melihat tanda centang biru ketika Anda telah mendengar pesan suara 
WhatsApp.




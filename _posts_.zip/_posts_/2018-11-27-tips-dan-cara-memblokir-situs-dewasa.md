---
layout: post
title: Tips dan Cara Memblokir Situs Dewasa Dan Konten Bermuatan Negatif
date: '2018-11-27T18:15:00.007+07:00'
author: rosari J
tags:
- dns
- internet
- filtering
modification_time: '2022-07-12T11:47:56.945+07:00'
blogger_id: tag:blogger.com,1999:blog-7329298365997944344.post-7080374595330115111
blogger_orig_url: https://www.oktrik.com/2018/11/tips-dan-cara-memblokir-situs-dewasa.html
---

Seperti yang anda ketahui perkembangan dunia maya dewasa ini sangat lah pesat, terlebih setelah memasuki milenium baru atau memasuki awal tahun. jika sebelumnya akses dunia internet terbatas pada Hardware dan provider tertentu yang tidak semua orang mempunyai akses, namun saat ini hampir semua masyarakat mengenal dunia internet dimana dengan cepat kita dapat mendapatkan informasi apapun dimana pun dan kapan saja selama tersedia akses internet


Saat ini dunia maya dapat diakses dengan sangat mudah dan relatif cukup murah, Hampir semua masyarakat menggunakan ponsel pintar atau smartphone dan jalur data yang ditawarkan para penyedia akses internet pun beragam.


 


[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgTHQzKiTNXkFtF41-eMpzrBI34elfUNOPRh4tNLsaYTuCQzQ2dHCox9CNgKr3lm0Q_AO0a5xPLUQHkKtxJ4Dalsldc1-guUV8x6x1Zka61uOg5J0w9pqlyO-SDb4-OlLDyVUpKXEfH1H4Nues-aatLJS1Y2t4kx-nxn0wU-TiBPkxt0EA7T1rFOWSMGA/w640-h400/blokir-1-800x500.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgTHQzKiTNXkFtF41-eMpzrBI34elfUNOPRh4tNLsaYTuCQzQ2dHCox9CNgKr3lm0Q_AO0a5xPLUQHkKtxJ4Dalsldc1-guUV8x6x1Zka61uOg5J0w9pqlyO-SDb4-OlLDyVUpKXEfH1H4Nues-aatLJS1Y2t4kx-nxn0wU-TiBPkxt0EA7T1rFOWSMGA/s800/blokir-1-800x500.jpg)





Konten dewasa, Ujaran Kebencian Dan Konten Negatif Yang Berbahaya Di Internet
-----------------------------------------------------------------------------


Namun dibalik kemudahan tersebut terdapat pula dampak negatif yang dihasilkan seperti maraknya situs situs yang menyediakan konten Dewasa , konten kebencian, kekerasan dan lain lain. seseorang bahkan bisa dengan mudah mendapatkan informasi cara merakit bom dengan alat alat yang tersedia di dapur, dan hal ini dengan hanya  mengakses internet


Tentunya hal ini membuat cemas terutama para orang tua yang mempunyai anak anak yang masih berusia dibawah umur dimana mereka belum dapat menyaring informasi yang masuk atau mereka dapatkan saat melakukan browsing situs di internet.







Memblokir Situs Menggunakan DNs Filtering
-----------------------------------------


Banyak cara memblokir situs di google chrome hp dengan konten negatif tersebut, namun seiring waktu dan semakin canggihnya teknologi maka akan ditemukan pula cara melakukan [internet by pass menggunakan squid proxy]({{ site.baseurl }}{% post_url 2018-02-10-centos-cara-mudah-install-squid-proxy %}) terhadap cara pemblokiran tersebut


Berdasarkan pengalaman, cara terbaik dan efektif untuk *memblokir situs Dewasa* dan konten negatif ialah melakukan filter langsung pada koneksi internet yang digunakan atau melakukan filter pada DNS.


Pada umumnya para penyedia layanan internet telah menerapkan filter tersendiri namun ada kalanya filter tersebut tidak up to date sehingga banyak situs situs Dewasa atau pun situs judi dengan konten negatif lolos dari filter tersebut yang pada akhirnya di akses oleh putra dan putri kita







 [![norton connect safe](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjmg7Whj898_6IpppQXP_erwyLq1_sO42Z0pPLm1322Oo1UOc3m8FfPTR5KncerlC0ED4im3T7zrqGINLpTznCt6OW4STI72pWZTk0hbmjpf84bcYFikZTNcWYMGc0fG1aDoGceNPot474oIFMkRLmo-nLqtDzSpXkB0rTVbrtzieN8vU0BJvgVo7KDXA/w640-h418/nortonsafeconnect.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjmg7Whj898_6IpppQXP_erwyLq1_sO42Z0pPLm1322Oo1UOc3m8FfPTR5KncerlC0ED4im3T7zrqGINLpTznCt6OW4STI72pWZTk0hbmjpf84bcYFikZTNcWYMGc0fG1aDoGceNPot474oIFMkRLmo-nLqtDzSpXkB0rTVbrtzieN8vU0BJvgVo7KDXA/s1016/nortonsafeconnect.jpg)


  
 


 


Cara Memblokir Situs di google chrome dan hp android
----------------------------------------------------


1. **OPENDNS**  
OpenDns adalah salah satu penyedia Layanan Keamanan DNS yang berada dibawah naungan CISCO, OpenDns mempunyai Fitur Keamanan yang bernama [OpenDNS Family Shield](https://www.opendns.com:443/home-internet-security/) dan dalam fitur ini secara otomatis akan melakukan blokir situs-situs Dewasa yang tidak kehendaki
2. **Norton ConnectSafe**  
Layanan DNS yang kedua adalah layanan yang diberikan oleh Norton, Fitur ConnectSafe diberikan secara gratis dan pada keterangan yang tertera fitur dan layanan ini dikhususkan untuk memberikan proteksi terhadap serangan virus dan malware, namun begitu [Norton ConnectSafe](https://nortondns.com/faq/) pun akan memblokir situs situs yang dikategorikan kedalam situs Dewasa apabila kita mengaktifkan fitur tambahan ini dan tidak hanya Dewasa namun juga situs perjudian,Obat obat terlarang dan lain lain tergantung level filtering yang anda kehendaki







### **Konfigurasi DNS Pada Komputer, Gadget Dan Perangkat Anda**


Cara Memblokir Situs paling efektif ialah menggunakan **DNS Content filtering** ialah dengan langsung menerapkan sumber akses internet yang anda gunakan, dan jika Anda menggunakan Router. 


Kami menyarankan untuk memasang filter langsung pada Router anda sehingga semua jaringan yang anda gunakan otomatis menggunakan content filtering tadi sehingga anda tidak perlu repot lagi untuk melakukan setting pada perangkat anda


 


[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEidb-33yDSXzTMLEHF94k2HUhhICCPhwwj6zUQpGZB6SA2U37Omfr97pEXfXnO5xXs0IdcDWF_KURy9mp3wctfN3Zf3WIZfjmWLn8PpzeC-DASjfBh8gHOUTX7P8Oy8XUjm8gMePlTfdt_feFDo0dOCmcFpcRD9W12M4K32yziiNgrupFhCiEmGxkNaqA/w640-h392/dns1.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEidb-33yDSXzTMLEHF94k2HUhhICCPhwwj6zUQpGZB6SA2U37Omfr97pEXfXnO5xXs0IdcDWF_KURy9mp3wctfN3Zf3WIZfjmWLn8PpzeC-DASjfBh8gHOUTX7P8Oy8XUjm8gMePlTfdt_feFDo0dOCmcFpcRD9W12M4K32yziiNgrupFhCiEmGxkNaqA/s968/dns1.jpg)





### Konfig DNS Pada Router


Jika anda berlangganan layanan internet yang disediakan oleh Indihome, maka anda dapat mengakses router anda ( *Huawei HG8245A*) melalui url `http://192.168.100.1/` kemudian Login seperti biasa mengunakan user dengan level administrator kemudian pilih menu "Network Aplication" dan pada kolom menu sebelah kiri terdapat menu "DNS Configuration". Pada Fitur Ini terdapat pilihan untuk Merubah atau menambahkan DNS Server 


Masukan Alamat Dns yang kita dapatkan dari kedua provider Tersebut diatas Dan Klik Aply


 


[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEihYh7MGUIXVgvbSCCRRdhZpwP_Uaua8TwVEZlb2u0seVTkRO5i9N9IxYYWin7fFaf-X3ZsaSfftncCJzvYLFZ3N-WBs5KdzN2sBTNrR9F_ubruZDTJs723em3XJyJ7EAZu_KRzkuKioETqq_Wi7vkybSP4c7nmSM9iiJralI_fH8ROvm4lpTH1tE-7sQ/w640-h404/tcpv4.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEihYh7MGUIXVgvbSCCRRdhZpwP_Uaua8TwVEZlb2u0seVTkRO5i9N9IxYYWin7fFaf-X3ZsaSfftncCJzvYLFZ3N-WBs5KdzN2sBTNrR9F_ubruZDTJs723em3XJyJ7EAZu_KRzkuKioETqq_Wi7vkybSP4c7nmSM9iiJralI_fH8ROvm4lpTH1tE-7sQ/s746/tcpv4.jpg)





### **Konfig DNS Pada PC, Laptop**


Hampir serupa dengan cara yang telah dijelaskan diatas namun yang berbeda adalah seting diterapkan Tergantung pada `"Network Adapter"` yang kita Gunakan (Dial Up Atau LAN)   
Klik Kanan dan pilih "properties" pada Network Adapter tersebut, Kemudian Pilih Menu "Internet Protocol Version 4 (TCP/IPv4) dan kemudian kita masukan detail DNS nya


 


 


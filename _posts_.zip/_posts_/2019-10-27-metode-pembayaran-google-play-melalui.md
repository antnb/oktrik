---
layout: post
title: Metode Pembayaran Google Play Melalui Gopay, Kartu Kredit Dan Pulsa Telkomsel
date: '2019-10-27T12:06:00.001+07:00'
author: rosari J
tags:
- payment
- go-pay
- google play
modification_time: '2022-07-10T12:08:13.861+07:00'
blogger_id: tag:blogger.com,1999:blog-7329298365997944344.post-1370844787354766316
blogger_orig_url: https://www.oktrik.com/2019/10/metode-pembayaran-google-play-melalui.html
---

Google Play makin memudahkan para penggguna yang akan bertransaksi 
dengan menyediakan beragam metode pembayaran google play. Google Play 
Gift Card merupakan voucher yang bisa digunakan untuk berbelanja dan 
bertransaksi membeli berbagai macam layanan yang bersifat premium 
aplikasi android seperti game, musik atau lagu, buku, film dan 
lain-lain.


Cara untuk membeli Aplikasi dan Game berbayar di google play ada 
bermacam-macam. Mulai dari Kartu debit dan kartu kredit, pembayaran 
menggunakan pulsa telkomsel, Giftcard, membayar menggunakan Go-Pay, 
bahkan bisa juga menggunakan jasa pembayaran di minimarket seperti 
Indomaret atau Alfamart dengan membeli voucher goole play.


Berikut akan kami jelaskan secara singkat mengenai cara untuk membeli
 game atau aplikasi premium di Google Play dengan berbagai metode yang 
paling mudah dilakukan.

**Cara Beli Voucher, Game dan Aplikasi Google Play Lengkap**
------------------------------------------------------------


Simak penjelasan artikel di bawah ini tentang 4 cara beli Aplikasi dan Game Berbayar di Google Play.


### Metode Beli Aplikasi dan Game di Google Play menggunakan kartu debit atau kartu kredit


* Masuk pada aplikasi google play
* Pilih pada menu ‘akun’
* Pilih tambahkan metode pembayaran melalui kartu kredit atau debit
* Masukan nomer rekening kartu debit atau kredit mu yang berjumlah 16 digit angka.
* Jika berhasil, maka akan muncul 4 digit angka terakhir nomer kartu debit mu.
* Kemudian klik ‘simpan’


### Metode Beli Aplikasi dan Game di Google Play menggunakan Go-Pay


Gopay tak hanya bisa untuk bertransaksi atau membayar jasa Gojek 
saja, Namun bisa digunakan juga sebagai metode pembayaran google play 
dan ternyata cukup simple. Berikut Cara pembayaran Google Play via GOPAY



1. Masuk pada aplikasi google play
2. Pilih pada menu ‘akun’
3. Selanjutnya kamu dapat tambahkan metode pembayaran dan jadikan Go-Pay mu mejadi metode pembayaran utama di Google play tersebut.
4. Kemudian masukan nomer telepon yang digunakan untuk akses Gojek.
5. Kamu akan menerima pesan berupa kode untuk konfirmasi pada Google Play
6. Masukan kode OTP tersebut pada kolom yang di sediakan
7. Maka, kamu sudah bisa membeli aplikasi atau game premium dengan membayar lewat Go-Pay


### Metode Beli Voucher Google Play Melalui Indomaret atau Alfamaret


Membeli voucher fisik google play lewat Alfamaret atau Indomaret, 
biasanya tersedia di rak yang ada di minimarket tersebut. Kamu beli 
voucher tersebut sesuai dengan uang nominal yang tertera. Lalu kamu 
gosok voucher tersebut dan masukan kode tersebut pada menu tambahkan 
metode pembayaran google play. Dan kamu sudah bisa membeli game atau 
aplikasi premium yang ada di google playstore.

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhoVeC2i5ERatSlN8l8uPFXye5HcIBaCGyc2iSf0-zgQbkfH3EYRU6wsh8jS5wK1OOoJiChF1OvQia5JCDGQxkdCQkbXeFl-vXvFnBGgCLRULt7AyXmYiZf1cdsHjjOqEJAzTc-u_dvUkFHsA4D1QvA6r_fFCrjLQCjsZHCWgGa9XMgSNHt_pVB1Ya1xA/w640-h338/you-can-now-buy-google-play-gift-cards-in-7-11-yaww-world-of-buzz-5_640x337-1.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhoVeC2i5ERatSlN8l8uPFXye5HcIBaCGyc2iSf0-zgQbkfH3EYRU6wsh8jS5wK1OOoJiChF1OvQia5JCDGQxkdCQkbXeFl-vXvFnBGgCLRULt7AyXmYiZf1cdsHjjOqEJAzTc-u_dvUkFHsA4D1QvA6r_fFCrjLQCjsZHCWgGa9XMgSNHt_pVB1Ya1xA/s640/you-can-now-buy-google-play-gift-cards-in-7-11-yaww-world-of-buzz-5_640x337-1.jpg)  
 
### **Cara bayar google play dengan pulsa**


Google telah memudahkan Bagi kita yang tidak memiliki akses ke tiga 
cara yang telah dijelaskan  diatas, karena kita tahu tidak semua orang 
memiliki kartu kredit, GoPay atau bahkan malas untuk pergi ke indomart. 
Untuk itu kita bisa menggunakan [cara atau trik lain](https://www.oktrik.com/) yang lebih praktis yaitu melakukan pembayaran google play dengan pulsa operator yang kita gunakan seperti  **pulsa telkomsel**, xl, 3 . caranya seperti ini


1. Masuk pada aplikasi google play di ponsel android mu.
2. Klik menu berupa tanda garis tiga yang berderet kebawah
3. Pilih menu my account
4. Selanjutnya kamu pilih tambahkan metode pembayaran
5. Setelah itu kamu klik ‘enable’, biasa nya akan muncul secara 
otomatis dengan kartu sim apa yang digunakan. Semisal kamu menggunakan 
kartu telkomsel, maka tulisan yang akan muncul adalah ‘Enable Telkomsel 
Billing’.
6. Kemudian kamu akan menerima sms dari google play dan biaya sms tersebut ditanggung oleh dirimu.
7. Setelah itu, kamu mengisi formulir yang disediakan pada kolom di 
aplikasi google play. Isi data diri mu berupa nomer handphone, alamat 
dan lain sebagai nya
8. Jika telah selesai mengisi data diri, kemudian kamu klik ‘Save’
9. Langkah selanjutnya adalah melakukan konfirmasi bahwa data-data mu sudah tepat dan benar. Kemudian klik ‘Accept’ dan ‘Next’
10. Jika berhasil, maka pada menu metode pembayaran telah tersedia 
metode pembayaran google play dengan pulsa . Semisal kamu menggunakan 
kartu Telkomsel, maka akan muncul tulisan ‘Bill My Telkomsel Account’.
11. Kamu telah bisa membeli berbagai macam konten premium di google play. Dengan catatan, kamu mempunyai pulsa yang cukup.


Penutup
-------


Itulah metode pembayaran google play untuk pembelian aplikasi dan 
game berbayar menggunakan kartu debit atau kartu kredit, Go-Pay, lewat 
Indomaret atau Alfamaret dan juga metode pembayaran google play dengan 
pulsa . Kalian tinggal tambahkan metode pembayaran yang menurut Kalian 
paling mudah untuk melakukan pembelian aplikasi dan game di google play.

 

 


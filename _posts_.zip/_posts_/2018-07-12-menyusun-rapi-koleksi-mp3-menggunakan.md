---
layout: post
title: Menyusun Rapi Koleksi MP3 Menggunakan Windows Media Player
date: '2018-07-12T15:32:00.000+07:00'
author: rosari J
tags:
- mp3
- windows media player
modification_time: '2022-07-10T15:35:22.840+07:00'
blogger_id: tag:blogger.com,1999:blog-7329298365997944344.post-5264205060335465425
blogger_orig_url: https://www.oktrik.com/2018/07/menyusun-rapi-koleksi-mp3-menggunakan.html
---

Anda punya CD audio yang berisi lagu kesukaan ? Ingin anda jadikan MP3 atau WMA agar dapat didengarkan di iPod atau di MP3 player milik anda ? Jika anda membutuhkan semua proses itu, gunakan saja Windows Media Player 10 anda.

Lagu anda dapat di rip dengan cukup banyak pilihan kualitas. Namun tidak hanya itu, anda juga dapat memberi judul untuk semua lagu tersebut secara otomatis, beserta gambar cover albumnya asalkan ada koneksi Internet.

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhx270hgIrNmyWgMEdOupGCrHfXhh8PSVr-m6YyJRKQtzxt-LSF6A3-JMPSBYg4tXFO5O3Kv5iEdI80qSwkGar1D74faJ2AljSwRf23ijw39IJpOhO2DY3GUDZyNH6sh9gFzrd1f04bGOuUm9oOgT0AjUIcsuhvXGJ9kYZgIUnvBnw27E2MudC7gMdCsw/w640-h400/mp3-1-800x500.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhx270hgIrNmyWgMEdOupGCrHfXhh8PSVr-m6YyJRKQtzxt-LSF6A3-JMPSBYg4tXFO5O3Kv5iEdI80qSwkGar1D74faJ2AljSwRf23ijw39IJpOhO2DY3GUDZyNH6sh9gFzrd1f04bGOuUm9oOgT0AjUIcsuhvXGJ9kYZgIUnvBnw27E2MudC7gMdCsw/s800/mp3-1-800x500.jpg)  
 Menyusun Koleksi Mp3 Dengan Media Player
----------------------------------------

Berikut ini adalah langkah-langkah sederhananya :

### **Masukkan CD Anda Kedalam CD/ PLAYER**

Jika anda memiliki CD audio favorit dan ingin di rip menjadi format MP3 maupun WMA, masukkan saja CD anda ke dalam CD-ROM dan jalankan program Windows Media Player anda. CD audio apapun dapat di rip menggunakan Windows Media Player 10 ini.

Namun untuk mendapatkan informasi judul lagu beserta gambar album dari musik anda ini, usahakan agar CD audio tersebut adalah sebuah album spesifik tertentu dari penyanyi internasional.

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgs9SpJdGZPEqQuGVZJKFohjV2KRphDNYhEGC-304HgnT_w0JhxfMxAce_dQP2L_h8L3G5OPfZIsAo3yI9A6oV0JpS6FnVEjUEmIKN2RsKK33_-WASOx2prid0ppJcj5DRi_43VTlgZ9jObPIgPtYLGFEIIupmlke1jMU_Y1u6RSRrbXsQ_aOPki4IJvA/w640-h360/wmp_1024x576.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgs9SpJdGZPEqQuGVZJKFohjV2KRphDNYhEGC-304HgnT_w0JhxfMxAce_dQP2L_h8L3G5OPfZIsAo3yI9A6oV0JpS6FnVEjUEmIKN2RsKK33_-WASOx2prid0ppJcj5DRi_43VTlgZ9jObPIgPtYLGFEIIupmlke1jMU_Y1u6RSRrbXsQ_aOPki4IJvA/s1024/wmp_1024x576.jpg)  
 ### **Buka di Windows Media Player**

Setelah memasukkan CD anda, bukalah CD tersebut di program Windows Media Player anda. Caranya kliklah tombol Quick Access Panel yang letaknya berada di sebelah tab Now Playing. Setelah di klik, maka akan muncul opsi pengaksesan cepat dari media-media penyimpanan yang ada di komputer anda.

Selain itu, juga ada list-list yang telah sengaja dibuat. Dalam kasus anda ini, pilihlah media penyimpanan CD-ROM di mana anda memasukkan CD tersebut. Setelah di klik, maka seluruh lagu di dalam CD akan terbuka di Windows Media Player tersebut.

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhWS4cYOaPH0ukIxWbrJVKx4yZs0kJRXnL1P0F_a436dX5rWa842kYT1Mz-9Q6qWTxW_M44rNyCvai7L5ZHsXJsrTzVuhgL390ojgkIOTX7rp__ZP1doLyos7kV2Y58BTA4DTSBhOSVlDfqvUL-yph_117jHVc0kdcuzmfEEkryScaWLoG8a1T4oDNo6A/w640-h246/Capture_1024x392.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhWS4cYOaPH0ukIxWbrJVKx4yZs0kJRXnL1P0F_a436dX5rWa842kYT1Mz-9Q6qWTxW_M44rNyCvai7L5ZHsXJsrTzVuhgL390ojgkIOTX7rp__ZP1doLyos7kV2Y58BTA4DTSBhOSVlDfqvUL-yph_117jHVc0kdcuzmfEEkryScaWLoG8a1T4oDNo6A/s1024/Capture_1024x392.jpg)  
 ### **Masuk ke Menu Ripping**

Setelah di pastikan semua lagu muncul di Windows Media Player, langkah selanjutnya adalah masuk ke menu Ripping. Caranya kliklah tab Rip yang ada di bagian atas. Sesaat kemudian akan muncul menu lagu-lagu dari CD anda yang akan di Rip.

Anda dapat dengan bebas memilih lagu-lagu mana saja yang ingin di Rip menjadi format lain. Tinggal hilangkan centang `(√)` yang ada di depan setiap lagu, maka anda dapat mengatur lagu mana saja yang ingin di Rip atau tidak.

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiSc6PnMR7CT02W-Qqx9-vq1iHKhDa_e_m7vxv6FBw2VFu91XduKNPJFlDbQoujLcdmIrlZgDbDyfFVS9UyUW1P0gIF27o5wcs1UaByzi4A4QPkzjiFISwAO_ioSHAszwo4xgut8mjymCaBzsoE9HEngRyloc89__L0UgNyBHShidQFXpYy9FMFof8I5w/w640-h436/rip-cd-in-windows-media-player_1024x698.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiSc6PnMR7CT02W-Qqx9-vq1iHKhDa_e_m7vxv6FBw2VFu91XduKNPJFlDbQoujLcdmIrlZgDbDyfFVS9UyUW1P0gIF27o5wcs1UaByzi4A4QPkzjiFISwAO_ioSHAszwo4xgut8mjymCaBzsoE9HEngRyloc89__L0UgNyBHShidQFXpYy9FMFof8I5w/s1024/rip-cd-in-windows-media-player_1024x698.jpg)  
 ### **Atur Parameter Ripping**

Jika anda ingin memodifikasi lagi proses Ripping ini, kliklah menu Tools|Options… Setelah itu klik tab Rip Music, sesaat kemudian akan muncul menu pengaturannya. Di dalam menu ini, anda dapat menentukan ke folder mana lagu tersebut akan disimpan.

Selain itu, anda juga bisa mengatur format apa yang ingin digunakan untuk membuat lagu anda. Format yang tersedia adalah Windows Media Audio (terdiri dari tiga jenis yang masing-masing berbeda penentuan bit rate-nya) dan MP3.

Anda juga dapat mengatur parameter Audio Quality-nya (kualitas tinggi atau tidak bergantung kepada bit rate-nya). Setelah selesai, klik tombol OK.

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgY8WH8mja6FfdOcJ-P-IYobh3ROEVNw-cqS97BQyTb5V6SZ9mO7BxRD2FHBjFhOXA1xnqVetjvcEzIEqJWGgKrbuNsCQDaLKxQq3N18k2SDcuSXw8SbSSh1jVpLXX1LgTZFRIh5qOWRaGljLZek4524hHbOz5_Ni19mh5wFIQ1mkD-myvkps2ZnpTgSg/w492-h640/rip-music-options_590x768.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgY8WH8mja6FfdOcJ-P-IYobh3ROEVNw-cqS97BQyTb5V6SZ9mO7BxRD2FHBjFhOXA1xnqVetjvcEzIEqJWGgKrbuNsCQDaLKxQq3N18k2SDcuSXw8SbSSh1jVpLXX1LgTZFRIh5qOWRaGljLZek4524hHbOz5_Ni19mh5wFIQ1mkD-myvkps2ZnpTgSg/s768/rip-music-options_590x768.jpg)  
 ### **Mulai Melakukan Ripping Audio Dengan WMA**

Setelah semua selesai diatur sesuai keinginan anda, mulailah melakukan Ripping. Caranya kliklah tombol Rip Music yang letaknya berada di bagian kanan atas jendela Windows Media Player. Setelah di klik maka proses Ripping akan berjalan.

Setiap musik membutuhkan waktu yang bervariasi tergantung pada panjang pendeknya musik tersebut. Lagu yang sudah di Rip akan hilang tanda centangnya `(√)` dan di beri keterangan Ripped To Library.

Jika tidak ingin semua lagu di Rip, anda dapat menyetopnya kapan saja. Tinggal klik tombol Stop Rip. Setelah anda selesai melakukan Rip, semua lagu tersimpan di folder yang ditentukan.

### **Mendapatkan Informasi Lagu/ Song Info Lewat Windows Media Player**

Setelah selesai proses di atas, maka lagu-lagu anda telah tersimpan rapi di folder yang ditentukan. Namun, jika ingin memberikan judul dan juga informasi seputar album dari lagu-lagu tersebut , anda dapat melakukannya dengan mudah asalkan ada koneksi Internet,  sambungkan dahulu PC anda dengan Internet, kemudian kliklah menu Find Album Info.

Setelah menunggu beberapa lama, maka keluarlah informasi yang anda butuhkan seputar lagu tersebut. Informasinya termasuk judul lagu, penyanyi, gambar cover album, jenis Genre dan banyak lagi. Lagu anda kini sudah berjudul.

### **Lagu Anda Tersusun Rapi**

Setelah semua proses selesai, maka lagu anda kini sudah siap di transfer ke MP3 player anda untuk didengarkan di mana saja. Lagu anda kini telah tersimpan rapi di dalam folder yang ditentukan.

Kesimpulan
----------

Selain itu, informasi seputar lagu tersebut juga telah tersedia, tidak perlu anda edit satu persatu secara manual. Bahkan anda akan mendapatkan gambar albumnya yang dapat anda lihat di gambar folder lagu tersebut. Tidak perlu repot-repot untuk mengatur lagu-lagu anda, bukan  ? Selamat mencoba.

 


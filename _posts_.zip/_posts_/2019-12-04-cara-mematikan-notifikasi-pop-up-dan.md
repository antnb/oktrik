---
layout: post
title: Cara Mematikan Notifikasi Pop Up Dan Spam Yang Menggangu
date: '2019-12-04T11:39:00.001+07:00'
author: rosari J
tags:
- android
- notifikasi
modification_time: '2022-07-10T11:41:28.485+07:00'
blogger_id: tag:blogger.com,1999:blog-7329298365997944344.post-8526916221018408334
blogger_orig_url: https://www.oktrik.com/2019/12/cara-mematikan-notifikasi-pop-up-dan.html
---

Bermain game memang banyak dilakukan melalui Hp daripada bermain 
secara langsung. Hal tersebut dikarenakan bermain di Hp lebih memiliki 
banyak permainan yang bermacam-macam sehingga anak-anak banyak 
menyukainya.

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEho8B0z-fQZa4YJL0f2I1i93d1Sb44ItiHAlaqhGT98Xz_NPVh22suXGN1gedeKSYw6l0X80V84UShJdlnbdCWk6WvU-_TliYDU4DyLUMEYVMYL4yCV-Eg9t7V5ff9ahRcns7lw5fqawmg6OHRPguspoy8onN9ybXdE1Yc6BBP3zcWzN4nOHfMOJxa8sw/w640-h428/gaming_640x427.png)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEho8B0z-fQZa4YJL0f2I1i93d1Sb44ItiHAlaqhGT98Xz_NPVh22suXGN1gedeKSYw6l0X80V84UShJdlnbdCWk6WvU-_TliYDU4DyLUMEYVMYL4yCV-Eg9t7V5ff9ahRcns7lw5fqawmg6OHRPguspoy8onN9ybXdE1Yc6BBP3zcWzN4nOHfMOJxa8sw/s640/gaming_640x427.png)  
 
Apa itu notifikasi pop up dan Bagaimana Cara Kerjanya?
------------------------------------------------------


Notifikasi pop up artinya pesan yang ditampilkan di browser atau di 
layar smartphone Anda. Pesan ini dimaksudkan untuk memberitahukan kepada
 Anda bahwa anda telah menerima sebuah pesan atau notifikasi , itulah 
yang dimaksud notifikasi pop up


Dari jendela Notifikasi popup, Anda dapat dengan cepat memeriksa 
konten notifikasi dan mengambil berbagai tindakan. Jika Anda menerima 
pesan saat menonton film atau bermain game, misalnya, Anda dapat 
melihatnya dan merespons tanpa berpindah layar. Untuk melihat konten 
jendela popup notifikasi, geser ke bawah.



Mematikan Notifikasi Pemberitahuan
----------------------------------


Walaupun dengan mudah melakukannya di Hp dengan cara mengunduh 
aplikasi game yang diinginkan kemudian bisa menikmati dengan mudah dan 
nyaman.


Walaupun begitu, terdapat beberapa kendala dalam bermain game. Salah 
satunya adalah terdapat pesan pemberitahuan yang muncul pada saat 
bermain game. Hal tersebut bisa saja mengganggu kenyamanan dalam 
melakukan game. Berikut ini adalah cara untuk menghilangkan notifikasi 
pop up pada saat bermain game.

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEg0wirQMz1L2_wL2pdMFwEqUdlbvppSG-64YJ0EqGy-67kH9wyLV19hRRrzvIpfTLFVUo_YCvH1Gt-gWjGp4jPp8TmmtR8IdF6kELEHpRloCzX5S3AlSR-VN75kpWCNz-2o2NhSadPAaTZQz8pa1pinIAi3mfZ0DEUP7Pkpzz_ZrQHe0gdufyqXoarmEQ/w640-h400/android-800x500.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEg0wirQMz1L2_wL2pdMFwEqUdlbvppSG-64YJ0EqGy-67kH9wyLV19hRRrzvIpfTLFVUo_YCvH1Gt-gWjGp4jPp8TmmtR8IdF6kELEHpRloCzX5S3AlSR-VN75kpWCNz-2o2NhSadPAaTZQz8pa1pinIAi3mfZ0DEUP7Pkpzz_ZrQHe0gdufyqXoarmEQ/s800/android-800x500.jpg)  
 ### Mematikan Data


Pada saat menggunakan game atau permainan offline pasti tidak 
memerlukan jaringan internet untuk bermain. Memang banyak juga permainan
 yang bisa dilakukan secara offline sehingga tidak diperlukan data 
internet. Pemain game offline ini pasti santai-santai saja karena tidak 
terdapat notifikasi pop up apapun pada saat bermain game.



Biasanya dalam bermain game offline dilakukan agar menghemat kuota 
internet karena apabila disambungkan akan terjadi penghabisan kuota yang
 cukup pesat walaupun memang pengguna game mendapatkan beberapa hadiah 
atau poin apabila bermain secara online.


Biasanya ganguan yang didapatkan selain iklan atau pesan 
pemberitahuan adalah beberapa iklan dari aplikasi lain seperti browser, 
pesan WhatsApp, Instagram, atau media sosial lainnya bisa saja muncul 
pada saat bermain secara online.


Cara ampuh agar tidak terganggu notifikasi tersebut adalah dengan 
mematikan atau membuat notifikasi tidak bersuara atau bisa saja dengan 
mematikan data sehingga tidak akan terganggu oleh pesan pemberitahuan 
tersebut. Cara yang pertama ini biasanya digunakan pada saat bermain 
game secara offline.



### Menggunakan aplikasi Notification Blocker


Cara selanjutnya untuk menghentikan pesan pemberitahuan pada saat 
bermain game adalah dengan mengunduh aplikasi Notification blocker. 
Salah satu aplikasi untuk memblokir notifikasi adalah aplikasi 
Notification Blocker & Cleaner & Heads-up Off.


Caranya adalah mengunduh aplikasi tersebut terlebih dahulu yang sudah
 tersedia di Play Store bagi Hp Android dan App Store bagi Hp Apple. 
Setelah berhasil mengunduh kemudian pengguna bisa mencari opsi atau menu
 settings atau pengaturan yang tersedia di aplikasi tersebut.


Kemudian pengguna bisa memilih aplikasi atau game yang ingin diblokir
 pesan pemberitahuan nya. apabila aplikasi ini telah aktif, maka cara 
menampilkan pop up wa adalah dengan memasukan whatsapp kedalam 
whitelist. Keunggulan aplikasi ini adalah mampu menghilangkan sampah 
pesan pemberitahuan yang sudah banyak sehingga aplikasi lebih terjamin 
bersih dari pesan pemberitahuan yang mengganggu.



### Menu Pengaturan Ponsel


Cara berikutnya yaitu melalui menu pengaturan yang terdapat di dalam 
ponsel masing-masing. Langkah pertama adalah tentu saja pengguna harus 
masuk terlebih dahulu ke dalam menu pengaturan atau settings yang 
terdapat di dalam ponsel. Kemudian setelah berhasil masuk, pengguna bisa
 memilih opsi atau menu Pemberitahuan atau notification.


Setelah memilih menu tersebut, pengguna bisa memilih aplikasi atau 
game yang akan dihapus atau dihilangkan notifikasinya. Setelah memilih 
atau mengeklik aplikasi yang diinginkan kemudian pengguna bisa mengeklik
 atau menonaktifkan Izin pemberitahuan atau notification. Setelah 
memilih menu atau mengeklik pilihan tersebut maka pesan pemberitahuan 
juga tidak akan muncul lagi pada saat bermain game.

Selain aplikasi game, melalui cara yang praktis dan mudah ini 
pengguna juga bisa memblokir notifikasi atau iklan di beberapa aplikasi 
lainnya seperti browser, pop up wa, musik, chrome, dan lain sebagainya sehingga smartphone yang dimiliki akan terbebas dari pesan pemberitahuan yang mengganggu.



Penutup
-------


Buat kalian yang sudah membaca artikel ini bisa memilih salah satu 
cara yang sudah dipaparkan. Dijamin pesan pemberitahuan yang mengganggu 
saat bermain game tidak akan pernah muncul lagi. itulah beberapa cara 
untuk menghilangkan notifikasi pop up pada saat bermain game. Semoga 
bermanfaat.


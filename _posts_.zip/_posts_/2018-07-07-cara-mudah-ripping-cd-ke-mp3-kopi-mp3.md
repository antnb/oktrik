---
layout: post
title: Cara Mudah Ripping CD ke MP3 (Kopi Mp3 Dari CD)
date: '2018-07-07T15:42:00.001+07:00'
author: rosari J
tags:
- audio
- mp3
modification_time: '2022-07-10T15:45:39.667+07:00'
blogger_id: tag:blogger.com,1999:blog-7329298365997944344.post-5548090846102453936
blogger_orig_url: https://www.oktrik.com/2018/07/cara-mudah-ripping-cd-ke-mp3-kopi-mp3.html
---

Bila anda ingin *mengubah format koleksi CD anda ke dalam bentuk MP3* agar mudah didengar di Komputer, cobalah untuk menggunakan software **audio extractor** ini. Selain sangat mudah penggunaannya, anda juga dapat memberikan identitas yang lengkap pada lagu yang akan di Ripping.

Jalankan Aplikasi MP3 Extractor
-------------------------------

Setelah menginstal program audio extractor yang telah kami sediakan ini, jalankan program tersebut. Masukkan CD lagu anda, kemudian pada daftar lagu yang muncul, pilih yang mana saja yang akan di rubah. Anda juga dapat mendengarkan lagu, dengan menekan tombol-tombol yang ada di bawah.

Tombol-tombol ini cukup lengkap, anda seperti sedang menggunakan Media Player saja. Mulai dari tombol-tombol player sampai tombol Eject dan radio bar untuk volume. Sedangkan di bagian atasnya, anda dapat melengkapi CD dengan nama album, penyanyi, tahun keluarnya, serta jenis musiknya.

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgVVpEgmYmTSKYXyYMH-Od2Jq0RAUCZG9YwKhHyIh7VKbcCZ7iGCmbi6G_75TvhsjwnPuVKSMqvAXXsxCPVWnuRzywFlR0bbNj8SHDq1dqXQttbWGSRC-o_LJngIA5sL3Ezhq1IsDJtPBP-oGQYGcR6tXUPXe4cZ-7VcPnjA8njDTMzza-H7GSNgYvSnw/w640-h400/ripping-1-800x500.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgVVpEgmYmTSKYXyYMH-Od2Jq0RAUCZG9YwKhHyIh7VKbcCZ7iGCmbi6G_75TvhsjwnPuVKSMqvAXXsxCPVWnuRzywFlR0bbNj8SHDq1dqXQttbWGSRC-o_LJngIA5sL3Ezhq1IsDJtPBP-oGQYGcR6tXUPXe4cZ-7VcPnjA8njDTMzza-H7GSNgYvSnw/s800/ripping-1-800x500.jpg)  
 ### Mengedit Data

Bila ada atribut lagu yang ingin dilengkapi,maka tekan tombol Edit. Dengan tombol ini, akan terbuka layar Edit Disc Data. Pada Edit Disc Data, anda dapat memasukkan beberapa atribut lagu. Mulai nama lagu, penyanyi, sampai judul lagu.

Informasi yang diberikan dapat lebih lengkap dibandingkan dengan halaman depan. Di halaman Edit, anda dapat memasukkan judul lagu sekaligus untuk setiap track. Caranya, cukup dengan pilih track yang akan diberikan nama, lalu ketikkan judul lagu di sebelah tombol Set Name. kemudian untuk mengaktifkan judul tersebut tekan tombol Set Name.

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjdFRlyysGOeWc7z1CSH9_3rDKnl26_2bjSXh22VLlHNTBfmmi5LjzMJMDefAp8V7zx51UdswMaccqMFiCk_cJb1nOwrGfVYYEew0zz-FviDBgGGHDrAoTmblqprsPITBHcifwT_ouWsLltJeQ3ybVlpeqDGmeyvQY-9JAvBvwZ0Y22eMEcgYQj4S2cdQ/w640-h522/scrshot.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjdFRlyysGOeWc7z1CSH9_3rDKnl26_2bjSXh22VLlHNTBfmmi5LjzMJMDefAp8V7zx51UdswMaccqMFiCk_cJb1nOwrGfVYYEew0zz-FviDBgGGHDrAoTmblqprsPITBHcifwT_ouWsLltJeQ3ybVlpeqDGmeyvQY-9JAvBvwZ0Y22eMEcgYQj4S2cdQ/s683/scrshot.jpg)  
 ### **Pilih Format**

Bila sudah mengatur nama-nama lagunya, tekan tombol Copy. Pada halaman Output, dapat ditentukan format apa yang diinginkan sebagai hasil akhir. Lalu tentukan bagaimana tampilan nama file pada boks Output File Name. Pada Out File Box, tentukan lokasi hasil akhir Ripping akan diletakkan. Ada beberapa pilihan berkaitan dengan format.

Yang pertama adalah Integrated Format dan Windows Format. Pada Integrated Format ada enam format yang dapat dipilih .mp3, .m4a, .ogg, .ape, dan .wav. Sedangkan Di bagian Windows Format anda dapat memilih PCM, Windows Media Audio, MPEG Layer 3 serta Microsoft ADPCM.

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjRobz06QXXn02kn9bNtda7SoOR8xyynk5yXgdeeSyMgzWjlWScVMH6XHmh4w6keGqFs8M0PCbf3nhh8Hut-UPp00RhGcKM5Lui2JPbEmkJLK_t3_YWpKujRqKFbQs98IiEyifrvIsRin4VdWHrYzPcr1Ml8M_XFj8trGC3VWufG8HU-GwQUSrxwU2IlA/w640-h482/scrshot3.png)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjRobz06QXXn02kn9bNtda7SoOR8xyynk5yXgdeeSyMgzWjlWScVMH6XHmh4w6keGqFs8M0PCbf3nhh8Hut-UPp00RhGcKM5Lui2JPbEmkJLK_t3_YWpKujRqKFbQs98IiEyifrvIsRin4VdWHrYzPcr1Ml8M_XFj8trGC3VWufG8HU-GwQUSrxwU2IlA/s920/scrshot3.png)  
 ### **Identitas Pelengkap**

Bila ada identitas lagu yang akan anda Ripping belum lengkap, buka saja halaman ID3. Pada halaman ini, anda dapat mengedit mulai dari nama penyanyi, album sampai tahun pembuatannya. Bahkan anda juga dapat memasukkan sedikit komentar ke masing-masing lagu.

Termasuk juga informasi mengenai hak cipta, website dan nama yang melakukan proses Encode. Bila sudah selesai mengedit identitas lagu, kembali ke halaman Output. Lalu tekan tombol Start Copying. Atau tekan tombol Cancel jika ada yang masih akan anda atur.

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEg4utTnalehSbtIV_v00LmUOSR6k8VquBWmfZXsylg3r-kT1SbQVxXRnf79EgdJtqHDXEwBoWm8V9Q7vG22g8-hd7Yh657tPa9VTYdtcn9WC29CZQLBPJquFUDCch-8ErQKEFI1ORNpLc8BRn_Uaodvmfv1J2N4k2GpVpQxpWJzgB8UQ5zIUwwrOt0ZFQ/w640-h482/scrshot2.png)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEg4utTnalehSbtIV_v00LmUOSR6k8VquBWmfZXsylg3r-kT1SbQVxXRnf79EgdJtqHDXEwBoWm8V9Q7vG22g8-hd7Yh657tPa9VTYdtcn9WC29CZQLBPJquFUDCch-8ErQKEFI1ORNpLc8BRn_Uaodvmfv1J2N4k2GpVpQxpWJzgB8UQ5zIUwwrOt0ZFQ/s920/scrshot2.png)  
 ### **Output Audio / Convert MP3 Ke Format Audio Lain**

Anda juga dapat **mengubah file Audio yang ada ke dalam bentuk lain**, misalnya MP3 atau WAV. Caranya cukup dengan menekan menu Tools, lalu pilih Easy Audio File Converter. Maka akan terbuka layar tersendiri untuk me-Ripping antar Format File.

Carilah folder yang memuat file di sebelah kiri atas. Lalu seret lagu yang ada di sebelah kanan atas, ke dalam bagian kiri bawah. Setelah itu, pada bagian kanan tentukan formatnya, sama seperti me-Ripping CD ke format lain (Langkah 3)

### **ID3**

Selain melakukan proses Ripping audio extractor dari CD, anda juga dapat mengonversikan file audio lain yang sudah dipindahkan di komputer. Atau misalnya mengubah dari format .mp3 ke format lain. Caranya cukup dengan menekan tombol Shift+F2.

Bila ingin memasukan atribut pada file yang akan di Ripping, anda dapat membuka halaman ID3 yang ada di sebelah Output, bagian kanan bawah pada layar anda. Dalam ID3 ini, anda dapat memasukkan judul, penyanyi, album dan sebagainya. Sedangkan di bagian Output, anda dapat menentukan lokasi hasil konversi dan pilihan format awal dan akhir.

### **Add File dan Remove**

Bila ada file audio yang tidak akan jadi di Ripping, maka anda tinggal memilih file yang dimaksud pada bagian kiri bawah, lalu tekan tombol Remove. Anda juga dapat memasukkan file dengan menekan tombol Add File. Pilih file apa saja, kemudian tekan tombol Open.

Jika ada file yang tidak jadi di konversi, pilih saja filenya lalu tekan tombol Remove Selected. Atau cara termudah menambahkan file, dengan cara membrowsing kemudian menyeretnya ke dalam bagian sebelah kiri bawah. Bila butuh bantuan, pilih  menu Help, Homepage.

**Download aplikasi extract audio Dari CD/DVD**
-----------------------------------------------

<http://www.mediafire.com/file/gw9ht6fbdbhcquh/ezcddax9.exe/file>


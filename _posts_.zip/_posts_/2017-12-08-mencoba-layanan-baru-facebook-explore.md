---
layout: post
title: Mencoba layanan Baru Facebook Explore Feed
date: '2017-12-08T16:52:00.001+07:00'
author: rosari J
tags:
- social media
- facebook
modification_time: '2022-07-10T16:54:29.168+07:00'
blogger_id: tag:blogger.com,1999:blog-7329298365997944344.post-4417131470780419913
blogger_orig_url: https://www.oktrik.com/2017/12/mencoba-layanan-baru-facebook-explore.html
---

Jika anda menggunakan aplikasi Facebook pada IOS, mungkin anda memperhatikan terdapat dua ikon baru menggantikan ikon lama yaitu ikon beranda toko dan sebuah ikon seperti gambar roket. kedua ikon tersebut adalah sebuah shorcut atau jalan pintas untuk membuka FAcebook marketplace dan Facebook Explore Feed

Menu Facebook marketplace rasanya sudah tidak asing lagi bagi anda dan pastinya anda sudah paham fungsi dan kegunaan nya, namun yang menarik perhatian bagi kami ialah Menu *Facebook Explore Feed*. dikarenakan rasa penasaran kami putuskan untuk sedikit mencari tahu apakah kegunaan Facebook Explore Feed ini

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhAVrXyxH3cs_CnKA_WtDQT2NSp-ZNTMQGAg5z9tn9LmREh-rfseaULixH0s0i9J6ZHkrTot2p4f_bC2rad3deJMwpdzMkw2n3xCIOpehZ7y0bG3FPdiPHd9fkJJqt6F6PibEQBTUQTiGEkvJE0g6bmMf1VP67QJYK5XhI6n5i09n2IjIpUt8ZVQqJ72Q/w640-h400/fb-1-800x500.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhAVrXyxH3cs_CnKA_WtDQT2NSp-ZNTMQGAg5z9tn9LmREh-rfseaULixH0s0i9J6ZHkrTot2p4f_bC2rad3deJMwpdzMkw2n3xCIOpehZ7y0bG3FPdiPHd9fkJJqt6F6PibEQBTUQTiGEkvJE0g6bmMf1VP67QJYK5XhI6n5i09n2IjIpUt8ZVQqJ72Q/s800/fb-1-800x500.jpg)  
 Setelah sedikit mencari tahu, Rupanya dari pada menampilkan Post dari Pages atau laman yang telah anda like, Pada facebook explore feed ini anda akan diberikan atau ditampilkan post atau laman yang populer dikalangan friendlist anda atau yang populer dengan demografik yang cocok dengan anda sebagai contoh anda dan kawan dari group anda sama sama menyukai laman dengan topik berita terkini. Kemungkinan besar untuk mengambil data tersebut facebook menggunakan beragam metode atau algoritme dan dan dapat diakses pada [facebook profile](https://www.oktrik.com/cara-melihat-orang-yang-melihat-fb-kita.html) anda dalam ketegori "Top posts for you from across Facebook."

Jika anda baru mendengar tentang **fitur baru Facebook Explore Feed** maka anda dapat mengaksesnya melalui Fb apps pada IOS anda, Cukup ketuk menu ikon dan pilih "*Explore find*". Fb explore feed akan tersedia pada tabs Favorites jika anda menggunakan smartphone dengan os Android dan "*explore*" jika anda menggunakan IOS

Setelah mencoba fitur ini dan melakukan explorasi fungsi fungsi yang disediakan FAcebook explore feed, sepertinya fitur ini hanya dimaksudkan agar para pengguna facebook menghabiskan waktu yang lebih lama saat menggunakan Facebook.

Karena Fitur Explore Feed ini sepertinya tidak menambahkan layanan layanan yang penting, hanya menarik data feed atas topik yang anda sukai seperti Feed pada reddit anda atau post pada satu facebook group. seperti yang anda ketahui semakin lama durasi anda menggunakan facebook maka lebih banyak lagi iklan yang dapat ditampilkan yang pada akhirnya Facebook dapat menghasilkan Pendapatan lebih


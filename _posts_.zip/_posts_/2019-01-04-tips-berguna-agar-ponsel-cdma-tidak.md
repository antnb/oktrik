---
layout: post
title: Tips berguna Agar Ponsel CDMA Tidak Cepat Panas
date: '2019-01-04T13:33:00.002+07:00'
author: rosari J
tags:
- baterai
- smartphone
modification_time: '2022-07-23T23:53:01.625+07:00'
blogger_id: tag:blogger.com,1999:blog-7329298365997944344.post-951761866585471303
blogger_orig_url: https://www.oktrik.com/2019/01/tips-berguna-agar-ponsel-cdma-tidak.html
---

Program tarif murah yang sudah lama ditawarkan oleh operator CDMA membuat Anda susah berpaling untuk menelepon nomor lokal via kartu CDMA. Ada yang menawarkan tarif bicara Rp 1000 per jam, Rp 1000 per hari hingga hitungan menit saja.

Tinggal pilih deh. Hanya saja nih, saking murahnya, Anda jadi sering menelepon kelewat lama. Gak peduli sedang pacaran atau hanya iseng saja ngomongin orang lain. Dan tanpa sadar, *ponsel yang dipakai lebih dari setengah jam itu mulai terasa panas di telinga.*

Karena itu tak heran banyak pengguna ponsel CDMA yang memanfaatkan handfree atau loud speaker yang disediakan. “Waduh kalau harus merapatkan speaker ke telinga, saya gak kuat. Ponselnya terasa panas banget,” ujar Weni yang rajin menelepon pacarnya selama minimum setengah jam. “Cukup pakai handsfree. Tapi kalau dengan loud speaker kan tidak sopan,”

Nah, Anda tahu kenapa ponsel CDMA lebih cepat panas dibanding ponsel GSM? Secara teori pengaruh dari power control di BTS yang mengatur kekuatan sinyal tiap handset agar seimbang dan tidak saling tumpang tindih lah yang [menyebabkan ponsel CDMA cepat panas]({{ site.baseurl }}{% post_url 2017-12-05-tips-menghemat-baterai-iphone-dan %}).

Selain itu ponsel CDMA juga membutuhkan power yang bersifat konstan, terutama saat Anda memulai percakapan dari awal hingga akhir. Penggunaan tenaga baterai secara konstan memungkinkan timbulnya panas di ponsel CDMA lebih tinggi dibanding ponsel GSM. Tapi Anda tidak perlu khawatir dengan panas di ponsel.

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhsfUSKgTymPcVHyfWZiqFWnduAv0ef64qoNBWVXjxqOELaU7GrC3gaFqwuNrwm768fIB1Hmim7vWs7VaeYFUcNb6If5Zbiv4DaLJDSBrNPLsGbiY9vuF-CsDYIjenSVDsoupzKRDogMbSYlQUBgW5RcCq-X2V5PcjvIfCXGhlhrL3BTB9sjxL8G0a3LQ/w640-h400/batre-1-800x500.jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhsfUSKgTymPcVHyfWZiqFWnduAv0ef64qoNBWVXjxqOELaU7GrC3gaFqwuNrwm768fIB1Hmim7vWs7VaeYFUcNb6If5Zbiv4DaLJDSBrNPLsGbiY9vuF-CsDYIjenSVDsoupzKRDogMbSYlQUBgW5RcCq-X2V5PcjvIfCXGhlhrL3BTB9sjxL8G0a3LQ/s800/batre-1-800x500.jpg)  
 #### Panduan berikut ini setidaknya bisa mengurangi tingkat panas di ponsel CDMA.

1. Cek kondisi baterai. Jika Anda sering mencharger pada saat ponsel menyala, lalu dipakai juga untuk menelepon, menyebabkan arus menjadi tidak stabil. Ada baiknya mencharger saat ponsel dimatikan. Selain itu yakinkan menggunakan baterai ponsel original. Memang sih murah jika membeli baterai non original, tapi hal ini secara tak langsung juga mempengaruhi performa ponsel CDMA. Baterai non original biasanya lebih cepat menghantarkan panas.
2. Pastikan kekuatan sinyal yang ada di daerah terdekat. Karena fungsi dari power control yang mengatur kekuatan sinyal di ponsel CDMA, maka yakinkan bar yang menunjukkan sinyal di ponsel terlihat penuh. Jika bar sinyal kurang dari setengah, dijamin ponsel akan lebih cepat panas dibanding ponsel yang menangkap sinyal bar penuh. Karena itu tidak 'da salahnya Anda survei dulu kondisi sinyal dari masing-masing operator CDMA yang ada di daerah Anda.
3. Bijak dalam menentukan lama pembicaraan. Menelepon lama memang seru dan mengasyikkan. Tapi kalau durasinya sudah lebih dari satu jam, banyak aktifitas penting yang terlewat kan. Lagipula ma- sih Anda harus menelepon selama itu. Ada baiknya tidak meneie-oc . lebih dari satu jam, ponsel pun tidak akan terlalu panas.
4. Pilihlah handset yang disertai dengan aturan hemat baterai. Jika ponsel cepat panas karena menyerap energi, maka ketahanan baterai akan cepat berkurang. Saat melakukan komunikasi, ada baiknya Anda juga tidak sedang membuka menu lainnya atau matikan fungsi backlight yang ada di ponsel.
5. Gunakan casing berwarna terang dan berbahan menolak panas. Jangan menggunakan casing berwarna gelap karena akan menyerap panas yang dihantarkan ponsel. Ada baiknya jika Anda gemar gonta-ganti casing, gunakan casing dari bahan stainless heating coil yang anti panas.

 

